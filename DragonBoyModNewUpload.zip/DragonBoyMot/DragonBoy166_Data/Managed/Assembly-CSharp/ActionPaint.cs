﻿using System;

// Token: 0x020000BB RID: 187
// (Invoke) Token: 0x06000944 RID: 2372
public delegate void ActionPaint(mGraphics g, int x, int y);
