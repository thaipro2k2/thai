﻿using System;

// Token: 0x02000045 RID: 69
public class Archivement
{
	// Token: 0x04000322 RID: 802
	public string info1;

	// Token: 0x04000323 RID: 803
	public string info2;

	// Token: 0x04000324 RID: 804
	public int money;

	// Token: 0x04000325 RID: 805
	public bool isFinish;

	// Token: 0x04000326 RID: 806
	public bool isRecieve;
}
