﻿using System;

// Token: 0x0200002E RID: 46
public class ClanManager
{
	// Token: 0x040001E8 RID: 488
	public static Clan[] clans;
}
