﻿using System;

// Token: 0x02000030 RID: 48
public class ClanObject
{
	// Token: 0x040001F7 RID: 503
	public int clanID;

	// Token: 0x040001F8 RID: 504
	public int code;
}
