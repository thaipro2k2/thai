﻿using System;

// Token: 0x0200004D RID: 77
public class DartInfo
{
	// Token: 0x04000490 RID: 1168
	public short id;

	// Token: 0x04000491 RID: 1169
	public short[][] head;

	// Token: 0x04000492 RID: 1170
	public short[][] headBorder;

	// Token: 0x04000493 RID: 1171
	public short[] tail;

	// Token: 0x04000494 RID: 1172
	public short[] tailBorder;

	// Token: 0x04000495 RID: 1173
	public short[] xd1;

	// Token: 0x04000496 RID: 1174
	public short[] xd2;

	// Token: 0x04000497 RID: 1175
	public short xdPercent;

	// Token: 0x04000498 RID: 1176
	public short nUpdate;

	// Token: 0x04000499 RID: 1177
	public int va;
}
