﻿using System;

// Token: 0x0200004F RID: 79
public class EffectCharPaint
{
	// Token: 0x040004A1 RID: 1185
	public int idEf;

	// Token: 0x040004A2 RID: 1186
	public EffectInfoPaint[] arrEfInfo;
}
