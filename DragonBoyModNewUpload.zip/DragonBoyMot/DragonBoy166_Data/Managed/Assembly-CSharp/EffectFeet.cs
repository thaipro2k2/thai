﻿using System;

// Token: 0x02000039 RID: 57
public class EffectFeet : Effect2
{
	// Token: 0x06000265 RID: 613 RVA: 0x00015A24 File Offset: 0x00013C24
	public static void addFeet(int cx, int cy, int ctrans, int timeLengthInSecond, bool isCF)
	{
		EffectFeet effectFeet = new EffectFeet();
		effectFeet.x = cx;
		effectFeet.y = cy;
		effectFeet.trans = ctrans;
		effectFeet.isF = isCF;
		effectFeet.endTime = mSystem.currentTimeMillis() + (long)(timeLengthInSecond * 1000);
		Effect2.vEffectFeet.addElement(effectFeet);
	}

	// Token: 0x06000266 RID: 614 RVA: 0x0000463C File Offset: 0x0000283C
	public override void update()
	{
		if (mSystem.currentTimeMillis() - this.endTime > 0L)
		{
			Effect2.vEffectFeet.removeElement(this);
		}
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00015A74 File Offset: 0x00013C74
	public override void paint(mGraphics g)
	{
		int num = (int)TileMap.size;
		if (TileMap.tileTypeAt(this.x + num / 2, this.y + 1, 4))
		{
			g.setClip(this.x / num * num, (this.y - 30) / num * num, num, 100);
		}
		else if (TileMap.tileTypeAt((this.x - num / 2) / num, (this.y + 1) / num) == 0)
		{
			g.setClip(this.x / num * num, (this.y - 30) / num * num, 100, 100);
		}
		else if (TileMap.tileTypeAt((this.x + num / 2) / num, (this.y + 1) / num) == 0)
		{
			g.setClip(this.x / num * num, (this.y - 30) / num * num, num, 100);
		}
		else if (TileMap.tileTypeAt(this.x - num / 2, this.y + 1, 8))
		{
			g.setClip(this.x / 24 * num, (this.y - 30) / num * num, num, 100);
		}
		g.drawRegion((!this.isF) ? EffectFeet.imgFeet3 : EffectFeet.imgFeet1, 0, 0, EffectFeet.imgFeet1.getWidth(), EffectFeet.imgFeet1.getHeight(), this.trans, this.x, this.y, mGraphics.BOTTOM | mGraphics.HCENTER);
		g.setClip(GameScr.cmx, GameScr.cmy - GameCanvas.transY, GameScr.gW, GameScr.gH + 2 * GameCanvas.transY);
	}

	// Token: 0x040002B7 RID: 695
	private int x;

	// Token: 0x040002B8 RID: 696
	private int y;

	// Token: 0x040002B9 RID: 697
	private int trans;

	// Token: 0x040002BA RID: 698
	private long endTime;

	// Token: 0x040002BB RID: 699
	private bool isF;

	// Token: 0x040002BC RID: 700
	public static Image imgFeet1 = GameCanvas.loadImage("/mainImage/myTexture2dmove-1.png");

	// Token: 0x040002BD RID: 701
	public static Image imgFeet3 = GameCanvas.loadImage("/mainImage/myTexture2dmove-3.png");
}
