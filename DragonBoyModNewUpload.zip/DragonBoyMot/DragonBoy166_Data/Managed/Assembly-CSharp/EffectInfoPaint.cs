﻿using System;

// Token: 0x02000050 RID: 80
public class EffectInfoPaint
{
	// Token: 0x040004A3 RID: 1187
	public int dx;

	// Token: 0x040004A4 RID: 1188
	public int dy;

	// Token: 0x040004A5 RID: 1189
	public int idImg;
}
