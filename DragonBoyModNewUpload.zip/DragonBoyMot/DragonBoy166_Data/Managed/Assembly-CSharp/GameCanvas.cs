﻿using System;
using Assets.src.g;
using UnityEngine;

// Token: 0x020000B6 RID: 182
public class GameCanvas : IActionListener
{
	// Token: 0x060008D1 RID: 2257 RVA: 0x00083A88 File Offset: 0x00081C88
	public GameCanvas()
	{
		int num = Rms.loadRMSInt("languageVersion");
		if (num == -1)
		{
			Rms.saveRMSInt("languageVersion", 0);
		}
		else if (num != 0)
		{
			Main.main.doClearRMS();
			Rms.saveRMSInt("languageVersion", 0);
		}
		GameCanvas.clearOldData = Rms.loadRMSInt(GameMidlet.VERSION);
		if (GameCanvas.clearOldData != 1)
		{
			Main.main.doClearRMS();
			Rms.saveRMSInt(GameMidlet.VERSION, 1);
		}
		this.initGame();
	}

	// Token: 0x060008D3 RID: 2259 RVA: 0x0000705B File Offset: 0x0000525B
	public static string getPlatformName()
	{
		return "iphone platform xxx";
	}

	// Token: 0x060008D4 RID: 2260 RVA: 0x00083C30 File Offset: 0x00081E30
	public void initGame()
	{
		MotherCanvas.instance.setChildCanvas(this);
		GameCanvas.w = MotherCanvas.instance.getWidthz();
		GameCanvas.h = MotherCanvas.instance.getHeightz();
		GameCanvas.hw = GameCanvas.w / 2;
		GameCanvas.hh = GameCanvas.h / 2;
		GameCanvas.isTouch = true;
		if (GameCanvas.w >= 240)
		{
			GameCanvas.isTouchControl = true;
		}
		if (GameCanvas.w < 320)
		{
			GameCanvas.isTouchControlSmallScreen = true;
		}
		if (GameCanvas.w >= 320)
		{
			GameCanvas.isTouchControlLargeScreen = true;
		}
		GameCanvas.msgdlg = new MsgDlg();
		if (GameCanvas.h <= 160)
		{
			Paint.hTab = 15;
			mScreen.cmdH = 17;
		}
		GameScr.d = ((GameCanvas.w <= GameCanvas.h) ? GameCanvas.h : GameCanvas.w) + 20;
		GameCanvas.instance = this;
		mFont.init();
		mScreen.ITEM_HEIGHT = mFont.tahoma_8b.getHeight() + 8;
		this.initPaint();
		this.loadDust();
		this.loadWaterSplash();
		GameCanvas.panel = new Panel();
		GameCanvas.imgShuriken = GameCanvas.loadImage("/mainImage/myTexture2df.png");
		if (Rms.loadRMSString("clienttype") != null && !Rms.loadRMSString("clienttype").Equals(string.Empty))
		{
			mSystem.clientType = int.Parse(Rms.loadRMSString("clienttype"));
		}
		if (mSystem.clientType == 7 && (Rms.loadRMSString("fake") == null || Rms.loadRMSString("fake") == string.Empty))
		{
			GameCanvas.imgShuriken = GameCanvas.loadImage("/mainImage/wait.png");
		}
		GameCanvas.imgClear = GameCanvas.loadImage("/mainImage/myTexture2der.png");
		GameCanvas.img12 = GameCanvas.loadImage("/mainImage/12+.png");
		GameCanvas.debugUpdate = new MyVector();
		GameCanvas.debugPaint = new MyVector();
		GameCanvas.debugSession = new MyVector();
		for (int i = 0; i < 3; i++)
		{
			GameCanvas.imgBorder[i] = GameCanvas.loadImage("/mainImage/myTexture2dbd" + i + ".png");
		}
		GameCanvas.borderConnerW = mGraphics.getImageWidth(GameCanvas.imgBorder[0]);
		GameCanvas.borderConnerH = mGraphics.getImageHeight(GameCanvas.imgBorder[0]);
		GameCanvas.borderCenterW = mGraphics.getImageWidth(GameCanvas.imgBorder[1]);
		GameCanvas.borderCenterH = mGraphics.getImageHeight(GameCanvas.imgBorder[1]);
		Panel.graphics = Rms.loadRMSInt("lowGraphic");
		GameCanvas.lowGraphic = (Rms.loadRMSInt("lowGraphic") == 1);
		GameScr.isPaintChatVip = (Rms.loadRMSInt("serverchat") != 1);
		Res.init();
		SmallImage.loadBigImage();
		Panel.WIDTH_PANEL = 176;
		if (Panel.WIDTH_PANEL > GameCanvas.w)
		{
			Panel.WIDTH_PANEL = GameCanvas.w;
		}
		InfoMe.gI().loadCharId();
		Command.btn0left = GameCanvas.loadImage("/mainImage/btn0left.png");
		Command.btn0mid = GameCanvas.loadImage("/mainImage/btn0mid.png");
		Command.btn0right = GameCanvas.loadImage("/mainImage/btn0right.png");
		Command.btn1left = GameCanvas.loadImage("/mainImage/btn1left.png");
		Command.btn1mid = GameCanvas.loadImage("/mainImage/btn1mid.png");
		Command.btn1right = GameCanvas.loadImage("/mainImage/btn1right.png");
		GameCanvas.serverScreen = new ServerListScreen();
		GameCanvas.img12 = GameCanvas.loadImage("/mainImage/12+.png");
		for (int j = 0; j < 7; j++)
		{
			GameCanvas.imgBlue[j] = GameCanvas.loadImage("/effectdata/blue/" + j + ".png");
			GameCanvas.imgViolet[j] = GameCanvas.loadImage("/effectdata/violet/" + j + ".png");
		}
		ServerListScreen.createDeleteRMS();
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x00007062 File Offset: 0x00005262
	public static GameCanvas gI()
	{
		return GameCanvas.instance;
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x00007069 File Offset: 0x00005269
	public void initPaint()
	{
		GameCanvas.paintz = new Paint();
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x00007075 File Offset: 0x00005275
	public static void closeKeyBoard()
	{
		mGraphics.addYWhenOpenKeyBoard = 0;
		GameCanvas.timeOpenKeyBoard = 0;
		Main.closeKeyBoard();
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00083FD4 File Offset: 0x000821D4
	public void update()
	{
		Res.updateOnScreenDebug();
		try
		{
			if (global::TouchScreenKeyboard.visible)
			{
				GameCanvas.timeOpenKeyBoard++;
				if (GameCanvas.timeOpenKeyBoard > ((!Main.isWindowsPhone) ? 10 : 5))
				{
					mGraphics.addYWhenOpenKeyBoard = 94;
				}
			}
			else
			{
				mGraphics.addYWhenOpenKeyBoard = 0;
				GameCanvas.timeOpenKeyBoard = 0;
			}
			GameCanvas.debugUpdate.removeAllElements();
			long num = mSystem.currentTimeMillis();
			if (num - GameCanvas.timeTickEff1 >= 780L && !GameCanvas.isEff1)
			{
				GameCanvas.timeTickEff1 = num;
				GameCanvas.isEff1 = true;
			}
			else
			{
				GameCanvas.isEff1 = false;
			}
			if (num - GameCanvas.timeTickEff2 >= 7800L && !GameCanvas.isEff2)
			{
				GameCanvas.timeTickEff2 = num;
				GameCanvas.isEff2 = true;
			}
			else
			{
				GameCanvas.isEff2 = false;
			}
			if (GameCanvas.taskTick > 0)
			{
				GameCanvas.taskTick--;
			}
			GameCanvas.gameTick++;
			if (GameCanvas.gameTick > 10000)
			{
				if (mSystem.currentTimeMillis() - GameCanvas.lastTimePress > 20000L && GameCanvas.currentScreen == GameCanvas.loginScr)
				{
					GameMidlet.instance.exit();
				}
				GameCanvas.gameTick = 0;
			}
			if (GameCanvas.currentScreen != null)
			{
				if (ChatPopup.serverChatPopUp != null)
				{
					ChatPopup.serverChatPopUp.update();
					ChatPopup.serverChatPopUp.updateKey();
				}
				else if (ChatPopup.currChatPopup != null)
				{
					ChatPopup.currChatPopup.update();
					ChatPopup.currChatPopup.updateKey();
				}
				else if (GameCanvas.currentDialog != null)
				{
					GameCanvas.debug("B", 0);
					GameCanvas.currentDialog.update();
				}
				else if (GameCanvas.menu.showMenu)
				{
					GameCanvas.debug("C", 0);
					GameCanvas.menu.updateMenu();
					GameCanvas.debug("D", 0);
					GameCanvas.menu.updateMenuKey();
				}
				else if (GameCanvas.panel.isShow)
				{
					GameCanvas.panel.update();
					if (GameCanvas.panel2 != null)
					{
						if (GameCanvas.isFocusPanel2)
						{
							GameCanvas.panel2.updateKey();
						}
						else
						{
							GameCanvas.panel.updateKey();
						}
						if (GameCanvas.panel2.isShow)
						{
							GameCanvas.panel2.update();
							if (GameCanvas.isPointer(GameCanvas.panel2.X, GameCanvas.panel2.Y, GameCanvas.panel2.W, GameCanvas.panel2.H))
							{
								GameCanvas.panel2.updateKey();
							}
						}
					}
					else
					{
						GameCanvas.panel.updateKey();
					}
					if (GameCanvas.panel.chatTField != null && GameCanvas.panel.chatTField.isShow)
					{
						GameCanvas.panel.chatTFUpdateKey();
					}
					else if (GameCanvas.panel2 != null && GameCanvas.panel2.chatTField != null && GameCanvas.panel2.chatTField.isShow)
					{
						GameCanvas.panel2.chatTFUpdateKey();
					}
					if (GameCanvas.isPointer(GameCanvas.panel.X + GameCanvas.panel.W, GameCanvas.panel.Y, GameCanvas.w - GameCanvas.panel.W * 2, GameCanvas.panel.H) && GameCanvas.isPointerJustRelease && GameCanvas.panel.isDoneCombine)
					{
						GameCanvas.panel.hide();
					}
				}
				GameCanvas.debug("E", 0);
				if (!GameCanvas.isLoading)
				{
					GameCanvas.currentScreen.update();
				}
				GameCanvas.debug("F", 0);
				if (!GameCanvas.panel.isShow && ChatPopup.serverChatPopUp == null)
				{
					GameCanvas.currentScreen.updateKey();
				}
				Hint.update();
				SoundMn.gI().update();
			}
			GameCanvas.debug("Ix", 0);
			Timer.update();
			GameCanvas.debug("Hx", 0);
			InfoDlg.update();
			GameCanvas.debug("G", 0);
			if (this.resetToLoginScr)
			{
				this.resetToLoginScr = false;
				this.doResetToLoginScr(GameCanvas.serverScreen);
			}
			GameCanvas.debug("Zzz", 0);
			if (Controller.isConnectOK)
			{
				if (Controller.isMain)
				{
					GameMidlet.IP = ServerListScreen.address[ServerListScreen.ipSelect];
					GameMidlet.PORT = (int)ServerListScreen.port[ServerListScreen.ipSelect];
					Cout.println("Connect ok");
					ServerListScreen.testConnect = 2;
					Rms.saveRMSInt("svselect", ServerListScreen.ipSelect);
					Rms.saveIP(GameMidlet.IP + ":" + GameMidlet.PORT);
					Service.gI().setClientType();
					Service.gI().androidPack();
				}
				else
				{
					Service.gI().setClientType2();
					Service.gI().androidPack2();
				}
				Controller.isConnectOK = false;
			}
			if (Controller.isDisconnected)
			{
				Debug.Log("disconnect");
				if (!Controller.isMain)
				{
					if (GameCanvas.currentScreen == GameCanvas.serverScreen && !Service.reciveFromMainSession)
					{
						GameCanvas.serverScreen.cancel();
					}
					if (GameCanvas.currentScreen == GameCanvas.loginScr && !Service.reciveFromMainSession)
					{
						this.onDisconnected();
					}
				}
				else
				{
					this.onDisconnected();
				}
				Controller.isDisconnected = false;
			}
			if (Controller.isConnectionFail)
			{
				Debug.Log("connect fail");
				if (!Controller.isMain)
				{
					if (GameCanvas.currentScreen == GameCanvas.serverScreen && ServerListScreen.isGetData && !Service.reciveFromMainSession)
					{
						GameCanvas.serverScreen.cancel();
					}
					if (GameCanvas.currentScreen == GameCanvas.loginScr && !Service.reciveFromMainSession)
					{
						this.onConnectionFail();
					}
				}
				else
				{
					this.onConnectionFail();
				}
				Controller.isConnectionFail = false;
			}
			if (Main.isResume)
			{
				Main.isResume = false;
				if (GameCanvas.currentDialog != null && GameCanvas.currentDialog.left != null && GameCanvas.currentDialog.left.actionListener != null)
				{
					GameCanvas.currentDialog.left.performAction();
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x000845EC File Offset: 0x000827EC
	public void onDisconnected()
	{
		if (Controller.isConnectionFail)
		{
			Controller.isConnectionFail = false;
		}
		GameCanvas.isResume = true;
		Session_ME.gI().clearSendingMessage();
		Session_ME2.gI().clearSendingMessage();
		if (Controller.isLoadingData)
		{
			GameCanvas.instance.resetToLoginScrz();
			GameCanvas.startOK(mResources.pls_restart_game_error, 8885, null);
			Controller.isDisconnected = false;
			return;
		}
		global::Char.isLoadingMap = false;
		if (Controller.isMain)
		{
			ServerListScreen.testConnect = 0;
		}
		GameCanvas.instance.resetToLoginScrz();
		if (Main.typeClient == 6)
		{
			if (GameCanvas.currentScreen != GameCanvas.serverScreen && GameCanvas.currentScreen != GameCanvas.loginScr)
			{
				GameCanvas.startOKDlg(mResources.maychutathoacmatsong);
			}
		}
		else
		{
			GameCanvas.startOKDlg(mResources.maychutathoacmatsong);
		}
		mSystem.endKey();
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x000846B8 File Offset: 0x000828B8
	public void onConnectionFail()
	{
		if (GameCanvas.currentScreen.Equals(SplashScr.instance))
		{
			if (ServerListScreen.hasConnected != null)
			{
				if (!ServerListScreen.hasConnected[0])
				{
					ServerListScreen.hasConnected[0] = true;
					ServerListScreen.ipSelect = 0;
					GameMidlet.IP = ServerListScreen.address[ServerListScreen.ipSelect];
					Rms.saveRMSInt("svselect", ServerListScreen.ipSelect);
					GameCanvas.connect();
				}
				else if (!ServerListScreen.hasConnected[2])
				{
					ServerListScreen.hasConnected[2] = true;
					ServerListScreen.ipSelect = 2;
					GameMidlet.IP = ServerListScreen.address[ServerListScreen.ipSelect];
					Rms.saveRMSInt("svselect", ServerListScreen.ipSelect);
					GameCanvas.connect();
				}
				else
				{
					GameCanvas.startOK(mResources.pls_restart_game_error, 8885, null);
				}
			}
			else
			{
				GameCanvas.startOK(mResources.pls_restart_game_error, 8885, null);
			}
			return;
		}
		Session_ME.gI().clearSendingMessage();
		Session_ME2.gI().clearSendingMessage();
		ServerListScreen.isWait = false;
		if (Controller.isLoadingData)
		{
			GameCanvas.startOK(mResources.pls_restart_game_error, 8885, null);
			Controller.isConnectionFail = false;
			return;
		}
		GameCanvas.isResume = true;
		LoginScr.isContinueToLogin = false;
		if (GameCanvas.loginScr != null)
		{
			GameCanvas.instance.resetToLoginScrz();
		}
		else
		{
			GameCanvas.loginScr = new LoginScr();
		}
		LoginScr.serverName = ServerListScreen.nameServer[ServerListScreen.ipSelect];
		if (GameCanvas.currentScreen != GameCanvas.serverScreen)
		{
			GameCanvas.startOK(mResources.lost_connection + LoginScr.serverName, 888395, null);
		}
		else
		{
			GameCanvas.endDlg();
		}
		global::Char.isLoadingMap = false;
		if (Controller.isMain)
		{
			ServerListScreen.testConnect = 0;
		}
		mSystem.endKey();
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x00084858 File Offset: 0x00082A58
	public static bool isWaiting()
	{
		return InfoDlg.isShow || (GameCanvas.msgdlg != null && GameCanvas.msgdlg.info.Equals(mResources.PLEASEWAIT)) || global::Char.isLoadingMap || LoginScr.isContinueToLogin;
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x00007088 File Offset: 0x00005288
	public static void connect()
	{
		if (!Session_ME.gI().isConnected())
		{
			Session_ME.gI().connect(GameMidlet.IP, GameMidlet.PORT);
		}
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x000848AC File Offset: 0x00082AAC
	public static void connect2()
	{
		if (!Session_ME2.gI().isConnected())
		{
			Res.outz(string.Concat(new object[]
			{
				"IP2= ",
				GameMidlet.IP2,
				" PORT 2= ",
				GameMidlet.PORT2
			}));
			Session_ME2.gI().connect(GameMidlet.IP2, GameMidlet.PORT2);
		}
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x000070AD File Offset: 0x000052AD
	public static void resetTrans(mGraphics g)
	{
		g.translate(-g.getTranslateX(), -g.getTranslateY());
		g.setClip(0, 0, GameCanvas.w, GameCanvas.h);
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x00084914 File Offset: 0x00082B14
	public void initGameCanvas()
	{
		GameCanvas.debug("SP2i1", 0);
		GameCanvas.w = MotherCanvas.instance.getWidthz();
		GameCanvas.h = MotherCanvas.instance.getHeightz();
		GameCanvas.debug("SP2i2", 0);
		GameCanvas.hw = GameCanvas.w / 2;
		GameCanvas.hh = GameCanvas.h / 2;
		GameCanvas.wd3 = GameCanvas.w / 3;
		GameCanvas.hd3 = GameCanvas.h / 3;
		GameCanvas.w2d3 = 2 * GameCanvas.w / 3;
		GameCanvas.h2d3 = 2 * GameCanvas.h / 3;
		GameCanvas.w3d4 = 3 * GameCanvas.w / 4;
		GameCanvas.h3d4 = 3 * GameCanvas.h / 4;
		GameCanvas.wd6 = GameCanvas.w / 6;
		GameCanvas.hd6 = GameCanvas.h / 6;
		GameCanvas.debug("SP2i3", 0);
		mScreen.initPos();
		GameCanvas.debug("SP2i4", 0);
		GameCanvas.debug("SP2i5", 0);
		GameCanvas.inputDlg = new InputDlg();
		GameCanvas.debug("SP2i6", 0);
		GameCanvas.listPoint = new MyVector();
		GameCanvas.debug("SP2i7", 0);
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x000031FC File Offset: 0x000013FC
	public void start()
	{
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x000070D5 File Offset: 0x000052D5
	public int getWidth()
	{
		return (int)ScaleGUI.WIDTH;
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x000070DD File Offset: 0x000052DD
	public int getHeight()
	{
		return (int)ScaleGUI.HEIGHT;
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x000031FC File Offset: 0x000013FC
	public static void debug(string s, int type)
	{
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x00084A28 File Offset: 0x00082C28
	public void doResetToLoginScr(mScreen screen)
	{
		try
		{
			SoundMn.gI().stopAll();
			LoginScr.isContinueToLogin = false;
			TileMap.lastType = (TileMap.bgType = 0);
			global::Char.clearMyChar();
			GameScr.clearGameScr();
			GameScr.resetAllvector();
			InfoDlg.hide();
			GameScr.info1.hide();
			GameScr.info2.hide();
			GameScr.info2.cmdChat = null;
			Hint.isShow = false;
			ChatPopup.currChatPopup = null;
			Controller.isStopReadMessage = false;
			GameScr.loadCamera(true, -1, -1);
			GameScr.cmx = 100;
			GameCanvas.panel.currentTabIndex = 0;
			GameCanvas.panel.selected = ((!GameCanvas.isTouch) ? 0 : -1);
			GameCanvas.panel.init();
			GameCanvas.panel2 = null;
			GameScr.isPaint = true;
			ClanMessage.vMessage.removeAllElements();
			GameScr.textTime.removeAllElements();
			GameScr.vClan.removeAllElements();
			GameScr.vFriend.removeAllElements();
			GameScr.vEnemies.removeAllElements();
			TileMap.vCurrItem.removeAllElements();
			BackgroudEffect.vBgEffect.removeAllElements();
			EffecMn.vEff.removeAllElements();
			Effect.newEff.removeAllElements();
			GameCanvas.menu.showMenu = false;
			GameCanvas.panel.vItemCombine.removeAllElements();
			GameCanvas.panel.isShow = false;
			if (GameCanvas.panel.tabIcon != null)
			{
				GameCanvas.panel.tabIcon.isShow = false;
			}
			if (mGraphics.zoomLevel == 1)
			{
				SmallImage.clearHastable();
			}
			Session_ME.gI().close();
			Session_ME2.gI().close();
			screen.switchToMe();
		}
		catch (Exception ex)
		{
			Cout.println("Loi tai doResetToLoginScr " + ex.ToString());
		}
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x000031FC File Offset: 0x000013FC
	public static void showErrorForm(int type, string moreInfo)
	{
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x000031FC File Offset: 0x000013FC
	public static void paintCloud(mGraphics g)
	{
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x000031FC File Offset: 0x000013FC
	public static void updateBG()
	{
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00084BE8 File Offset: 0x00082DE8
	public static void fillRect(mGraphics g, int color, int x, int y, int w, int h, int detalY)
	{
		g.setColor(color);
		int cmy = GameScr.cmy;
		if (cmy > GameCanvas.h)
		{
			cmy = GameCanvas.h;
		}
		g.fillRect(x, y - ((detalY == 0) ? 0 : (cmy >> detalY)), w, h + ((detalY == 0) ? 0 : (cmy >> detalY)));
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x00084C4C File Offset: 0x00082E4C
	public static void paintBackgroundtLayer(mGraphics g, int layer, int deltaY, int color1, int color2)
	{
		try
		{
			int num = layer - 1;
			if (num == GameCanvas.imgBG.Length - 1 && (GameScr.gI().isRongThanXuatHien || GameScr.gI().isFireWorks))
			{
				g.setColor(GameScr.gI().mautroi);
				g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
				if (GameCanvas.typeBg == 2 || GameCanvas.typeBg == 4 || GameCanvas.typeBg == 7)
				{
					GameCanvas.drawSun1(g);
					GameCanvas.drawSun2(g);
				}
				if (GameScr.gI().isFireWorks && !GameCanvas.lowGraphic)
				{
					FireWorkEff.paint(g);
				}
			}
			else if (GameCanvas.imgBG != null && GameCanvas.imgBG[num] != null)
			{
				if (GameCanvas.moveX[num] != 0)
				{
					GameCanvas.moveX[num] += GameCanvas.moveXSpeed[num];
				}
				int cmy = GameScr.cmy;
				if (cmy > GameCanvas.h)
				{
					cmy = GameCanvas.h;
				}
				if (GameCanvas.layerSpeed[num] != 0)
				{
					for (int i = -((GameScr.cmx + GameCanvas.moveX[num] >> GameCanvas.layerSpeed[num]) % GameCanvas.bgW[num]); i < GameScr.gW; i += GameCanvas.bgW[num])
					{
						g.drawImage(GameCanvas.imgBG[num], i, GameCanvas.yb[num] - ((deltaY <= 0) ? 0 : (cmy >> deltaY)), 0);
					}
				}
				else
				{
					for (int j = 0; j < GameScr.gW; j += GameCanvas.bgW[num])
					{
						g.drawImage(GameCanvas.imgBG[num], j, GameCanvas.yb[num] - ((deltaY <= 0) ? 0 : (cmy >> deltaY)), 0);
					}
				}
				if (color1 != -1)
				{
					if (num == GameCanvas.nBg - 1)
					{
						GameCanvas.fillRect(g, color1, 0, -(cmy >> deltaY), GameScr.gW, GameCanvas.yb[num], deltaY);
					}
					else
					{
						GameCanvas.fillRect(g, color1, 0, GameCanvas.yb[num - 1] + GameCanvas.bgH[num - 1], GameScr.gW, GameCanvas.yb[num] - (GameCanvas.yb[num - 1] + GameCanvas.bgH[num - 1]), deltaY);
					}
				}
				if (color2 != -1)
				{
					if (num == 0)
					{
						GameCanvas.fillRect(g, color2, 0, GameCanvas.yb[num] + GameCanvas.bgH[num], GameScr.gW, GameScr.gH - (GameCanvas.yb[num] + GameCanvas.bgH[num]), deltaY);
					}
					else
					{
						GameCanvas.fillRect(g, color2, 0, GameCanvas.yb[num] + GameCanvas.bgH[num], GameScr.gW, GameCanvas.yb[num - 1] - (GameCanvas.yb[num] + GameCanvas.bgH[num]) + 80, deltaY);
					}
				}
				if (GameCanvas.currentScreen == GameScr.instance)
				{
					if (layer == 1 && GameCanvas.typeBg == 11)
					{
						g.drawImage(GameCanvas.imgSun2, -(GameScr.cmx >> GameCanvas.layerSpeed[0]) + 400, GameCanvas.yb[0] + 30 - (cmy >> 2), StaticObj.BOTTOM_HCENTER);
					}
					if (layer == 1 && GameCanvas.typeBg == 13)
					{
						g.drawImage(GameCanvas.imgBG[1], -(GameScr.cmx >> GameCanvas.layerSpeed[0]) + 200, GameCanvas.yb[0] - (cmy >> 3) + 30, 0);
						g.drawRegion(GameCanvas.imgBG[1], 0, 0, GameCanvas.bgW[1], GameCanvas.bgH[1], 2, -(GameScr.cmx >> GameCanvas.layerSpeed[0]) + 200 + GameCanvas.bgW[1], GameCanvas.yb[0] - (cmy >> 3) + 30, 0);
					}
					if (layer == 3 && TileMap.mapID == 1)
					{
						for (int k = 0; k < TileMap.pxh / mGraphics.getImageHeight(GameCanvas.imgCaycot); k++)
						{
							g.drawImage(GameCanvas.imgCaycot, -(GameScr.cmx >> GameCanvas.layerSpeed[2]) + 300, k * mGraphics.getImageHeight(GameCanvas.imgCaycot) - (cmy >> 3), 0);
						}
					}
				}
				int x = -(GameScr.cmx + GameCanvas.moveX[num] >> GameCanvas.layerSpeed[num]);
				EffecMn.paintBackGroundUnderLayer(g, x, GameCanvas.yb[num] + GameCanvas.bgH[num] - (cmy >> deltaY), num);
			}
		}
		catch (Exception ex)
		{
			Cout.LogError("Loi ham paint bground: " + ex.ToString());
		}
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x000850C8 File Offset: 0x000832C8
	public static void drawSun1(mGraphics g)
	{
		if (GameCanvas.imgSun != null)
		{
			g.drawImage(GameCanvas.imgSun, GameCanvas.sunX, GameCanvas.sunY, 0);
		}
		if (GameCanvas.isBoltEff)
		{
			if (GameCanvas.gameTick % 200 == 0)
			{
				GameCanvas.boltActive = true;
			}
			if (GameCanvas.boltActive)
			{
				GameCanvas.tBolt++;
				if (GameCanvas.tBolt == 10)
				{
					GameCanvas.tBolt = 0;
					GameCanvas.boltActive = false;
				}
				if (GameCanvas.tBolt % 2 == 0)
				{
					g.setColor(16777215);
					g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
				}
			}
		}
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x000031FC File Offset: 0x000013FC
	public static void drawSun2(mGraphics g)
	{
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x000070E5 File Offset: 0x000052E5
	public static bool isHDVersion()
	{
		return mGraphics.zoomLevel > 1;
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x0008516C File Offset: 0x0008336C
	public static void paintBGGameScr(mGraphics g)
	{
		if (!GameCanvas.isLoadBGok)
		{
			g.setColor(0);
			g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
		}
		if (global::Char.isLoadingMap)
		{
			return;
		}
		int gW = GameScr.gW;
		int gH = GameScr.gH;
		g.translate(-g.getTranslateX(), -g.getTranslateY());
		if (GameCanvas.paintBG)
		{
			if (GameCanvas.currentScreen == GameScr.gI())
			{
				if (TileMap.mapID == 137 || TileMap.mapID == 115 || TileMap.mapID == 117 || TileMap.mapID == 118 || TileMap.mapID == 120)
				{
					g.setColor(0);
					g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
					return;
				}
				if (TileMap.mapID == 138)
				{
					g.setColor(6776679);
					g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
					return;
				}
			}
			if (GameCanvas.typeBg == 0)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 6, GameCanvas.colorTop[3], GameCanvas.colorBotton[3]);
				GameCanvas.paintBackgroundtLayer(g, 3, 4, -1, GameCanvas.colorBotton[2]);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 1)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 6, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 3, 3, -1, -1);
				GameCanvas.fillRect(g, GameCanvas.colorTop[2], 0, -(GameScr.cmy >> 5), gW, GameCanvas.yb[2], 5);
				GameCanvas.fillRect(g, GameCanvas.colorBotton[2], 0, GameCanvas.yb[2] + GameCanvas.bgH[2] - (GameScr.cmy >> 3), gW, 70, 3);
				GameCanvas.paintBackgroundtLayer(g, 2, 2, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 1, 1, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 2)
			{
				GameCanvas.paintBackgroundtLayer(g, 5, 10, GameCanvas.colorTop[4], GameCanvas.colorBotton[4]);
				GameCanvas.paintBackgroundtLayer(g, 4, 8, -1, GameCanvas.colorTop[2]);
				GameCanvas.paintBackgroundtLayer(g, 3, 5, -1, GameCanvas.colorBotton[2]);
				GameCanvas.paintBackgroundtLayer(g, 2, 2, -1, GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 1, -1, GameCanvas.colorBotton[0]);
				GameCanvas.paintCloud(g);
			}
			if (GameCanvas.typeBg == 3)
			{
				int num = GameScr.cmy - (325 - GameScr.gH23);
				g.translate(0, -num);
				GameCanvas.fillRect(g, (!GameScr.gI().isRongThanXuatHien && !GameScr.gI().isFireWorks) ? GameCanvas.colorTop[2] : GameScr.gI().mautroi, 0, num - (GameScr.cmy >> 3), gW, GameCanvas.yb[2] - num + (GameScr.cmy >> 3) + 100, 2);
				GameCanvas.paintBackgroundtLayer(g, 3, 2, -1, GameCanvas.colorBotton[2]);
				GameCanvas.paintBackgroundtLayer(g, 2, 0, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 1, 0, -1, GameCanvas.colorBotton[0]);
				g.translate(0, -g.getTranslateY());
			}
			if (GameCanvas.typeBg == 4)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 7, GameCanvas.colorTop[3], -1);
				GameCanvas.paintBackgroundtLayer(g, 3, 3, -1, (!GameCanvas.isHDVersion()) ? GameCanvas.colorTop[1] : GameCanvas.colorBotton[2]);
				GameCanvas.paintBackgroundtLayer(g, 2, 2, GameCanvas.colorTop[1], GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 1, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 5)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 15, GameCanvas.colorTop[3], -1);
				GameCanvas.drawSun1(g);
				g.translate(100, 10);
				GameCanvas.drawSun1(g);
				g.translate(-100, -10);
				GameCanvas.drawSun2(g);
				GameCanvas.paintBackgroundtLayer(g, 3, 10, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 2, 6, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 1, 4, -1, -1);
				g.translate(0, 27);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, -1);
				g.translate(0, 20);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
				g.translate(-g.getTranslateX(), -g.getTranslateY());
			}
			if (GameCanvas.typeBg == 6)
			{
				GameCanvas.paintBackgroundtLayer(g, 5, 10, GameCanvas.colorTop[4], GameCanvas.colorBotton[4]);
				GameCanvas.drawSun1(g);
				GameCanvas.drawSun2(g);
				g.translate(60, 40);
				GameCanvas.drawSun2(g);
				g.translate(-60, -40);
				GameCanvas.paintBackgroundtLayer(g, 4, 7, -1, GameCanvas.colorBotton[3]);
				BackgroudEffect.paintFarAll(g);
				GameCanvas.paintBackgroundtLayer(g, 3, 4, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 7)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 6, GameCanvas.colorTop[3], GameCanvas.colorBotton[3]);
				GameCanvas.paintBackgroundtLayer(g, 3, 5, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 2, 4, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 1, 3, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 8)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 8, GameCanvas.colorTop[3], GameCanvas.colorBotton[3]);
				GameCanvas.drawSun1(g);
				GameCanvas.drawSun2(g);
				GameCanvas.paintBackgroundtLayer(g, 3, 4, -1, GameCanvas.colorBotton[2]);
				GameCanvas.paintBackgroundtLayer(g, 2, 2, -1, GameCanvas.colorBotton[1]);
				if (((TileMap.mapID < 92 || TileMap.mapID > 96) && TileMap.mapID != 51 && TileMap.mapID != 52) || GameCanvas.currentScreen == GameCanvas.loginScr)
				{
					GameCanvas.paintBackgroundtLayer(g, 1, 1, -1, GameCanvas.colorBotton[0]);
				}
			}
			if (GameCanvas.typeBg == 9)
			{
				GameCanvas.paintBackgroundtLayer(g, 4, 8, GameCanvas.colorTop[3], GameCanvas.colorBotton[3]);
				GameCanvas.drawSun1(g);
				GameCanvas.drawSun2(g);
				g.translate(-80, 20);
				GameCanvas.drawSun2(g);
				g.translate(80, -20);
				BackgroudEffect.paintFarAll(g);
				GameCanvas.paintBackgroundtLayer(g, 3, 5, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, -1);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 10)
			{
				int num2 = GameScr.cmy - (380 - GameScr.gH23);
				g.translate(0, -num2);
				GameCanvas.fillRect(g, (!GameScr.gI().isRongThanXuatHien) ? GameCanvas.colorTop[1] : GameScr.gI().mautroi, 0, num2 - (GameScr.cmy >> 2), gW, GameCanvas.yb[1] - num2 + (GameScr.cmy >> 2) + 100, 2);
				GameCanvas.paintBackgroundtLayer(g, 2, 2, -1, GameCanvas.colorBotton[1]);
				GameCanvas.drawSun1(g);
				GameCanvas.drawSun2(g);
				GameCanvas.paintBackgroundtLayer(g, 1, 0, -1, -1);
				g.translate(0, -g.getTranslateY());
			}
			if (GameCanvas.typeBg == 11)
			{
				GameCanvas.paintBackgroundtLayer(g, 3, 6, GameCanvas.colorTop[2], GameCanvas.colorBotton[2]);
				GameCanvas.drawSun1(g);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
			}
			if (GameCanvas.typeBg == 12)
			{
				g.setColor(9161471);
				g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
				GameCanvas.paintBackgroundtLayer(g, 3, 4, -1, 14417919);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, 14417919);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, 14417919);
				GameCanvas.paintCloud(g);
			}
			if (GameCanvas.typeBg == 13)
			{
				g.setColor(15268088);
				g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
				GameCanvas.paintBackgroundtLayer(g, 1, 5, -1, 15268088);
			}
			if (GameCanvas.typeBg == 15)
			{
				g.setColor(2631752);
				g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
				GameCanvas.paintBackgroundtLayer(g, 2, 3, -1, GameCanvas.colorBotton[1]);
				GameCanvas.paintBackgroundtLayer(g, 1, 2, -1, GameCanvas.colorBotton[0]);
			}
		}
		else
		{
			g.setColor(2315859);
			g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
			if (GameCanvas.tam != null)
			{
				for (int i = -((GameScr.cmx >> 2) % mGraphics.getImageWidth(GameCanvas.tam)); i < GameScr.gW; i += mGraphics.getImageWidth(GameCanvas.tam))
				{
					g.drawImage(GameCanvas.tam, i, (GameScr.cmy >> 3) + GameCanvas.h / 2 - 50, 0);
				}
			}
			g.setColor(5084791);
			g.fillRect(0, (GameScr.cmy >> 3) + GameCanvas.h / 2 - 50 + mGraphics.getImageHeight(GameCanvas.tam), gW, GameCanvas.h);
		}
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x000031FC File Offset: 0x000013FC
	public static void resetBg()
	{
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x000859B8 File Offset: 0x00083BB8
	public static void getYBackground(int typeBg)
	{
		int gH = GameScr.gH23;
		switch (typeBg)
		{
		case 0:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 70;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 20;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 30;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3] + 50;
			break;
		case 1:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 120;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 40;
			GameCanvas.yb[2] = GameCanvas.yb[1] - 90;
			GameCanvas.yb[3] = GameCanvas.yb[2] - 25;
			break;
		case 2:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 150;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] - 60;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 40;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3] - 10;
			GameCanvas.yb[4] = GameCanvas.yb[3] - GameCanvas.bgH[4];
			break;
		case 3:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 10;
			GameCanvas.yb[1] = GameCanvas.yb[0] + 80;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 10;
			break;
		case 4:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 130;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1];
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 20;
			GameCanvas.yb[3] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 80;
			break;
		case 5:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 40;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 10;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 15;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3] + 50;
			break;
		case 6:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 100;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] - 30;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 10;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3] + 15;
			GameCanvas.yb[4] = GameCanvas.yb[3] - GameCanvas.bgH[4] + 15;
			break;
		case 7:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 20;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 15;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 20;
			GameCanvas.yb[3] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 10;
			break;
		case 8:
			GameCanvas.yb[0] = gH - 103 + 150;
			if (TileMap.mapID == 103)
			{
				GameCanvas.yb[0] -= 100;
			}
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] - 10;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 40;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3] + 10;
			break;
		case 9:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 100;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 22;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] + 50;
			GameCanvas.yb[3] = GameCanvas.yb[2] - GameCanvas.bgH[3];
			break;
		case 10:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] - 45;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] - 10;
			break;
		case 11:
			GameCanvas.yb[0] = gH - GameCanvas.bgH[0] + 60;
			GameCanvas.yb[1] = GameCanvas.yb[0] - GameCanvas.bgH[1] + 5;
			GameCanvas.yb[2] = GameCanvas.yb[1] - GameCanvas.bgH[2] - 15;
			break;
		case 12:
			GameCanvas.yb[0] = gH + 40;
			GameCanvas.yb[1] = GameCanvas.yb[0] - 40;
			GameCanvas.yb[2] = GameCanvas.yb[1] - 40;
			break;
		case 13:
			GameCanvas.yb[0] = gH - 80;
			GameCanvas.yb[1] = GameCanvas.yb[0];
			break;
		case 15:
			GameCanvas.yb[0] = gH - 20;
			GameCanvas.yb[1] = GameCanvas.yb[0] - 80;
			break;
		}
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00085EFC File Offset: 0x000840FC
	public static void loadBG(int typeBG)
	{
		try
		{
			GameCanvas.isLoadBGok = true;
			if (GameCanvas.typeBg == 12)
			{
				BackgroudEffect.yfog = TileMap.pxh - 100;
			}
			else
			{
				BackgroudEffect.yfog = TileMap.pxh - 160;
			}
			BackgroudEffect.clearImage();
			GameCanvas.randomRaintEff(typeBG);
			if ((TileMap.lastBgID != typeBG || TileMap.lastType != TileMap.bgType) && typeBG != -1)
			{
				GameCanvas.transY = 12;
				TileMap.lastBgID = (int)((sbyte)typeBG);
				TileMap.lastType = (int)((sbyte)TileMap.bgType);
				GameCanvas.layerSpeed = new int[]
				{
					1,
					2,
					3,
					7,
					8
				};
				GameCanvas.moveX = new int[5];
				GameCanvas.moveXSpeed = new int[5];
				GameCanvas.typeBg = typeBG;
				GameCanvas.isBoltEff = false;
				GameScr.firstY = GameScr.cmy;
				GameCanvas.imgBG = null;
				GameCanvas.imgCloud = null;
				GameCanvas.imgSun = null;
				GameCanvas.imgCaycot = null;
				GameScr.firstY = -1;
				switch (GameCanvas.typeBg)
				{
				case 0:
					GameCanvas.imgCaycot = GameCanvas.loadImageRMS("/bg/caycot.png");
					GameCanvas.layerSpeed = new int[]
					{
						1,
						3,
						5,
						7
					};
					GameCanvas.nBg = 4;
					if (TileMap.bgType == 2)
					{
						GameCanvas.transY = 8;
					}
					break;
				case 1:
					GameCanvas.transY = 7;
					GameCanvas.nBg = 4;
					break;
				case 2:
				{
					int[] array = new int[5];
					array[2] = 1;
					GameCanvas.moveX = array;
					int[] array2 = new int[5];
					array2[2] = 2;
					GameCanvas.moveXSpeed = array2;
					GameCanvas.nBg = 5;
					break;
				}
				case 3:
					GameCanvas.nBg = 3;
					break;
				case 4:
				{
					BackgroudEffect.addEffect(3);
					int[] array3 = new int[5];
					array3[1] = 1;
					GameCanvas.moveX = array3;
					int[] array4 = new int[5];
					array4[1] = 1;
					GameCanvas.moveXSpeed = array4;
					GameCanvas.nBg = 4;
					break;
				}
				case 5:
					GameCanvas.nBg = 4;
					break;
				case 6:
				{
					int[] array5 = new int[5];
					array5[0] = 1;
					GameCanvas.moveX = array5;
					int[] array6 = new int[5];
					array6[0] = 2;
					GameCanvas.moveXSpeed = array6;
					GameCanvas.nBg = 5;
					break;
				}
				case 7:
					GameCanvas.nBg = 4;
					break;
				case 8:
					GameCanvas.transY = 8;
					GameCanvas.nBg = 4;
					break;
				case 9:
					BackgroudEffect.addEffect(9);
					GameCanvas.nBg = 4;
					break;
				case 10:
					GameCanvas.nBg = 2;
					break;
				case 11:
					GameCanvas.transY = 7;
					GameCanvas.layerSpeed[2] = 0;
					GameCanvas.nBg = 3;
					break;
				case 12:
				{
					int[] array7 = new int[5];
					array7[0] = 1;
					array7[1] = 1;
					GameCanvas.moveX = array7;
					int[] array8 = new int[5];
					array8[0] = 2;
					array8[1] = 1;
					GameCanvas.moveXSpeed = array8;
					GameCanvas.nBg = 3;
					break;
				}
				case 13:
					GameCanvas.nBg = 2;
					break;
				case 15:
					Res.outz("HELL");
					GameCanvas.nBg = 2;
					break;
				}
				GameCanvas.skyColor = StaticObj.SKYCOLOR[GameCanvas.typeBg];
				if (GameCanvas.lowGraphic)
				{
					GameCanvas.tam = GameCanvas.loadImageRMS("/bg/b63.png");
				}
				else
				{
					GameCanvas.imgBG = new Image[GameCanvas.nBg];
					GameCanvas.bgW = new int[GameCanvas.nBg];
					GameCanvas.bgH = new int[GameCanvas.nBg];
					GameCanvas.colorBotton = new int[GameCanvas.nBg];
					GameCanvas.colorTop = new int[GameCanvas.nBg];
					if (TileMap.bgType == 100)
					{
						GameCanvas.imgBG[0] = GameCanvas.loadImageRMS("/bg/b100.png");
						GameCanvas.imgBG[1] = GameCanvas.loadImageRMS("/bg/b100.png");
						GameCanvas.imgBG[2] = GameCanvas.loadImageRMS("/bg/b82-1.png");
						GameCanvas.imgBG[3] = GameCanvas.loadImageRMS("/bg/b93.png");
						for (int i = 0; i < GameCanvas.nBg; i++)
						{
							if (GameCanvas.imgBG[i] != null)
							{
								int[] array9 = new int[1];
								GameCanvas.imgBG[i].getRGB(ref array9, 0, 1, mGraphics.getRealImageWidth(GameCanvas.imgBG[i]) / 2, 0, 1, 1);
								GameCanvas.colorTop[i] = array9[0];
								array9 = new int[1];
								GameCanvas.imgBG[i].getRGB(ref array9, 0, 1, mGraphics.getRealImageWidth(GameCanvas.imgBG[i]) / 2, mGraphics.getRealImageHeight(GameCanvas.imgBG[i]) - 1, 1, 1);
								GameCanvas.colorBotton[i] = array9[0];
								GameCanvas.bgW[i] = mGraphics.getImageWidth(GameCanvas.imgBG[i]);
								GameCanvas.bgH[i] = mGraphics.getImageHeight(GameCanvas.imgBG[i]);
							}
							else if (GameCanvas.nBg > 1)
							{
								GameCanvas.imgBG[i] = GameCanvas.loadImageRMS("/bg/b" + GameCanvas.typeBg + "0.png");
								GameCanvas.bgW[i] = mGraphics.getImageWidth(GameCanvas.imgBG[i]);
								GameCanvas.bgH[i] = mGraphics.getImageHeight(GameCanvas.imgBG[i]);
							}
						}
					}
					else
					{
						for (int j = 0; j < GameCanvas.nBg; j++)
						{
							if (TileMap.bgType == 0)
							{
								GameCanvas.imgBG[j] = GameCanvas.loadImageRMS(string.Concat(new object[]
								{
									"/bg/b",
									GameCanvas.typeBg,
									j,
									".png"
								}));
							}
							else
							{
								Res.outz(string.Concat(new object[]
								{
									"link type= /bg/b",
									GameCanvas.typeBg,
									j,
									"-",
									TileMap.bgType,
									".png"
								}));
								GameCanvas.imgBG[j] = GameCanvas.loadImageRMS(string.Concat(new object[]
								{
									"/bg/b",
									GameCanvas.typeBg,
									j,
									"-",
									TileMap.bgType,
									".png"
								}));
							}
							if (GameCanvas.imgBG[j] != null)
							{
								int[] array10 = new int[1];
								GameCanvas.imgBG[j].getRGB(ref array10, 0, 1, mGraphics.getRealImageWidth(GameCanvas.imgBG[j]) / 2, 0, 1, 1);
								GameCanvas.colorTop[j] = array10[0];
								array10 = new int[1];
								GameCanvas.imgBG[j].getRGB(ref array10, 0, 1, mGraphics.getRealImageWidth(GameCanvas.imgBG[j]) / 2, mGraphics.getRealImageHeight(GameCanvas.imgBG[j]) - 1, 1, 1);
								GameCanvas.colorBotton[j] = array10[0];
								GameCanvas.bgW[j] = mGraphics.getImageWidth(GameCanvas.imgBG[j]);
								GameCanvas.bgH[j] = mGraphics.getImageHeight(GameCanvas.imgBG[j]);
							}
							else if (GameCanvas.nBg > 1)
							{
								GameCanvas.imgBG[j] = GameCanvas.loadImageRMS("/bg/b" + GameCanvas.typeBg + "0.png");
								GameCanvas.bgW[j] = mGraphics.getImageWidth(GameCanvas.imgBG[j]);
								GameCanvas.bgH[j] = mGraphics.getImageHeight(GameCanvas.imgBG[j]);
							}
						}
					}
					GameCanvas.getYBackground(GameCanvas.typeBg);
					GameCanvas.cloudX = new int[]
					{
						GameScr.gW / 2 - 40,
						GameScr.gW / 2 + 40,
						GameScr.gW / 2 - 100,
						GameScr.gW / 2 - 80,
						GameScr.gW / 2 - 120
					};
					GameCanvas.cloudY = new int[]
					{
						130,
						100,
						150,
						140,
						80
					};
					if (GameCanvas.typeBg != 0)
					{
						if (GameCanvas.typeBg == 2)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun0.png");
							GameCanvas.sunX = GameScr.gW / 2 + 50;
							GameCanvas.sunY = GameCanvas.yb[4] - 40;
						}
						else if (GameCanvas.typeBg == 4)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun2.png");
							GameCanvas.sunX = GameScr.gW / 2 + 30;
							GameCanvas.sunY = GameCanvas.yb[3];
						}
						else if (GameCanvas.typeBg == 7)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun3" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun4" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW - GameScr.gW / 3;
							GameCanvas.sunY = GameCanvas.yb[3] - 80;
							GameCanvas.sunX2 = GameCanvas.sunX - 100;
							GameCanvas.sunY2 = GameCanvas.yb[3] - 30;
						}
						else if (GameCanvas.typeBg == 6)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun5" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun6" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW - GameScr.gW / 3;
							GameCanvas.sunY = GameCanvas.yb[4];
							GameCanvas.sunX2 = GameCanvas.sunX - 100;
							GameCanvas.sunY2 = GameCanvas.yb[4] + 20;
						}
						else if (typeBG == 5)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun8" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun7" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW / 2 - 50;
							GameCanvas.sunY = GameCanvas.yb[3] + 20;
							GameCanvas.sunX2 = GameScr.gW / 2 + 20;
							GameCanvas.sunY2 = GameCanvas.yb[3] - 30;
						}
						else if (GameCanvas.typeBg == 8 && TileMap.mapID < 90)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun9" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun10" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW / 2 - 30;
							GameCanvas.sunY = GameCanvas.yb[3] + 60;
							GameCanvas.sunX2 = GameScr.gW / 2 + 20;
							GameCanvas.sunY2 = GameCanvas.yb[3] + 10;
						}
						else if (typeBG == 9)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun11" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun12" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW - GameScr.gW / 3;
							GameCanvas.sunY = GameCanvas.yb[4] + 20;
							GameCanvas.sunX2 = GameCanvas.sunX - 80;
							GameCanvas.sunY2 = GameCanvas.yb[4] + 40;
						}
						else if (typeBG == 10)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun13" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/sun14" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW - GameScr.gW / 3;
							GameCanvas.sunY = GameCanvas.yb[1] - 30;
							GameCanvas.sunX2 = GameCanvas.sunX - 80;
							GameCanvas.sunY2 = GameCanvas.yb[1];
						}
						else if (typeBG == 11)
						{
							GameCanvas.imgSun = GameCanvas.loadImageRMS("/bg/sun15" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.imgSun2 = GameCanvas.loadImageRMS("/bg/b113" + ((TileMap.bgType != 0) ? ("-" + TileMap.bgType) : string.Empty) + ".png");
							GameCanvas.sunX = GameScr.gW / 2 - 30;
							GameCanvas.sunY = GameCanvas.yb[2] - 30;
						}
						else if (typeBG == 12)
						{
							GameCanvas.cloudY = new int[]
							{
								200,
								170,
								220,
								150,
								250
							};
						}
						else
						{
							GameCanvas.imgCloud = null;
							GameCanvas.imgSun = null;
							GameCanvas.imgSun2 = null;
						}
					}
					GameCanvas.paintBG = false;
					if (!GameCanvas.paintBG)
					{
						GameCanvas.paintBG = true;
					}
				}
			}
		}
		catch (Exception ex)
		{
			GameCanvas.isLoadBGok = false;
		}
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x00086C98 File Offset: 0x00084E98
	private static void randomRaintEff(int typeBG)
	{
		for (int i = 0; i < GameCanvas.bgRain.Length; i++)
		{
			if (typeBG == GameCanvas.bgRain[i] && Res.random(0, 2) == 0)
			{
				BackgroudEffect.addEffect(0);
				break;
			}
		}
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00086CE4 File Offset: 0x00084EE4
	public void keyPressedz(int keyCode)
	{
		GameCanvas.lastTimePress = mSystem.currentTimeMillis();
		if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 122) || keyCode == 10 || keyCode == 8 || keyCode == 13 || keyCode == 32 || keyCode == 31)
		{
			GameCanvas.keyAsciiPress = keyCode;
		}
		this.mapKeyPress(keyCode);
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x00086D50 File Offset: 0x00084F50
	public void mapKeyPress(int keyCode)
	{
		if (GameCanvas.currentDialog != null)
		{
			GameCanvas.currentDialog.keyPress(keyCode);
			GameCanvas.keyAsciiPress = 0;
			return;
		}
		GameCanvas.currentScreen.keyPress(keyCode);
		switch (keyCode)
		{
		case 35:
			GameCanvas.keyHold[11] = true;
			GameCanvas.keyPressed[11] = true;
			return;
		default:
			switch (keyCode + 8)
			{
			case 0:
				GameCanvas.keyHold[14] = true;
				GameCanvas.keyPressed[14] = true;
				return;
			case 1:
				goto IL_31A;
			case 2:
				goto IL_307;
			case 3:
				goto IL_1EC;
			case 4:
				if (GameCanvas.currentScreen is GameScr && global::Char.myCharz().isAttack)
				{
					GameCanvas.clearKeyHold();
					GameCanvas.clearKeyPressed();
					return;
				}
				GameCanvas.keyHold[24] = true;
				GameCanvas.keyPressed[24] = true;
				return;
			case 5:
				if (GameCanvas.currentScreen is GameScr && global::Char.myCharz().isAttack)
				{
					GameCanvas.clearKeyHold();
					GameCanvas.clearKeyPressed();
					return;
				}
				GameCanvas.keyHold[23] = true;
				GameCanvas.keyPressed[23] = true;
				return;
			case 6:
				goto IL_138;
			case 7:
				break;
			default:
				switch (keyCode + 26)
				{
				case 0:
					GameCanvas.keyHold[16] = true;
					GameCanvas.keyPressed[16] = true;
					return;
				default:
					if (keyCode == -39)
					{
						goto IL_138;
					}
					if (keyCode != -38)
					{
						if (keyCode == 10)
						{
							goto IL_1EC;
						}
						if (keyCode != 113)
						{
							return;
						}
						GameCanvas.keyHold[17] = true;
						GameCanvas.keyPressed[17] = true;
						return;
					}
					break;
				case 4:
					goto IL_31A;
				case 5:
					goto IL_307;
				}
				break;
			}
			if (GameCanvas.currentScreen is GameScr && global::Char.myCharz().isAttack)
			{
				GameCanvas.clearKeyHold();
				GameCanvas.clearKeyPressed();
				return;
			}
			GameCanvas.keyHold[21] = true;
			GameCanvas.keyPressed[21] = true;
			return;
			IL_138:
			if (GameCanvas.currentScreen is GameScr && global::Char.myCharz().isAttack)
			{
				GameCanvas.clearKeyHold();
				GameCanvas.clearKeyPressed();
				return;
			}
			GameCanvas.keyHold[22] = true;
			GameCanvas.keyPressed[22] = true;
			return;
			IL_1EC:
			if (GameCanvas.currentScreen is GameScr && global::Char.myCharz().isAttack)
			{
				GameCanvas.clearKeyHold();
				GameCanvas.clearKeyPressed();
				return;
			}
			GameCanvas.keyHold[25] = true;
			GameCanvas.keyPressed[25] = true;
			GameCanvas.keyHold[15] = true;
			GameCanvas.keyPressed[15] = true;
			return;
			IL_307:
			GameCanvas.keyHold[12] = true;
			GameCanvas.keyPressed[12] = true;
			return;
			IL_31A:
			GameCanvas.keyHold[13] = true;
			GameCanvas.keyPressed[13] = true;
			return;
		case 42:
			GameCanvas.keyHold[10] = true;
			GameCanvas.keyPressed[10] = true;
			return;
		case 48:
			GameCanvas.keyHold[0] = true;
			GameCanvas.keyPressed[0] = true;
			return;
		case 49:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[1] = true;
				GameCanvas.keyPressed[1] = true;
			}
			return;
		case 50:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[2] = true;
				GameCanvas.keyPressed[2] = true;
			}
			return;
		case 51:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[3] = true;
				GameCanvas.keyPressed[3] = true;
			}
			return;
		case 52:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[4] = true;
				GameCanvas.keyPressed[4] = true;
			}
			return;
		case 53:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[5] = true;
				GameCanvas.keyPressed[5] = true;
			}
			return;
		case 54:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[6] = true;
				GameCanvas.keyPressed[6] = true;
			}
			return;
		case 55:
			GameCanvas.keyHold[7] = true;
			GameCanvas.keyPressed[7] = true;
			return;
		case 56:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[8] = true;
				GameCanvas.keyPressed[8] = true;
			}
			return;
		case 57:
			GameCanvas.keyHold[9] = true;
			GameCanvas.keyPressed[9] = true;
			return;
		}
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x000070F5 File Offset: 0x000052F5
	public void keyReleasedz(int keyCode)
	{
		GameCanvas.keyAsciiPress = 0;
		this.mapKeyRelease(keyCode);
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x000871EC File Offset: 0x000853EC
	public void mapKeyRelease(int keyCode)
	{
		switch (keyCode)
		{
		case 35:
			GameCanvas.keyHold[11] = false;
			GameCanvas.keyReleased[11] = true;
			return;
		default:
			switch (keyCode + 8)
			{
			case 0:
				GameCanvas.keyHold[14] = false;
				return;
			case 1:
				goto IL_202;
			case 2:
				goto IL_1EF;
			case 3:
				goto IL_FD;
			case 4:
				GameCanvas.keyHold[24] = false;
				return;
			case 5:
				GameCanvas.keyHold[23] = false;
				return;
			case 6:
				goto IL_DF;
			case 7:
				break;
			default:
				switch (keyCode + 26)
				{
				case 0:
					GameCanvas.keyHold[16] = false;
					return;
				default:
					if (keyCode == -39)
					{
						goto IL_DF;
					}
					if (keyCode != -38)
					{
						if (keyCode == 10)
						{
							goto IL_FD;
						}
						if (keyCode != 113)
						{
							return;
						}
						GameCanvas.keyHold[17] = false;
						GameCanvas.keyReleased[17] = true;
						return;
					}
					break;
				case 4:
					goto IL_202;
				case 5:
					goto IL_1EF;
				}
				break;
			}
			GameCanvas.keyHold[21] = false;
			return;
			IL_DF:
			GameCanvas.keyHold[22] = false;
			return;
			IL_FD:
			GameCanvas.keyHold[25] = false;
			GameCanvas.keyReleased[25] = true;
			GameCanvas.keyHold[15] = true;
			GameCanvas.keyPressed[15] = true;
			return;
			IL_1EF:
			GameCanvas.keyHold[12] = false;
			GameCanvas.keyReleased[12] = true;
			return;
			IL_202:
			GameCanvas.keyHold[13] = false;
			GameCanvas.keyReleased[13] = true;
			return;
		case 42:
			GameCanvas.keyHold[10] = false;
			GameCanvas.keyReleased[10] = true;
			return;
		case 48:
			GameCanvas.keyHold[0] = false;
			GameCanvas.keyReleased[0] = true;
			return;
		case 49:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[1] = false;
				GameCanvas.keyReleased[1] = true;
			}
			return;
		case 50:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[2] = false;
				GameCanvas.keyReleased[2] = true;
			}
			return;
		case 51:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[3] = false;
				GameCanvas.keyReleased[3] = true;
			}
			return;
		case 52:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[4] = false;
				GameCanvas.keyReleased[4] = true;
			}
			return;
		case 53:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[5] = false;
				GameCanvas.keyReleased[5] = true;
			}
			return;
		case 54:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[6] = false;
				GameCanvas.keyReleased[6] = true;
			}
			return;
		case 55:
			GameCanvas.keyHold[7] = false;
			GameCanvas.keyReleased[7] = true;
			return;
		case 56:
			if (GameCanvas.currentScreen == GameScr.instance && GameCanvas.isMoveNumberPad && !ChatTextField.gI().isShow)
			{
				GameCanvas.keyHold[8] = false;
				GameCanvas.keyReleased[8] = true;
			}
			return;
		case 57:
			GameCanvas.keyHold[9] = false;
			GameCanvas.keyReleased[9] = true;
			return;
		}
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x00007104 File Offset: 0x00005304
	public void pointerMouse(int x, int y)
	{
		GameCanvas.pxMouse = x;
		GameCanvas.pyMouse = y;
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x00007112 File Offset: 0x00005312
	public void scrollMouse(int a)
	{
		GameCanvas.pXYScrollMouse = a;
		if (GameCanvas.panel != null && GameCanvas.panel.isShow)
		{
			GameCanvas.panel.updateScroolMouse(a);
		}
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x00087560 File Offset: 0x00085760
	public void pointerDragged(int x, int y)
	{
		if (Res.abs(x - GameCanvas.pxLast) >= 10 || Res.abs(y - GameCanvas.pyLast) >= 10)
		{
			GameCanvas.isPointerClick = false;
		}
		GameCanvas.px = x;
		GameCanvas.py = y;
		GameCanvas.curPos++;
		if (GameCanvas.curPos > 3)
		{
			GameCanvas.curPos = 0;
		}
		GameCanvas.arrPos[GameCanvas.curPos] = new Position(x, y);
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x0000713E File Offset: 0x0000533E
	public static bool isHoldPress()
	{
		return mSystem.currentTimeMillis() - GameCanvas.lastTimePress >= 800L;
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x000875D4 File Offset: 0x000857D4
	public void pointerPressed(int x, int y)
	{
		GameCanvas.isPointerJustRelease = false;
		GameCanvas.isPointerJustDown = true;
		GameCanvas.isPointerDown = true;
		GameCanvas.isPointerClick = true;
		GameCanvas.lastTimePress = mSystem.currentTimeMillis();
		GameCanvas.pxFirst = x;
		GameCanvas.pyFirst = y;
		GameCanvas.pxLast = x;
		GameCanvas.pyLast = y;
		GameCanvas.px = x;
		GameCanvas.py = y;
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x00007159 File Offset: 0x00005359
	public void pointerReleased(int x, int y)
	{
		GameCanvas.isPointerDown = false;
		GameCanvas.isPointerJustRelease = true;
		mScreen.keyTouch = -1;
		GameCanvas.px = x;
		GameCanvas.py = y;
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x00087628 File Offset: 0x00085828
	public static bool isPointerHoldIn(int x, int y, int w, int h)
	{
		return (GameCanvas.isPointerDown || GameCanvas.isPointerJustRelease) && (GameCanvas.px >= x && GameCanvas.px <= x + w && GameCanvas.py >= y && GameCanvas.py <= y + h);
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x00007179 File Offset: 0x00005379
	public static bool isMouseFocus(int x, int y, int w, int h)
	{
		return GameCanvas.pxMouse >= x && GameCanvas.pxMouse <= x + w && GameCanvas.pyMouse >= y && GameCanvas.pyMouse <= y + h;
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x00087680 File Offset: 0x00085880
	public static void clearKeyPressed()
	{
		for (int i = 0; i < GameCanvas.keyPressed.Length; i++)
		{
			GameCanvas.keyPressed[i] = false;
		}
		GameCanvas.isPointerJustRelease = false;
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x000876B4 File Offset: 0x000858B4
	public static void clearKeyHold()
	{
		for (int i = 0; i < GameCanvas.keyHold.Length; i++)
		{
			GameCanvas.keyHold[i] = false;
		}
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x000876E4 File Offset: 0x000858E4
	public static void checkBackButton()
	{
		if (ChatPopup.serverChatPopUp == null && ChatPopup.currChatPopup == null)
		{
			GameCanvas.startYesNoDlg(mResources.DOYOUWANTEXIT, new Command(mResources.YES, GameCanvas.instance, 8885, null), new Command(mResources.NO, GameCanvas.instance, 8882, null));
		}
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x0008773C File Offset: 0x0008593C
	public void paintChangeMap(mGraphics g)
	{
		GameCanvas.resetTrans(g);
		g.setColor(0);
		g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
		g.drawImage(LoginScr.imgTitle, GameCanvas.w / 2, GameCanvas.h / 2 - 24, StaticObj.BOTTOM_HCENTER);
		GameCanvas.paintShukiren(GameCanvas.hw, GameCanvas.h / 2 + 24, g);
		mFont.tahoma_7b_white.drawString(g, mResources.PLEASEWAIT + ((LoginScr.timeLogin <= 0) ? string.Empty : (" " + LoginScr.timeLogin + "s")), GameCanvas.w / 2, GameCanvas.h / 2, 2);
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x000877F0 File Offset: 0x000859F0
	public void paint(mGraphics gx)
	{
		try
		{
			GameCanvas.debugPaint.removeAllElements();
			GameCanvas.debug("PA", 1);
			if (GameCanvas.currentScreen != null)
			{
				GameCanvas.currentScreen.paint(this.g);
			}
			GameCanvas.debug("PB", 1);
			this.g.translate(-this.g.getTranslateX(), -this.g.getTranslateY());
			this.g.setClip(0, 0, GameCanvas.w, GameCanvas.h);
			if (GameCanvas.panel.isShow)
			{
				GameCanvas.panel.paint(this.g);
				if (GameCanvas.panel2 != null && GameCanvas.panel2.isShow)
				{
					GameCanvas.panel2.paint(this.g);
				}
				if (GameCanvas.panel.chatTField != null && GameCanvas.panel.chatTField.isShow)
				{
					GameCanvas.panel.chatTField.paint(this.g);
				}
				if (GameCanvas.panel2 != null && GameCanvas.panel2.chatTField != null && GameCanvas.panel2.chatTField.isShow)
				{
					GameCanvas.panel2.chatTField.paint(this.g);
				}
			}
			Res.paintOnScreenDebug(this.g);
			InfoDlg.paint(this.g);
			if (GameCanvas.currentDialog != null)
			{
				GameCanvas.debug("PC", 1);
				GameCanvas.currentDialog.paint(this.g);
			}
			else if (GameCanvas.menu.showMenu)
			{
				GameCanvas.debug("PD", 1);
				GameCanvas.menu.paintMenu(this.g);
			}
			GameScr.info1.paint(this.g);
			GameScr.info2.paint(this.g);
			if (GameScr.gI().popUpYesNo != null)
			{
				GameScr.gI().popUpYesNo.paint(this.g);
			}
			if (ChatPopup.currChatPopup != null)
			{
				ChatPopup.currChatPopup.paint(this.g);
			}
			Hint.paint(this.g);
			if (ChatPopup.serverChatPopUp != null)
			{
				ChatPopup.serverChatPopUp.paint(this.g);
			}
			for (int i = 0; i < Effect2.vEffect2.size(); i++)
			{
				Effect2 effect = (Effect2)Effect2.vEffect2.elementAt(i);
				if (effect is ChatPopup && !effect.Equals(ChatPopup.currChatPopup) && !effect.Equals(ChatPopup.serverChatPopUp))
				{
					effect.paint(this.g);
				}
			}
			if (global::Char.isLoadingMap || LoginScr.isContinueToLogin || ServerListScreen.waitToLogin || ServerListScreen.isWait)
			{
				this.paintChangeMap(this.g);
			}
			GameCanvas.debug("PE", 1);
			GameCanvas.resetTrans(this.g);
			EffecMn.paintLayer4(this.g);
			if ((int)mResources.language == 0 && GameCanvas.open3Hour && !GameCanvas.isLoading)
			{
				if (GameCanvas.currentScreen == GameCanvas.loginScr || GameCanvas.currentScreen == GameCanvas.serverScreen)
				{
					this.g.drawImage(GameCanvas.img12, 5, 5, 0);
				}
				if (GameCanvas.currentScreen == CreateCharScr.instance)
				{
					this.g.drawImage(GameCanvas.img12, 5, 20, 0);
				}
			}
		}
		catch (Exception ex)
		{
		}
	}

	// Token: 0x06000903 RID: 2307 RVA: 0x000071AE File Offset: 0x000053AE
	public static void endDlg()
	{
		if (GameCanvas.inputDlg != null)
		{
			GameCanvas.inputDlg.tfInput.setMaxTextLenght(500);
		}
		GameCanvas.currentDialog = null;
		InfoDlg.hide();
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x000071D9 File Offset: 0x000053D9
	public static void startOKDlg(string info)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, null, new Command(mResources.OK, GameCanvas.instance, 8882, null), null);
		GameCanvas.currentDialog = GameCanvas.msgdlg;
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x0000720C File Offset: 0x0000540C
	public static void startWaitDlg(string info)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, null, new Command(mResources.CANCEL, GameCanvas.instance, 8882, null), null);
		GameCanvas.currentDialog = GameCanvas.msgdlg;
		GameCanvas.msgdlg.isWait = true;
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x0000720C File Offset: 0x0000540C
	public static void startOKDlg(string info, bool isError)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, null, new Command(mResources.CANCEL, GameCanvas.instance, 8882, null), null);
		GameCanvas.currentDialog = GameCanvas.msgdlg;
		GameCanvas.msgdlg.isWait = true;
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x0000724A File Offset: 0x0000544A
	public static void startWaitDlg()
	{
		GameCanvas.closeKeyBoard();
		global::Char.isLoadingMap = true;
	}

	// Token: 0x06000908 RID: 2312 RVA: 0x00007257 File Offset: 0x00005457
	public void openWeb(string strLeft, string strRight, string url, string str)
	{
		GameCanvas.msgdlg.setInfo(str, new Command(strLeft, this, 8881, url), null, new Command(strRight, this, 8882, null));
		GameCanvas.currentDialog = GameCanvas.msgdlg;
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x0000728A File Offset: 0x0000548A
	public static void startOK(string info, int actionID, object p)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, null, new Command(mResources.OK, GameCanvas.instance, actionID, p), null);
		GameCanvas.msgdlg.show();
	}

	// Token: 0x0600090A RID: 2314 RVA: 0x00087B74 File Offset: 0x00085D74
	public static void startYesNoDlg(string info, int iYes, object pYes, int iNo, object pNo)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, new Command(mResources.YES, GameCanvas.instance, iYes, pYes), new Command(string.Empty, GameCanvas.instance, iYes, pYes), new Command(mResources.NO, GameCanvas.instance, iNo, pNo));
		GameCanvas.msgdlg.show();
	}

	// Token: 0x0600090B RID: 2315 RVA: 0x000072B9 File Offset: 0x000054B9
	public static void startYesNoDlg(string info, Command cmdYes, Command cmdNo)
	{
		GameCanvas.closeKeyBoard();
		GameCanvas.msgdlg.setInfo(info, cmdYes, null, cmdNo);
		GameCanvas.msgdlg.show();
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x00087BD0 File Offset: 0x00085DD0
	public static string getMoneys(int m)
	{
		string text = string.Empty;
		int num = m / 1000 + 1;
		for (int i = 0; i < num; i++)
		{
			if (m < 1000)
			{
				text = m + text;
				break;
			}
			int num2 = m % 1000;
			if (num2 == 0)
			{
				text = ".000" + text;
			}
			else if (num2 < 10)
			{
				text = ".00" + num2 + text;
			}
			else if (num2 < 100)
			{
				text = ".0" + num2 + text;
			}
			else
			{
				text = "." + num2 + text;
			}
			m /= 1000;
		}
		return text;
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x000072D8 File Offset: 0x000054D8
	public static int getX(int start, int w)
	{
		return (GameCanvas.px - start) / w;
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x000072E3 File Offset: 0x000054E3
	public static int getY(int start, int w)
	{
		return (GameCanvas.py - start) / w;
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x000031FC File Offset: 0x000013FC
	protected void sizeChanged(int w, int h)
	{
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x000060E9 File Offset: 0x000042E9
	public static bool isGetResourceFromServer()
	{
		return true;
	}

	// Token: 0x06000911 RID: 2321 RVA: 0x00087C9C File Offset: 0x00085E9C
	public static Image loadImageRMS(string path)
	{
		path = string.Concat(new object[]
		{
			Main.res,
			"/x",
			mGraphics.zoomLevel,
			path
		});
		path = GameCanvas.cutPng(path);
		Image result = null;
		try
		{
			result = Image.createImage(path);
		}
		catch (Exception ex)
		{
			try
			{
				string[] array = Res.split(path, "/", 0);
				string filename = "x" + mGraphics.zoomLevel + array[array.Length - 1];
				sbyte[] array2 = Rms.loadRMS(filename);
				if (array2 != null)
				{
					result = Image.createImage(array2, 0, array2.Length);
				}
			}
			catch (Exception ex2)
			{
				Cout.LogError("Loi ham khong tim thay a: " + ex.ToString());
			}
		}
		return result;
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x00087D80 File Offset: 0x00085F80
	public static Image loadImage(string path)
	{
		path = string.Concat(new object[]
		{
			Main.res,
			"/x",
			mGraphics.zoomLevel,
			path
		});
		path = GameCanvas.cutPng(path);
		Image result = null;
		try
		{
			result = Image.createImage(path);
		}
		catch (Exception ex)
		{
		}
		return result;
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x00087DE8 File Offset: 0x00085FE8
	public static string cutPng(string str)
	{
		string result = str;
		if (str.Contains(".png"))
		{
			result = str.Replace(".png", string.Empty);
		}
		return result;
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x000072EE File Offset: 0x000054EE
	public static int random(int a, int b)
	{
		return a + GameCanvas.r.nextInt(b - a);
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x00087E1C File Offset: 0x0008601C
	public bool startDust(int dir, int x, int y)
	{
		if (GameCanvas.lowGraphic)
		{
			return false;
		}
		int num = (dir != 1) ? 1 : 0;
		if (this.dustState[num] != -1)
		{
			return false;
		}
		this.dustState[num] = 0;
		this.dustX[num] = x;
		this.dustY[num] = y;
		return true;
	}

	// Token: 0x06000916 RID: 2326 RVA: 0x00087E70 File Offset: 0x00086070
	public void loadWaterSplash()
	{
		if (GameCanvas.lowGraphic)
		{
			return;
		}
		GameCanvas.imgWS = new Image[3];
		for (int i = 0; i < 3; i++)
		{
			GameCanvas.imgWS[i] = GameCanvas.loadImage("/e/w" + i + ".png");
		}
		GameCanvas.wsX = new int[2];
		GameCanvas.wsY = new int[2];
		GameCanvas.wsState = new int[2];
		GameCanvas.wsF = new int[2];
		GameCanvas.wsState[0] = (GameCanvas.wsState[1] = -1);
	}

	// Token: 0x06000917 RID: 2327 RVA: 0x00087F04 File Offset: 0x00086104
	public bool startWaterSplash(int x, int y)
	{
		if (GameCanvas.lowGraphic)
		{
			return false;
		}
		int num = (GameCanvas.wsState[0] != -1) ? 1 : 0;
		if (GameCanvas.wsState[num] != -1)
		{
			return false;
		}
		GameCanvas.wsState[num] = 0;
		GameCanvas.wsX[num] = x;
		GameCanvas.wsY[num] = y;
		return true;
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x00087F5C File Offset: 0x0008615C
	public void updateWaterSplash()
	{
		if (GameCanvas.lowGraphic)
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			if (GameCanvas.wsState[i] != -1)
			{
				GameCanvas.wsY[i]--;
				if (GameCanvas.gameTick % 2 == 0)
				{
					GameCanvas.wsState[i]++;
					if (GameCanvas.wsState[i] > 2)
					{
						GameCanvas.wsState[i] = -1;
					}
					else
					{
						GameCanvas.wsF[i] = GameCanvas.wsState[i];
					}
				}
			}
		}
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x00087FE8 File Offset: 0x000861E8
	public void updateDust()
	{
		if (GameCanvas.lowGraphic)
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			if (this.dustState[i] != -1)
			{
				this.dustState[i]++;
				if (this.dustState[i] >= 5)
				{
					this.dustState[i] = -1;
				}
				if (i == 0)
				{
					this.dustX[i]--;
				}
				else
				{
					this.dustX[i]++;
				}
				this.dustY[i]--;
			}
		}
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x00088088 File Offset: 0x00086288
	public static bool isPaint(int x, int y)
	{
		return x >= GameScr.cmx && x <= GameScr.cmx + GameScr.gW && y >= GameScr.cmy && y <= GameScr.cmy + GameScr.gH + 30;
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x000880DC File Offset: 0x000862DC
	public void paintDust(mGraphics g)
	{
		if (GameCanvas.lowGraphic)
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			if (this.dustState[i] != -1 && GameCanvas.isPaint(this.dustX[i], this.dustY[i]))
			{
				g.drawImage(GameCanvas.imgDust[i][this.dustState[i]], this.dustX[i], this.dustY[i], 3);
			}
		}
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x00088158 File Offset: 0x00086358
	public void loadDust()
	{
		if (GameCanvas.lowGraphic)
		{
			return;
		}
		if (GameCanvas.imgDust == null)
		{
			GameCanvas.imgDust = new Image[2][];
			for (int i = 0; i < GameCanvas.imgDust.Length; i++)
			{
				GameCanvas.imgDust[i] = new Image[5];
			}
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 5; k++)
				{
					GameCanvas.imgDust[j][k] = GameCanvas.loadImage(string.Concat(new object[]
					{
						"/e/d",
						j,
						k,
						".png"
					}));
				}
			}
		}
		this.dustX = new int[2];
		this.dustY = new int[2];
		this.dustState = new int[2];
		this.dustState[0] = (this.dustState[1] = -1);
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x00088244 File Offset: 0x00086444
	public static void paintShukiren(int x, int y, mGraphics g)
	{
		g.drawRegion(GameCanvas.imgShuriken, 0, Main.f * 16, 16, 16, 0, x, y, mGraphics.HCENTER | mGraphics.VCENTER);
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x000072FF File Offset: 0x000054FF
	public void resetToLoginScrz()
	{
		this.resetToLoginScr = true;
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x00087628 File Offset: 0x00085828
	public static bool isPointer(int x, int y, int w, int h)
	{
		return (GameCanvas.isPointerDown || GameCanvas.isPointerJustRelease) && (GameCanvas.px >= x && GameCanvas.px <= x + w && GameCanvas.py >= y && GameCanvas.py <= y + h);
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x00088278 File Offset: 0x00086478
	public void perform(int idAction, object p)
	{
		switch (idAction)
		{
		case 88810:
		{
			int playerMapId = (int)p;
			GameCanvas.endDlg();
			Service.gI().acceptInviteTrade(playerMapId);
			break;
		}
		case 88811:
			GameCanvas.endDlg();
			Service.gI().cancelInviteTrade();
			break;
		default:
			switch (idAction)
			{
			case 8881:
			{
				string url = (string)p;
				try
				{
					GameMidlet.instance.platformRequest(url);
				}
				catch (Exception ex)
				{
				}
				GameCanvas.currentDialog = null;
				break;
			}
			case 8882:
				InfoDlg.hide();
				GameCanvas.currentDialog = null;
				break;
			default:
				switch (idAction)
				{
				case 888391:
				{
					string s = (string)p;
					GameCanvas.endDlg();
					Service.gI().clearAccProtect(int.Parse(s));
					break;
				}
				case 888392:
					Service.gI().menu(4, GameCanvas.menu.menuSelectedItem, 0);
					break;
				case 888393:
					if (GameCanvas.loginScr == null)
					{
						GameCanvas.loginScr = new LoginScr();
					}
					GameCanvas.loginScr.doLogin();
					Main.closeKeyBoard();
					break;
				case 888394:
					GameCanvas.endDlg();
					break;
				case 888395:
					GameCanvas.endDlg();
					break;
				case 888396:
					GameCanvas.endDlg();
					break;
				case 888397:
				{
					string text = (string)p;
					break;
				}
				default:
					if (idAction != 999)
					{
						if (idAction != 9000)
						{
							if (idAction != 9999)
							{
								if (idAction != 101023)
								{
									if (idAction == 888361)
									{
										string text2 = GameCanvas.inputDlg.tfInput.getText();
										GameCanvas.endDlg();
										if (text2.Length < 6 || text2.Equals(string.Empty))
										{
											GameCanvas.startOKDlg(mResources.ALERT_PRIVATE_PASS_1);
										}
										else
										{
											try
											{
												Service.gI().activeAccProtect(int.Parse(text2));
											}
											catch (Exception ex2)
											{
												GameCanvas.startOKDlg(mResources.ALERT_PRIVATE_PASS_2);
												Cout.println("Loi tai 888361 Gamescavas " + ex2.ToString());
											}
										}
									}
								}
								else
								{
									Main.numberQuit = 0;
								}
							}
							else
							{
								GameCanvas.endDlg();
								GameCanvas.connect();
								Service.gI().setClientType();
								if (GameCanvas.loginScr == null)
								{
									GameCanvas.loginScr = new LoginScr();
								}
								GameCanvas.loginScr.doLogin();
							}
						}
						else
						{
							GameCanvas.endDlg();
							SplashScr.imgLogo = null;
							SmallImage.loadBigRMS();
							mSystem.gcc();
							ServerListScreen.bigOk = true;
							ServerListScreen.loadScreen = true;
							GameScr.gI().loadGameScr();
							if (GameCanvas.currentScreen != GameCanvas.loginScr)
							{
								GameCanvas.serverScreen.switchToMe2();
							}
						}
					}
					else
					{
						mSystem.closeBanner();
						GameCanvas.endDlg();
					}
					break;
				}
				break;
			case 8884:
				GameCanvas.endDlg();
				GameCanvas.loginScr.switchToMe();
				break;
			case 8885:
				GameMidlet.instance.exit();
				break;
			case 8886:
			{
				GameCanvas.endDlg();
				string name = (string)p;
				Service.gI().addFriend(name);
				break;
			}
			case 8887:
			{
				GameCanvas.endDlg();
				int charId = (int)p;
				Service.gI().addPartyAccept(charId);
				break;
			}
			case 8888:
			{
				int charId2 = (int)p;
				Service.gI().addPartyCancel(charId2);
				GameCanvas.endDlg();
				break;
			}
			case 8889:
			{
				string str = (string)p;
				GameCanvas.endDlg();
				Service.gI().acceptPleaseParty(str);
				break;
			}
			}
			break;
		case 88814:
		{
			Item[] items = (Item[])p;
			GameCanvas.endDlg();
			Service.gI().crystalCollectLock(items);
			break;
		}
		case 88815:
			break;
		case 88817:
			ChatPopup.addChatPopup(string.Empty, 1, global::Char.myCharz().npcFocus);
			Service.gI().menu(global::Char.myCharz().npcFocus.template.npcTemplateId, GameCanvas.menu.menuSelectedItem, 0);
			break;
		case 88818:
		{
			short menuId = (short)p;
			Service.gI().textBoxId(menuId, GameCanvas.inputDlg.tfInput.getText());
			GameCanvas.endDlg();
			break;
		}
		case 88819:
		{
			short menuId2 = (short)p;
			Service.gI().menuId(menuId2);
			break;
		}
		case 88820:
		{
			string[] array = (string[])p;
			if (global::Char.myCharz().npcFocus == null)
			{
				return;
			}
			int menuSelectedItem = GameCanvas.menu.menuSelectedItem;
			if (array.Length > 1)
			{
				MyVector myVector = new MyVector();
				for (int i = 0; i < array.Length - 1; i++)
				{
					myVector.addElement(new Command(array[i + 1], GameCanvas.instance, 88821, menuSelectedItem));
				}
				GameCanvas.menu.startAt(myVector, 3);
			}
			else
			{
				ChatPopup.addChatPopup(string.Empty, 1, global::Char.myCharz().npcFocus);
				Service.gI().menu(global::Char.myCharz().npcFocus.template.npcTemplateId, menuSelectedItem, 0);
			}
			break;
		}
		case 88821:
		{
			int menuId3 = (int)p;
			ChatPopup.addChatPopup(string.Empty, 1, global::Char.myCharz().npcFocus);
			Service.gI().menu(global::Char.myCharz().npcFocus.template.npcTemplateId, menuId3, GameCanvas.menu.menuSelectedItem);
			break;
		}
		case 88822:
			ChatPopup.addChatPopup(string.Empty, 1, global::Char.myCharz().npcFocus);
			Service.gI().menu(global::Char.myCharz().npcFocus.template.npcTemplateId, GameCanvas.menu.menuSelectedItem, 0);
			break;
		case 88823:
			GameCanvas.startOKDlg(mResources.SENTMSG);
			break;
		case 88824:
			GameCanvas.startOKDlg(mResources.NOSENDMSG);
			break;
		case 88825:
			GameCanvas.startOKDlg(mResources.sendMsgSuccess, false);
			break;
		case 88826:
			GameCanvas.startOKDlg(mResources.cannotSendMsg, false);
			break;
		case 88827:
			GameCanvas.startOKDlg(mResources.sendGuessMsgSuccess);
			break;
		case 88828:
			GameCanvas.startOKDlg(mResources.sendMsgFail);
			break;
		case 88829:
		{
			string text3 = GameCanvas.inputDlg.tfInput.getText();
			if (text3.Equals(string.Empty))
			{
				return;
			}
			Service.gI().changeName(text3, (int)p);
			InfoDlg.showWait();
			break;
		}
		case 88836:
			GameCanvas.inputDlg.tfInput.setMaxTextLenght(6);
			GameCanvas.inputDlg.show(mResources.INPUT_PRIVATE_PASS, new Command(mResources.ACCEPT, GameCanvas.instance, 888361, null), TField.INPUT_TYPE_NUMERIC);
			break;
		case 88837:
		{
			string text4 = GameCanvas.inputDlg.tfInput.getText();
			GameCanvas.endDlg();
			try
			{
				Service.gI().openLockAccProtect(int.Parse(text4.Trim()));
			}
			catch (Exception ex3)
			{
				Cout.println("Loi tai 88837 " + ex3.ToString());
			}
			break;
		}
		case 88839:
		{
			string text5 = GameCanvas.inputDlg.tfInput.getText();
			GameCanvas.endDlg();
			if (text5.Length < 6 || text5.Equals(string.Empty))
			{
				GameCanvas.startOKDlg(mResources.ALERT_PRIVATE_PASS_1);
			}
			else
			{
				try
				{
					GameCanvas.startYesNoDlg(mResources.cancelAccountProtection, 888391, text5, 8882, null);
				}
				catch (Exception ex4)
				{
					GameCanvas.startOKDlg(mResources.ALERT_PRIVATE_PASS_2);
				}
			}
			break;
		}
		}
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x00007308 File Offset: 0x00005508
	public static void clearAllPointerEvent()
	{
		GameCanvas.isPointerClick = false;
		GameCanvas.isPointerDown = false;
		GameCanvas.isPointerJustDown = false;
		GameCanvas.isPointerJustRelease = false;
		GameScr.gI().lastSingleClick = 0L;
		GameScr.gI().isPointerDowning = false;
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x000031FC File Offset: 0x000013FC
	public static void backToRegister()
	{
	}

	// Token: 0x04001063 RID: 4195
	public static bool open3Hour;

	// Token: 0x04001064 RID: 4196
	public static bool lowGraphic = false;

	// Token: 0x04001065 RID: 4197
	public static bool isMoveNumberPad = true;

	// Token: 0x04001066 RID: 4198
	public static bool isLoading;

	// Token: 0x04001067 RID: 4199
	public static bool isTouch = false;

	// Token: 0x04001068 RID: 4200
	public static bool isTouchControl;

	// Token: 0x04001069 RID: 4201
	public static bool isTouchControlSmallScreen;

	// Token: 0x0400106A RID: 4202
	public static bool isTouchControlLargeScreen;

	// Token: 0x0400106B RID: 4203
	public static bool isConnectFail;

	// Token: 0x0400106C RID: 4204
	public static GameCanvas instance;

	// Token: 0x0400106D RID: 4205
	public static bool bRun;

	// Token: 0x0400106E RID: 4206
	public static bool[] keyPressed = new bool[30];

	// Token: 0x0400106F RID: 4207
	public static bool[] keyReleased = new bool[30];

	// Token: 0x04001070 RID: 4208
	public static bool[] keyHold = new bool[30];

	// Token: 0x04001071 RID: 4209
	public static bool isPointerDown;

	// Token: 0x04001072 RID: 4210
	public static bool isPointerClick;

	// Token: 0x04001073 RID: 4211
	public static bool isPointerJustRelease;

	// Token: 0x04001074 RID: 4212
	public static int px;

	// Token: 0x04001075 RID: 4213
	public static int py;

	// Token: 0x04001076 RID: 4214
	public static int pxFirst;

	// Token: 0x04001077 RID: 4215
	public static int pyFirst;

	// Token: 0x04001078 RID: 4216
	public static int pxLast;

	// Token: 0x04001079 RID: 4217
	public static int pyLast;

	// Token: 0x0400107A RID: 4218
	public static int pxMouse;

	// Token: 0x0400107B RID: 4219
	public static int pyMouse;

	// Token: 0x0400107C RID: 4220
	public static Position[] arrPos = new Position[4];

	// Token: 0x0400107D RID: 4221
	public static int gameTick;

	// Token: 0x0400107E RID: 4222
	public static int taskTick;

	// Token: 0x0400107F RID: 4223
	public static bool isEff1;

	// Token: 0x04001080 RID: 4224
	public static bool isEff2;

	// Token: 0x04001081 RID: 4225
	public static long timeTickEff1;

	// Token: 0x04001082 RID: 4226
	public static long timeTickEff2;

	// Token: 0x04001083 RID: 4227
	public static int w;

	// Token: 0x04001084 RID: 4228
	public static int h;

	// Token: 0x04001085 RID: 4229
	public static int hw;

	// Token: 0x04001086 RID: 4230
	public static int hh;

	// Token: 0x04001087 RID: 4231
	public static int wd3;

	// Token: 0x04001088 RID: 4232
	public static int hd3;

	// Token: 0x04001089 RID: 4233
	public static int w2d3;

	// Token: 0x0400108A RID: 4234
	public static int h2d3;

	// Token: 0x0400108B RID: 4235
	public static int w3d4;

	// Token: 0x0400108C RID: 4236
	public static int h3d4;

	// Token: 0x0400108D RID: 4237
	public static int wd6;

	// Token: 0x0400108E RID: 4238
	public static int hd6;

	// Token: 0x0400108F RID: 4239
	public static mScreen currentScreen;

	// Token: 0x04001090 RID: 4240
	public static Menu menu = new Menu();

	// Token: 0x04001091 RID: 4241
	public static Panel panel;

	// Token: 0x04001092 RID: 4242
	public static Panel panel2;

	// Token: 0x04001093 RID: 4243
	public static LoginScr loginScr;

	// Token: 0x04001094 RID: 4244
	public static RegisterScreen registerScr;

	// Token: 0x04001095 RID: 4245
	public static Dialog currentDialog;

	// Token: 0x04001096 RID: 4246
	public static MsgDlg msgdlg;

	// Token: 0x04001097 RID: 4247
	public static InputDlg inputDlg;

	// Token: 0x04001098 RID: 4248
	public static MyVector currentPopup = new MyVector();

	// Token: 0x04001099 RID: 4249
	public static int requestLoseCount;

	// Token: 0x0400109A RID: 4250
	public static MyVector listPoint;

	// Token: 0x0400109B RID: 4251
	public static Paint paintz;

	// Token: 0x0400109C RID: 4252
	public static bool isGetResFromServer;

	// Token: 0x0400109D RID: 4253
	public static Image[] imgBG;

	// Token: 0x0400109E RID: 4254
	public static int skyColor;

	// Token: 0x0400109F RID: 4255
	public static int curPos = 0;

	// Token: 0x040010A0 RID: 4256
	public static int[] bgW;

	// Token: 0x040010A1 RID: 4257
	public static int[] bgH;

	// Token: 0x040010A2 RID: 4258
	public static int planet = 0;

	// Token: 0x040010A3 RID: 4259
	private mGraphics g = new mGraphics();

	// Token: 0x040010A4 RID: 4260
	public static Image img12;

	// Token: 0x040010A5 RID: 4261
	public static Image[] imgBlue = new Image[7];

	// Token: 0x040010A6 RID: 4262
	public static Image[] imgViolet = new Image[7];

	// Token: 0x040010A7 RID: 4263
	public static bool isPlaySound = true;

	// Token: 0x040010A8 RID: 4264
	private static int clearOldData;

	// Token: 0x040010A9 RID: 4265
	public static int timeOpenKeyBoard;

	// Token: 0x040010AA RID: 4266
	public static bool isFocusPanel2;

	// Token: 0x040010AB RID: 4267
	public bool isPaintCarret;

	// Token: 0x040010AC RID: 4268
	public static MyVector debugUpdate;

	// Token: 0x040010AD RID: 4269
	public static MyVector debugPaint;

	// Token: 0x040010AE RID: 4270
	public static MyVector debugSession;

	// Token: 0x040010AF RID: 4271
	private static bool isShowErrorForm = false;

	// Token: 0x040010B0 RID: 4272
	public static bool paintBG;

	// Token: 0x040010B1 RID: 4273
	public static int gsskyHeight;

	// Token: 0x040010B2 RID: 4274
	public static int gsgreenField1Y;

	// Token: 0x040010B3 RID: 4275
	public static int gsgreenField2Y;

	// Token: 0x040010B4 RID: 4276
	public static int gshouseY;

	// Token: 0x040010B5 RID: 4277
	public static int gsmountainY;

	// Token: 0x040010B6 RID: 4278
	public static int bgLayer0y;

	// Token: 0x040010B7 RID: 4279
	public static int bgLayer1y;

	// Token: 0x040010B8 RID: 4280
	public static Image imgCloud;

	// Token: 0x040010B9 RID: 4281
	public static Image imgSun;

	// Token: 0x040010BA RID: 4282
	public static Image imgSun2;

	// Token: 0x040010BB RID: 4283
	public static Image imgClear;

	// Token: 0x040010BC RID: 4284
	public static Image[] imgBorder = new Image[3];

	// Token: 0x040010BD RID: 4285
	public static int borderConnerW;

	// Token: 0x040010BE RID: 4286
	public static int borderConnerH;

	// Token: 0x040010BF RID: 4287
	public static int borderCenterW;

	// Token: 0x040010C0 RID: 4288
	public static int borderCenterH;

	// Token: 0x040010C1 RID: 4289
	public static int[] cloudX;

	// Token: 0x040010C2 RID: 4290
	public static int[] cloudY;

	// Token: 0x040010C3 RID: 4291
	public static int sunX;

	// Token: 0x040010C4 RID: 4292
	public static int sunY;

	// Token: 0x040010C5 RID: 4293
	public static int sunX2;

	// Token: 0x040010C6 RID: 4294
	public static int sunY2;

	// Token: 0x040010C7 RID: 4295
	public static int[] layerSpeed;

	// Token: 0x040010C8 RID: 4296
	public static int[] moveX;

	// Token: 0x040010C9 RID: 4297
	public static int[] moveXSpeed;

	// Token: 0x040010CA RID: 4298
	public static bool isBoltEff;

	// Token: 0x040010CB RID: 4299
	public static bool boltActive;

	// Token: 0x040010CC RID: 4300
	public static int tBolt;

	// Token: 0x040010CD RID: 4301
	public static int typeBg = -1;

	// Token: 0x040010CE RID: 4302
	public static int transY;

	// Token: 0x040010CF RID: 4303
	public static int[] yb = new int[5];

	// Token: 0x040010D0 RID: 4304
	public static int[] colorTop;

	// Token: 0x040010D1 RID: 4305
	public static int[] colorBotton;

	// Token: 0x040010D2 RID: 4306
	public static int yb1;

	// Token: 0x040010D3 RID: 4307
	public static int yb2;

	// Token: 0x040010D4 RID: 4308
	public static int yb3;

	// Token: 0x040010D5 RID: 4309
	public static int nBg = 0;

	// Token: 0x040010D6 RID: 4310
	public static int lastBg = -1;

	// Token: 0x040010D7 RID: 4311
	public static int[] bgRain = new int[]
	{
		1,
		4,
		11
	};

	// Token: 0x040010D8 RID: 4312
	public static int[] bgRainFont = new int[]
	{
		-1
	};

	// Token: 0x040010D9 RID: 4313
	public static Image imgCaycot;

	// Token: 0x040010DA RID: 4314
	public static Image tam;

	// Token: 0x040010DB RID: 4315
	public static int typeBackGround = -1;

	// Token: 0x040010DC RID: 4316
	public static int saveIDBg = -10;

	// Token: 0x040010DD RID: 4317
	public static bool isLoadBGok;

	// Token: 0x040010DE RID: 4318
	private static long lastTimePress = 0L;

	// Token: 0x040010DF RID: 4319
	public static int keyAsciiPress;

	// Token: 0x040010E0 RID: 4320
	public static int pXYScrollMouse;

	// Token: 0x040010E1 RID: 4321
	private static Image imgSignal;

	// Token: 0x040010E2 RID: 4322
	public static MyVector flyTexts = new MyVector();

	// Token: 0x040010E3 RID: 4323
	public int longTime;

	// Token: 0x040010E4 RID: 4324
	public static bool isPointerJustDown = false;

	// Token: 0x040010E5 RID: 4325
	private int count = 1;

	// Token: 0x040010E6 RID: 4326
	public static bool csWait;

	// Token: 0x040010E7 RID: 4327
	public static MyRandom r = new MyRandom();

	// Token: 0x040010E8 RID: 4328
	public static bool isBlackScreen;

	// Token: 0x040010E9 RID: 4329
	public static int[] bgSpeed;

	// Token: 0x040010EA RID: 4330
	public static int cmdBarX;

	// Token: 0x040010EB RID: 4331
	public static int cmdBarY;

	// Token: 0x040010EC RID: 4332
	public static int cmdBarW;

	// Token: 0x040010ED RID: 4333
	public static int cmdBarH;

	// Token: 0x040010EE RID: 4334
	public static int cmdBarLeftW;

	// Token: 0x040010EF RID: 4335
	public static int cmdBarRightW;

	// Token: 0x040010F0 RID: 4336
	public static int cmdBarCenterW;

	// Token: 0x040010F1 RID: 4337
	public static int hpBarX;

	// Token: 0x040010F2 RID: 4338
	public static int hpBarY;

	// Token: 0x040010F3 RID: 4339
	public static int hpBarW;

	// Token: 0x040010F4 RID: 4340
	public static int expBarW;

	// Token: 0x040010F5 RID: 4341
	public static int lvPosX;

	// Token: 0x040010F6 RID: 4342
	public static int moneyPosX;

	// Token: 0x040010F7 RID: 4343
	public static int hpBarH;

	// Token: 0x040010F8 RID: 4344
	public static int girlHPBarY;

	// Token: 0x040010F9 RID: 4345
	public int timeOut;

	// Token: 0x040010FA RID: 4346
	public int[] dustX;

	// Token: 0x040010FB RID: 4347
	public int[] dustY;

	// Token: 0x040010FC RID: 4348
	public int[] dustState;

	// Token: 0x040010FD RID: 4349
	public static int[] wsX;

	// Token: 0x040010FE RID: 4350
	public static int[] wsY;

	// Token: 0x040010FF RID: 4351
	public static int[] wsState;

	// Token: 0x04001100 RID: 4352
	public static int[] wsF;

	// Token: 0x04001101 RID: 4353
	public static Image[] imgWS;

	// Token: 0x04001102 RID: 4354
	public static Image imgShuriken;

	// Token: 0x04001103 RID: 4355
	public static Image[][] imgDust;

	// Token: 0x04001104 RID: 4356
	public static bool isResume;

	// Token: 0x04001105 RID: 4357
	public static ServerListScreen serverScreen;

	// Token: 0x04001106 RID: 4358
	public bool resetToLoginScr;
}
