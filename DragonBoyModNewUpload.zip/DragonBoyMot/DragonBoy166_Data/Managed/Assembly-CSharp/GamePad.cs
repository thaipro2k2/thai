﻿using System;

// Token: 0x020000B8 RID: 184
public class GamePad
{
	// Token: 0x0600092B RID: 2347 RVA: 0x00088AA4 File Offset: 0x00086CA4
	public GamePad()
	{
		this.R = 28;
		if (GameCanvas.w < 300)
		{
			this.isSmallGamePad = true;
			this.isMediumGamePad = false;
			this.isLargeGamePad = false;
		}
		if (GameCanvas.w >= 300 && GameCanvas.w <= 380)
		{
			this.isSmallGamePad = false;
			this.isMediumGamePad = true;
			this.isLargeGamePad = false;
		}
		if (GameCanvas.w > 380)
		{
			this.isSmallGamePad = false;
			this.isMediumGamePad = false;
			this.isLargeGamePad = true;
		}
		if (!this.isLargeGamePad)
		{
			this.xZone = 0;
			this.wZone = GameCanvas.hw;
			this.yZone = GameCanvas.hh >> 1;
			this.hZone = GameCanvas.h - 80;
		}
		else
		{
			this.xZone = 0;
			this.wZone = GameCanvas.hw / 4 * 3 - 20;
			this.yZone = GameCanvas.hh >> 1;
			this.hZone = GameCanvas.h;
		}
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x00088BA8 File Offset: 0x00086DA8
	public void update()
	{
		if (GameScr.isAnalog == 0)
		{
			return;
		}
		if (GameCanvas.isPointerDown && !GameCanvas.isPointerJustRelease)
		{
			this.xTemp = GameCanvas.pxFirst;
			this.yTemp = GameCanvas.pyFirst;
			if (this.xTemp >= this.xZone && this.xTemp <= this.wZone && this.yTemp >= this.yZone && this.yTemp <= this.hZone)
			{
				if (!this.isGamePad)
				{
					this.xC = (this.xM = this.xTemp);
					this.yC = (this.yM = this.yTemp);
				}
				this.isGamePad = true;
				this.deltaX = GameCanvas.px - this.xC;
				this.deltaY = GameCanvas.py - this.yC;
				this.delta = global::Math.pow(this.deltaX, 2) + global::Math.pow(this.deltaY, 2);
				this.d = Res.sqrt(this.delta);
				if (global::Math.abs(this.deltaX) > 4 || global::Math.abs(this.deltaY) > 4)
				{
					this.angle = Res.angle(this.deltaX, this.deltaY);
					if (!GameCanvas.isPointerHoldIn(this.xC - this.R, this.yC - this.R, 2 * this.R, 2 * this.R))
					{
						if (this.d != 0)
						{
							this.yM = this.deltaY * this.R / this.d;
							this.xM = this.deltaX * this.R / this.d;
							this.xM += this.xC;
							this.yM += this.yC;
							if (!Res.inRect(this.xC - this.R, this.yC - this.R, 2 * this.R, 2 * this.R, this.xM, this.yM))
							{
								this.xM = this.xMLast;
								this.yM = this.yMLast;
							}
							else
							{
								this.xMLast = this.xM;
								this.yMLast = this.yM;
							}
						}
						else
						{
							this.xM = this.xMLast;
							this.yM = this.yMLast;
						}
					}
					else
					{
						this.xM = GameCanvas.px;
						this.yM = GameCanvas.py;
					}
					this.resetHold();
					if (this.checkPointerMove(2))
					{
						if ((this.angle <= 360 && this.angle >= 340) || (this.angle >= 0 && this.angle <= 20))
						{
							GameCanvas.keyHold[(!Main.isPC) ? 6 : 24] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 6 : 24] = true;
						}
						else if (this.angle > 40 && this.angle < 70)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 6 : 24] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 6 : 24] = true;
						}
						else if (this.angle >= 70 && this.angle <= 110)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 8 : 22] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 8 : 22] = true;
						}
						else if (this.angle > 110 && this.angle < 120)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 4 : 23] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 4 : 23] = true;
						}
						else if (this.angle >= 120 && this.angle <= 200)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 4 : 23] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 4 : 23] = true;
						}
						else if (this.angle > 200 && this.angle < 250)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 2 : 21] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 2 : 21] = true;
							GameCanvas.keyHold[(!Main.isPC) ? 4 : 23] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 4 : 23] = true;
						}
						else if (this.angle >= 250 && this.angle <= 290)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 2 : 21] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 2 : 21] = true;
						}
						else if (this.angle > 290 && this.angle < 340)
						{
							GameCanvas.keyHold[(!Main.isPC) ? 2 : 21] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 2 : 21] = true;
							GameCanvas.keyHold[(!Main.isPC) ? 6 : 24] = true;
							GameCanvas.keyPressed[(!Main.isPC) ? 6 : 24] = true;
						}
					}
					else
					{
						this.resetHold();
					}
				}
			}
		}
		else
		{
			this.xM = (this.xC = 45);
			if (!this.isLargeGamePad)
			{
				this.yM = (this.yC = GameCanvas.h - 90);
			}
			else
			{
				this.yM = (this.yC = GameCanvas.h - 45);
			}
			this.isGamePad = false;
			this.resetHold();
		}
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x000891D8 File Offset: 0x000873D8
	private bool checkPointerMove(int distance)
	{
		if (GameScr.isAnalog == 0)
		{
			return false;
		}
		if (global::Char.myCharz().statusMe == 3)
		{
			return true;
		}
		try
		{
			for (int i = 2; i > 0; i--)
			{
				int i2 = GameCanvas.arrPos[i].x - GameCanvas.arrPos[i - 1].x;
				int i3 = GameCanvas.arrPos[i].y - GameCanvas.arrPos[i - 1].y;
				if (Res.abs(i2) > distance && Res.abs(i3) > distance)
				{
					return false;
				}
			}
		}
		catch (Exception ex)
		{
		}
		return true;
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x000073D2 File Offset: 0x000055D2
	private void resetHold()
	{
		GameCanvas.clearKeyHold();
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x0008928C File Offset: 0x0008748C
	public void paint(mGraphics g)
	{
		if (GameScr.isAnalog == 0)
		{
			return;
		}
		g.drawImage(GameScr.imgAnalog1, this.xC, this.yC, mGraphics.HCENTER | mGraphics.VCENTER);
		g.drawImage(GameScr.imgAnalog2, this.xM, this.yM, mGraphics.HCENTER | mGraphics.VCENTER);
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x000073D9 File Offset: 0x000055D9
	public bool disableCheckDrag()
	{
		return GameScr.isAnalog != 0 && this.isGamePad;
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x000892E8 File Offset: 0x000874E8
	public bool disableClickMove()
	{
		return GameScr.isAnalog != 0 && ((GameCanvas.px >= this.xZone && GameCanvas.px <= this.wZone && GameCanvas.py >= this.yZone && GameCanvas.py <= this.hZone) || GameCanvas.px >= GameCanvas.w - 50);
	}

	// Token: 0x04001111 RID: 4369
	private int xC;

	// Token: 0x04001112 RID: 4370
	private int yC;

	// Token: 0x04001113 RID: 4371
	private int xM;

	// Token: 0x04001114 RID: 4372
	private int yM;

	// Token: 0x04001115 RID: 4373
	private int xMLast;

	// Token: 0x04001116 RID: 4374
	private int yMLast;

	// Token: 0x04001117 RID: 4375
	private int R;

	// Token: 0x04001118 RID: 4376
	private int r;

	// Token: 0x04001119 RID: 4377
	private int d;

	// Token: 0x0400111A RID: 4378
	private int xTemp;

	// Token: 0x0400111B RID: 4379
	private int yTemp;

	// Token: 0x0400111C RID: 4380
	private int deltaX;

	// Token: 0x0400111D RID: 4381
	private int deltaY;

	// Token: 0x0400111E RID: 4382
	private int delta;

	// Token: 0x0400111F RID: 4383
	private int angle;

	// Token: 0x04001120 RID: 4384
	public int xZone;

	// Token: 0x04001121 RID: 4385
	public int yZone;

	// Token: 0x04001122 RID: 4386
	public int wZone;

	// Token: 0x04001123 RID: 4387
	public int hZone;

	// Token: 0x04001124 RID: 4388
	private bool isGamePad;

	// Token: 0x04001125 RID: 4389
	public bool isSmallGamePad;

	// Token: 0x04001126 RID: 4390
	public bool isMediumGamePad;

	// Token: 0x04001127 RID: 4391
	public bool isLargeGamePad;
}
