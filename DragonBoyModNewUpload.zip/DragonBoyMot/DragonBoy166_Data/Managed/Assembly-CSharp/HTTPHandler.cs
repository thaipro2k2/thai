﻿using System;

// Token: 0x02000006 RID: 6
internal interface HTTPHandler
{
	// Token: 0x0600002A RID: 42
	void onGetText(string s);
}
