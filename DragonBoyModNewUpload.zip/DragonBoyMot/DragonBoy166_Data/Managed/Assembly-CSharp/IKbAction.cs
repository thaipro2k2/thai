﻿using System;

// Token: 0x02000007 RID: 7
public interface IKbAction
{
	// Token: 0x0600002B RID: 43
	void perform(string text);
}
