﻿using System;

// Token: 0x0200009C RID: 156
public interface IMapObject
{
	// Token: 0x060006CB RID: 1739
	int getX();

	// Token: 0x060006CC RID: 1740
	int getY();

	// Token: 0x060006CD RID: 1741
	int getW();

	// Token: 0x060006CE RID: 1742
	int getH();

	// Token: 0x060006CF RID: 1743
	void stopMoving();

	// Token: 0x060006D0 RID: 1744
	bool isInvisible();
}
