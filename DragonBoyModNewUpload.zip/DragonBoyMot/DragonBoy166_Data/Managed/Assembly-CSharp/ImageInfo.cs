﻿using System;

// Token: 0x0200003F RID: 63
public class ImageInfo
{
	// Token: 0x040002F6 RID: 758
	public int ID;

	// Token: 0x040002F7 RID: 759
	public int x;

	// Token: 0x040002F8 RID: 760
	public int y;

	// Token: 0x040002F9 RID: 761
	public int x0;

	// Token: 0x040002FA RID: 762
	public int y0;

	// Token: 0x040002FB RID: 763
	public int w;

	// Token: 0x040002FC RID: 764
	public int h;
}
