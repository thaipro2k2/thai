﻿using System;

// Token: 0x0200009E RID: 158
public class InfoDlg
{
	// Token: 0x060006D9 RID: 1753 RVA: 0x000063AF File Offset: 0x000045AF
	public static void show(string title, string subtitle, int delay)
	{
		if (title == null)
		{
			return;
		}
		InfoDlg.isShow = true;
		InfoDlg.title = title;
		InfoDlg.subtitke = subtitle;
		InfoDlg.delay = delay;
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x000063D0 File Offset: 0x000045D0
	public static void showWait()
	{
		InfoDlg.show(mResources.PLEASEWAIT, null, 1000);
		InfoDlg.isLock = true;
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x000063E8 File Offset: 0x000045E8
	public static void showWait(string str)
	{
		InfoDlg.show(str, null, 700);
		InfoDlg.isLock = true;
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x0005F648 File Offset: 0x0005D848
	public static void paint(mGraphics g)
	{
		if (!InfoDlg.isShow)
		{
			return;
		}
		if (InfoDlg.isLock && InfoDlg.delay > 4990)
		{
			return;
		}
		if (GameScr.isPaintAlert)
		{
			return;
		}
		int num = 10;
		GameCanvas.paintz.paintPopUp(GameCanvas.hw - 75, num, 150, 55, g);
		if (InfoDlg.isLock)
		{
			GameCanvas.paintShukiren(GameCanvas.hw - mFont.tahoma_8b.getWidth(InfoDlg.title) / 2 - 10, num + 28, g);
			mFont.tahoma_8b.drawString(g, InfoDlg.title, GameCanvas.hw + 5, num + 21, 2);
		}
		else if (InfoDlg.subtitke != null)
		{
			mFont.tahoma_8b.drawString(g, InfoDlg.title, GameCanvas.hw, num + 13, 2);
			mFont.tahoma_7_green2.drawString(g, InfoDlg.subtitke, GameCanvas.hw, num + 30, 2);
		}
		else
		{
			mFont.tahoma_8b.drawString(g, InfoDlg.title, GameCanvas.hw, num + 21, 2);
		}
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x000063FC File Offset: 0x000045FC
	public static void update()
	{
		if (InfoDlg.delay > 0)
		{
			InfoDlg.delay--;
			if (InfoDlg.delay == 0)
			{
				InfoDlg.hide();
			}
		}
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00006424 File Offset: 0x00004624
	public static void hide()
	{
		InfoDlg.title = string.Empty;
		InfoDlg.subtitke = null;
		InfoDlg.isLock = false;
		InfoDlg.delay = 0;
		InfoDlg.isShow = false;
	}

	// Token: 0x04000CD3 RID: 3283
	public static bool isShow;

	// Token: 0x04000CD4 RID: 3284
	private static string title;

	// Token: 0x04000CD5 RID: 3285
	private static string subtitke;

	// Token: 0x04000CD6 RID: 3286
	public static int delay;

	// Token: 0x04000CD7 RID: 3287
	public static bool isLock;
}
