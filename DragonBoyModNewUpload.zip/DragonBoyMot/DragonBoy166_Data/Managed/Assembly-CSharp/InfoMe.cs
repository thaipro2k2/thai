﻿using System;

// Token: 0x020000A0 RID: 160
public class InfoMe
{
	// Token: 0x060006E1 RID: 1761 RVA: 0x0005F750 File Offset: 0x0005D950
	public InfoMe()
	{
		for (int i = 0; i < this.charId.Length; i++)
		{
			this.charId[i] = new int[3];
		}
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00006497 File Offset: 0x00004697
	public static InfoMe gI()
	{
		if (InfoMe.me == null)
		{
			InfoMe.me = new InfoMe();
		}
		return InfoMe.me;
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x0005F7A8 File Offset: 0x0005D9A8
	public void loadCharId()
	{
		for (int i = 0; i < this.charId.Length; i++)
		{
			this.charId[i] = new int[3];
		}
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x0005F7DC File Offset: 0x0005D9DC
	public void paint(mGraphics g)
	{
		if (this.Equals(GameScr.info2) && GameScr.gI().isVS())
		{
			return;
		}
		if (this.Equals(GameScr.info2) && GameScr.gI().popUpYesNo != null)
		{
			return;
		}
		if (!GameScr.isPaint)
		{
			return;
		}
		if (GameCanvas.currentScreen != GameScr.gI())
		{
			return;
		}
		if (ChatPopup.serverChatPopUp != null)
		{
			return;
		}
		if (!this.isUpdate)
		{
			return;
		}
		if (global::Char.ischangingMap)
		{
			return;
		}
		if (GameCanvas.panel.isShow && this.Equals(GameScr.info2))
		{
			return;
		}
		g.translate(-g.getTranslateX(), -g.getTranslateY());
		g.setClip(0, 0, GameCanvas.w, GameCanvas.h);
		if (this.info != null)
		{
			this.info.paint(g, this.cmx, this.cmy, this.dir);
			if (this.info.info == null || this.info.info.charInfo == null || this.cmdChat != null || !GameCanvas.isTouch)
			{
			}
			if (this.info.info == null || this.info.info.charInfo == null || this.cmdChat != null)
			{
			}
		}
		if (this.info.info != null && this.info.info.charInfo == null && this.charId != null)
		{
			SmallImage.drawSmallImage(g, this.charId[global::Char.myCharz().cgender][this.f], this.cmx, this.cmy + 3 + ((GameCanvas.gameTick % 10 <= 5) ? 0 : 1), (this.dir != 1) ? 2 : 0, StaticObj.VCENTER_HCENTER);
		}
		g.translate(-g.getTranslateX(), -g.getTranslateY());
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x000064B2 File Offset: 0x000046B2
	public void hide()
	{
		this.info.hide();
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x0005F9E0 File Offset: 0x0005DBE0
	public void moveCamera()
	{
		if (this.cmy != this.cmtoY)
		{
			this.cmvy = this.cmtoY - this.cmy << 2;
			this.cmdy += this.cmvy;
			this.cmy += this.cmdy >> 4;
			this.cmdy &= 15;
		}
		if (this.cmx != this.cmtoX)
		{
			this.cmvx = this.cmtoX - this.cmx << 2;
			this.cmdx += this.cmvx;
			this.cmx += this.cmdx >> 4;
			this.cmdx &= 15;
		}
		this.tF++;
		if (this.tF == 5)
		{
			this.tF = 0;
			if (this.f == 0)
			{
				this.f = 1;
			}
			else
			{
				this.f = 0;
			}
		}
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x000064BF File Offset: 0x000046BF
	public void doClick(int t)
	{
		this.timeDelay = t;
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x0005FAE8 File Offset: 0x0005DCE8
	public void update()
	{
		if (this.Equals(GameScr.info2) && GameScr.gI().popUpYesNo != null)
		{
			return;
		}
		if (!this.isUpdate)
		{
			return;
		}
		this.moveCamera();
		if (this.info == null)
		{
			return;
		}
		if (this.info != null && this.info.info == null)
		{
			return;
		}
		if (!this.isDone)
		{
			if (this.timeDelay > 0)
			{
				this.timeDelay--;
				if (this.timeDelay == 0)
				{
					GameCanvas.panel.setTypeMessage();
					GameCanvas.panel.show();
				}
			}
			if (GameCanvas.gameTick % 3 == 0)
			{
				if (global::Char.myCharz().cdir == 1)
				{
					this.cmtoX = global::Char.myCharz().cx - 20 - GameScr.cmx;
				}
				if (global::Char.myCharz().cdir == -1)
				{
					this.cmtoX = global::Char.myCharz().cx + 20 - GameScr.cmx;
				}
				if (this.cmtoX <= 24)
				{
					this.cmtoX += this.info.sayWidth / 2;
				}
				if (this.cmtoX >= GameCanvas.w - 24)
				{
					this.cmtoX -= this.info.sayWidth / 2;
				}
				this.cmtoY = global::Char.myCharz().cy - 40 - GameScr.cmy;
				if (this.info.says != null && this.cmtoY < (this.info.says.Length + 1) * 12 + 10)
				{
					this.cmtoY = (this.info.says.Length + 1) * 12 + 10;
				}
				if (this.info.info.charInfo != null)
				{
					if (GameCanvas.w - 50 > 155 + this.info.W)
					{
						this.cmtoX = GameCanvas.w - 60 - this.info.W / 2;
						this.cmtoY = this.info.H + 10;
					}
					else
					{
						this.cmtoX = GameCanvas.w - 20 - this.info.W / 2;
						this.cmtoY = 45 + this.info.H;
						if (GameCanvas.w > GameCanvas.h || GameCanvas.w < 220)
						{
							this.cmtoX = GameCanvas.w - 20 - this.info.W / 2;
							this.cmtoY = this.info.H + 10;
						}
					}
				}
			}
			if (this.cmx > global::Char.myCharz().cx - GameScr.cmx)
			{
				this.dir = -1;
			}
			else
			{
				this.dir = 1;
			}
		}
		if (this.info.info != null)
		{
			if (this.info.infoWaitToShow.size() > 1)
			{
				if (this.info.info.timeCount == 0)
				{
					this.info.time++;
					if (this.info.time >= this.info.info.speed)
					{
						this.info.time = 0;
						this.info.infoWaitToShow.removeElementAt(0);
						InfoItem infoItem = (InfoItem)this.info.infoWaitToShow.firstElement();
						this.info.info = infoItem;
						this.info.getInfo();
					}
				}
				else
				{
					this.info.info.curr = mSystem.currentTimeMillis();
					if (this.info.info.curr - this.info.info.last >= 100L)
					{
						this.info.info.last = mSystem.currentTimeMillis();
						this.info.info.timeCount--;
					}
					if (this.info.info.timeCount == 0)
					{
						this.info.infoWaitToShow.removeElementAt(0);
						if (this.info.infoWaitToShow.size() == 0)
						{
							return;
						}
						InfoItem infoItem2 = (InfoItem)this.info.infoWaitToShow.firstElement();
						this.info.info = infoItem2;
						this.info.getInfo();
					}
				}
			}
			else if (this.info.infoWaitToShow.size() == 1)
			{
				if (this.info.info.timeCount == 0)
				{
					this.info.time++;
					if (this.info.time >= this.info.info.speed)
					{
						this.isDone = true;
					}
					if (this.info.time == this.info.info.speed)
					{
						this.cmtoY = -40;
						this.cmtoX = global::Char.myCharz().cx - GameScr.cmx + ((global::Char.myCharz().cdir != 1) ? 20 : -20);
					}
					if (this.info.time >= this.info.info.speed + 20)
					{
						this.info.time = 0;
						this.info.infoWaitToShow.removeAllElements();
						this.info.says = null;
					}
				}
				else
				{
					this.info.info.curr = mSystem.currentTimeMillis();
					if (this.info.info.curr - this.info.info.last >= 100L)
					{
						this.info.info.last = mSystem.currentTimeMillis();
						this.info.info.timeCount--;
					}
					if (this.info.info.timeCount == 0)
					{
						this.isDone = true;
						this.cmtoY = -40;
						this.cmtoX = global::Char.myCharz().cx - GameScr.cmx + ((global::Char.myCharz().cdir != 1) ? 20 : -20);
						this.info.time = 0;
						this.info.infoWaitToShow.removeAllElements();
						this.info.says = null;
						this.cmdChat = null;
					}
				}
			}
		}
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x000064C8 File Offset: 0x000046C8
	public void addInfoWithChar(string s, global::Char c, bool isChatServer)
	{
		this.playerID = c.charID;
		this.info.addInfo(s, 3, c, isChatServer);
		this.isDone = false;
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x00060150 File Offset: 0x0005E350
	public void addInfo(string s, int Type)
	{
		if (s.Contains("vật phẩm của người"))
		{
			global::Char.myCharz().itemFocus = null;
			return;
		}
		if (s.Contains("Không thể thực hiện"))
		{
			s = "TeaM fix dồi";
		}
		if (s.Contains("Thể lực đã cạn"))
		{
			Sound.playSoundP(SoundMn.XAYDA_KAME, 10f);
			return;
		}
		s = Res.changeString(s);
		if (this.info.infoWaitToShow.size() > 0 && s.Equals(((InfoItem)this.info.infoWaitToShow.lastElement()).s))
		{
			return;
		}
		if (this.info.infoWaitToShow.size() > 10)
		{
			for (int i = 0; i < 5; i++)
			{
				this.info.infoWaitToShow.removeElementAt(0);
			}
		}
		global::Char cInfo = null;
		this.info.addInfo(s, Type, cInfo, false);
		if (this.info.infoWaitToShow.size() == 1)
		{
			this.cmy = 0;
			this.cmx = global::Char.myCharz().cx - GameScr.cmx + ((global::Char.myCharz().cdir != 1) ? 20 : -20);
		}
		this.isDone = false;
	}

	// Token: 0x04000CE2 RID: 3298
	public static InfoMe me;

	// Token: 0x04000CE3 RID: 3299
	public int[][] charId = new int[3][];

	// Token: 0x04000CE4 RID: 3300
	public Info info = new Info();

	// Token: 0x04000CE5 RID: 3301
	public int dir;

	// Token: 0x04000CE6 RID: 3302
	public int f;

	// Token: 0x04000CE7 RID: 3303
	public int tF;

	// Token: 0x04000CE8 RID: 3304
	public int cmtoY;

	// Token: 0x04000CE9 RID: 3305
	public int cmy;

	// Token: 0x04000CEA RID: 3306
	public int cmdy;

	// Token: 0x04000CEB RID: 3307
	public int cmvy;

	// Token: 0x04000CEC RID: 3308
	public int cmyLim;

	// Token: 0x04000CED RID: 3309
	public int cmtoX;

	// Token: 0x04000CEE RID: 3310
	public int cmx;

	// Token: 0x04000CEF RID: 3311
	public int cmdx;

	// Token: 0x04000CF0 RID: 3312
	public int cmvx;

	// Token: 0x04000CF1 RID: 3313
	public int cmxLim;

	// Token: 0x04000CF2 RID: 3314
	public bool isDone;

	// Token: 0x04000CF3 RID: 3315
	public bool isUpdate = true;

	// Token: 0x04000CF4 RID: 3316
	public int timeDelay;

	// Token: 0x04000CF5 RID: 3317
	public int playerID;

	// Token: 0x04000CF6 RID: 3318
	public int timeCount;

	// Token: 0x04000CF7 RID: 3319
	public Command cmdChat;

	// Token: 0x04000CF8 RID: 3320
	public bool isShow;
}
