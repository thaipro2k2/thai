﻿using System;

// Token: 0x0200005C RID: 92
public class ItemOptionTemplate
{
	// Token: 0x04000553 RID: 1363
	public int id;

	// Token: 0x04000554 RID: 1364
	public string name;

	// Token: 0x04000555 RID: 1365
	public int type;
}
