﻿using System;

// Token: 0x0200005E RID: 94
public class ItemTemplates
{
	// Token: 0x06000339 RID: 825 RVA: 0x00004BBC File Offset: 0x00002DBC
	public static void add(ItemTemplate it)
	{
		ItemTemplates.itemTemplates.put(it.id, it);
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00004BD4 File Offset: 0x00002DD4
	public static ItemTemplate get(short id)
	{
		return (ItemTemplate)ItemTemplates.itemTemplates.get(id);
	}

	// Token: 0x0600033B RID: 827 RVA: 0x00004BEB File Offset: 0x00002DEB
	public static short getPart(short itemTemplateID)
	{
		return ItemTemplates.get(itemTemplateID).part;
	}

	// Token: 0x0600033C RID: 828 RVA: 0x00004BF8 File Offset: 0x00002DF8
	public static short getIcon(short itemTemplateID)
	{
		return ItemTemplates.get(itemTemplateID).iconID;
	}

	// Token: 0x04000563 RID: 1379
	public static MyHashTable itemTemplates = new MyHashTable();
}
