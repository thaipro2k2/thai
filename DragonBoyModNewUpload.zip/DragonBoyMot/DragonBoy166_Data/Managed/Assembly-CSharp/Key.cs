﻿using System;

// Token: 0x02000060 RID: 96
public class Key
{
	// Token: 0x0600034B RID: 843 RVA: 0x00004C05 File Offset: 0x00002E05
	public static void mapKeyPC()
	{
		if (!Main.isPC)
		{
			return;
		}
		Key.UP = 15;
		Key.DOWN = 16;
		Key.LEFT = 17;
		Key.RIGHT = 18;
	}

	// Token: 0x0400056C RID: 1388
	public static int NUM0;

	// Token: 0x0400056D RID: 1389
	public static int NUM1 = 1;

	// Token: 0x0400056E RID: 1390
	public static int NUM2 = 2;

	// Token: 0x0400056F RID: 1391
	public static int NUM3 = 3;

	// Token: 0x04000570 RID: 1392
	public static int NUM4 = 4;

	// Token: 0x04000571 RID: 1393
	public static int NUM5 = 5;

	// Token: 0x04000572 RID: 1394
	public static int NUM6 = 6;

	// Token: 0x04000573 RID: 1395
	public static int NUM7 = 7;

	// Token: 0x04000574 RID: 1396
	public static int NUM8 = 8;

	// Token: 0x04000575 RID: 1397
	public static int NUM9 = 9;

	// Token: 0x04000576 RID: 1398
	public static int STAR = 10;

	// Token: 0x04000577 RID: 1399
	public static int BOUND = 11;

	// Token: 0x04000578 RID: 1400
	public static int UP = 12;

	// Token: 0x04000579 RID: 1401
	public static int DOWN = 13;

	// Token: 0x0400057A RID: 1402
	public static int LEFT = 14;

	// Token: 0x0400057B RID: 1403
	public static int RIGHT = 15;

	// Token: 0x0400057C RID: 1404
	public static int FIRE = 16;

	// Token: 0x0400057D RID: 1405
	public static int LEFT_SOFTKEY = 17;

	// Token: 0x0400057E RID: 1406
	public static int RIGHT_SOFTKEY = 18;

	// Token: 0x0400057F RID: 1407
	public static int CLEAR = 19;

	// Token: 0x04000580 RID: 1408
	public static int BACK = 20;
}
