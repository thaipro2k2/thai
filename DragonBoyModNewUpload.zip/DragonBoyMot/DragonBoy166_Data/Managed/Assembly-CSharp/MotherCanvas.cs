﻿using System;

// Token: 0x020000B9 RID: 185
public class MotherCanvas
{
	// Token: 0x06000932 RID: 2354 RVA: 0x000073ED File Offset: 0x000055ED
	public MotherCanvas()
	{
		this.checkZoomLevel(this.getWidth(), this.getHeight());
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x00089360 File Offset: 0x00087560
	public void checkZoomLevel(int w, int h)
	{
		if (Main.isWindowsPhone)
		{
			mGraphics.zoomLevel = 2;
			if (w * h >= 2073600)
			{
				mGraphics.zoomLevel = 4;
			}
			else if (w * h > 384000)
			{
				mGraphics.zoomLevel = 3;
			}
		}
		else if (!Main.isPC)
		{
			if (Main.isIpod)
			{
				mGraphics.zoomLevel = 2;
			}
			else if (w * h >= 2073600)
			{
				mGraphics.zoomLevel = 4;
			}
			else if (w * h >= 691200)
			{
				mGraphics.zoomLevel = 3;
			}
			else if (w * h > 153600)
			{
				mGraphics.zoomLevel = 3;
			}
		}
		else
		{
			mGraphics.zoomLevel = 2;
			if (w * h < 480000)
			{
				mGraphics.zoomLevel = 1;
			}
		}
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x000070D5 File Offset: 0x000052D5
	public int getWidth()
	{
		return (int)ScaleGUI.WIDTH;
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x000070DD File Offset: 0x000052DD
	public int getHeight()
	{
		return (int)ScaleGUI.HEIGHT;
	}

	// Token: 0x06000936 RID: 2358 RVA: 0x00007416 File Offset: 0x00005616
	public void setChildCanvas(GameCanvas tCanvas)
	{
		this.tCanvas = tCanvas;
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x0000741F File Offset: 0x0000561F
	protected void paint(mGraphics g)
	{
		this.tCanvas.paint(g);
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x0000742D File Offset: 0x0000562D
	protected void keyPressed(int keyCode)
	{
		this.tCanvas.keyPressedz(keyCode);
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x0000743B File Offset: 0x0000563B
	protected void keyReleased(int keyCode)
	{
		this.tCanvas.keyReleasedz(keyCode);
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x00007449 File Offset: 0x00005649
	protected void pointerDragged(int x, int y)
	{
		x /= mGraphics.zoomLevel;
		y /= mGraphics.zoomLevel;
		this.tCanvas.pointerDragged(x, y);
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x0000746A File Offset: 0x0000566A
	protected void pointerPressed(int x, int y)
	{
		x /= mGraphics.zoomLevel;
		y /= mGraphics.zoomLevel;
		this.tCanvas.pointerPressed(x, y);
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x0000748B File Offset: 0x0000568B
	protected void pointerReleased(int x, int y)
	{
		x /= mGraphics.zoomLevel;
		y /= mGraphics.zoomLevel;
		this.tCanvas.pointerReleased(x, y);
	}

	// Token: 0x0600093D RID: 2365 RVA: 0x00089430 File Offset: 0x00087630
	public int getWidthz()
	{
		int width = this.getWidth();
		return width / mGraphics.zoomLevel + width % mGraphics.zoomLevel;
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x00089454 File Offset: 0x00087654
	public int getHeightz()
	{
		int height = this.getHeight();
		return height / mGraphics.zoomLevel + height % mGraphics.zoomLevel;
	}

	// Token: 0x04001128 RID: 4392
	public static MotherCanvas instance;

	// Token: 0x04001129 RID: 4393
	public GameCanvas tCanvas;

	// Token: 0x0400112A RID: 4394
	public int zoomLevel = 1;

	// Token: 0x0400112B RID: 4395
	public Image imgCache;

	// Token: 0x0400112C RID: 4396
	private int[] imgRGBCache;

	// Token: 0x0400112D RID: 4397
	private int newWidth;

	// Token: 0x0400112E RID: 4398
	private int newHeight;

	// Token: 0x0400112F RID: 4399
	private int[] output;

	// Token: 0x04001130 RID: 4400
	private int OUTPUTSIZE = 20;
}
