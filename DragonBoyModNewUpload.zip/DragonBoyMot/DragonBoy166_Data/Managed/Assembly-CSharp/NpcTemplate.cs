﻿using System;

// Token: 0x02000068 RID: 104
public class NpcTemplate
{
	// Token: 0x040005DF RID: 1503
	public int npcTemplateId;

	// Token: 0x040005E0 RID: 1504
	public string name;

	// Token: 0x040005E1 RID: 1505
	public int headId;

	// Token: 0x040005E2 RID: 1506
	public int bodyId;

	// Token: 0x040005E3 RID: 1507
	public int legId;

	// Token: 0x040005E4 RID: 1508
	public string[][] menu;
}
