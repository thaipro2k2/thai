﻿using System;

// Token: 0x02000069 RID: 105
public class PKFlag
{
	// Token: 0x040005E5 RID: 1509
	public sbyte cflag;

	// Token: 0x040005E6 RID: 1510
	public int IDimageFlag;
}
