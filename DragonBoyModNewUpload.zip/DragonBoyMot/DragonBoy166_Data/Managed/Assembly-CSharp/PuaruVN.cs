﻿using System;
using System.IO;
using System.Net;
using System.Text;

// Token: 0x020000E0 RID: 224
public class PuaruVN
{
	// Token: 0x0600094C RID: 2380 RVA: 0x000074AC File Offset: 0x000056AC
	public static string Web(string noidung)
	{
		WebRequest webRequest = WebRequest.Create(noidung);
		webRequest.Method = "GET";
		webRequest.ContentType = "application/x-www-form-urlencoded";
		return new StreamReader(webRequest.GetResponse().GetResponseStream(), Encoding.UTF8).ReadToEnd();
	}
}
