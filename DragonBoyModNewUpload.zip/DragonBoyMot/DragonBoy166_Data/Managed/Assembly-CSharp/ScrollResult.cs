﻿using System;

// Token: 0x02000073 RID: 115
public class ScrollResult
{
	// Token: 0x04000668 RID: 1640
	public bool isDowning;

	// Token: 0x04000669 RID: 1641
	public int selected = -1;

	// Token: 0x0400066A RID: 1642
	public bool isFinish;
}
