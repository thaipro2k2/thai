﻿using System;

// Token: 0x02000077 RID: 119
public class SkillOptionTemplate
{
	// Token: 0x04000691 RID: 1681
	public int id;

	// Token: 0x04000692 RID: 1682
	public string name;
}
