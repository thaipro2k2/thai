﻿using System;

// Token: 0x0200007A RID: 122
public class Skills
{
	// Token: 0x060003D1 RID: 977 RVA: 0x00005220 File Offset: 0x00003420
	public static void add(Skill skill)
	{
		Skills.skills.put(skill.skillId, skill);
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x00005238 File Offset: 0x00003438
	public static Skill get(short skillId)
	{
		return (Skill)Skills.skills.get(skillId);
	}

	// Token: 0x040006A2 RID: 1698
	public static MyHashTable skills = new MyHashTable();
}
