﻿using System;

// Token: 0x020000B0 RID: 176
public class SplashScr : mScreen
{
	// Token: 0x06000891 RID: 2193 RVA: 0x00006E2D File Offset: 0x0000502D
	public SplashScr()
	{
		SplashScr.instance = this;
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x00006E49 File Offset: 0x00005049
	public static void loadSplashScr()
	{
		SplashScr.splashScrStat = 0;
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x000813A8 File Offset: 0x0007F5A8
	public override void update()
	{
		if (SplashScr.splashScrStat == 30 && !this.isCheckConnect)
		{
			this.isCheckConnect = true;
			if (Rms.loadRMSInt("isPlaySound") != -1)
			{
				GameCanvas.isPlaySound = (Rms.loadRMSInt("isPlaySound") == 1);
			}
			if (GameCanvas.isPlaySound)
			{
				SoundMn.gI().loadSound(TileMap.mapID);
			}
			SoundMn.gI().getStrOption();
			if (Rms.loadRMSInt("svselect") == -1)
			{
				ServerListScreen.loadIP();
			}
			else
			{
				ServerListScreen.loadIP();
			}
		}
		SplashScr.splashScrStat++;
		ServerListScreen.updateDeleteData();
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x00081454 File Offset: 0x0007F654
	public static void loadIP()
	{
		if (Rms.loadRMSInt("svselect") == -1)
		{
			int num = 0;
			if ((int)mResources.language > 0)
			{
				for (int i = 0; i < (int)mResources.language; i++)
				{
					num += ServerListScreen.lengthServer[i];
				}
			}
			if ((int)ServerListScreen.serverPriority == -1)
			{
				ServerListScreen.ipSelect = num + Res.random(0, ServerListScreen.lengthServer[(int)mResources.language]);
			}
			else
			{
				ServerListScreen.ipSelect = (int)ServerListScreen.serverPriority;
			}
			Rms.saveRMSInt("svselect", ServerListScreen.ipSelect);
			GameMidlet.IP = ServerListScreen.address[ServerListScreen.ipSelect];
			GameMidlet.PORT = (int)ServerListScreen.port[ServerListScreen.ipSelect];
			mResources.loadLanguague(ServerListScreen.language[ServerListScreen.ipSelect]);
			LoginScr.serverName = ServerListScreen.nameServer[ServerListScreen.ipSelect];
			GameCanvas.connect();
		}
		else
		{
			ServerListScreen.ipSelect = Rms.loadRMSInt("svselect");
			string text = Rms.loadRMSString("acc");
			string text2 = Rms.loadRMSString("userAo" + ServerListScreen.ipSelect);
			if ((text == null || text.Equals(string.Empty)) && (text2 == null || text2.Equals(string.Empty)))
			{
				int num2 = 0;
				if ((int)mResources.language > 0)
				{
					for (int j = 0; j < (int)mResources.language; j++)
					{
						num2 += ServerListScreen.lengthServer[j];
					}
				}
				if ((int)ServerListScreen.serverPriority == -1)
				{
					ServerListScreen.ipSelect = num2 + Res.random(0, ServerListScreen.lengthServer[(int)mResources.language]);
				}
				else
				{
					ServerListScreen.ipSelect = (int)ServerListScreen.serverPriority;
				}
			}
			GameMidlet.IP = ServerListScreen.address[ServerListScreen.ipSelect];
			GameMidlet.PORT = (int)ServerListScreen.port[ServerListScreen.ipSelect];
			mResources.loadLanguague(ServerListScreen.language[ServerListScreen.ipSelect]);
			LoginScr.serverName = ServerListScreen.nameServer[ServerListScreen.ipSelect];
			GameCanvas.connect();
		}
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x00081640 File Offset: 0x0007F840
	public override void paint(mGraphics g)
	{
		if (SplashScr.imgLogo != null && SplashScr.splashScrStat < 30)
		{
			g.setColor(16777215);
			g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
			g.drawImage(SplashScr.imgLogo, GameCanvas.w / 2, GameCanvas.h / 2, 3);
		}
		if (SplashScr.nData != -1)
		{
			g.setColor(0);
			g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
			g.drawImage(LoginScr.imgTitle, GameCanvas.w / 2, GameCanvas.h / 2 - 24, StaticObj.BOTTOM_HCENTER);
			GameCanvas.paintShukiren(GameCanvas.hw, GameCanvas.h / 2 + 24, g);
			mFont.tahoma_7b_white.drawString(g, mResources.downloading_data + SplashScr.nData * 100 / SplashScr.maxData + "%", GameCanvas.w / 2, GameCanvas.h / 2, 2);
		}
		else if (SplashScr.splashScrStat >= 30)
		{
			g.setColor(0);
			g.fillRect(0, 0, GameCanvas.w, GameCanvas.h);
			GameCanvas.paintShukiren(GameCanvas.hw, GameCanvas.hh, g);
			if (ServerListScreen.cmdDeleteRMS != null)
			{
				mFont.tahoma_7_white.drawString(g, mResources.xoadulieu, GameCanvas.w - 2, GameCanvas.h - 15, 1, mFont.tahoma_7_grey);
			}
		}
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x00006E51 File Offset: 0x00005051
	public static void loadImg()
	{
		SplashScr.imgLogo = GameCanvas.loadImage("/gamelogo.png");
	}

	// Token: 0x04000F9B RID: 3995
	public static int splashScrStat;

	// Token: 0x04000F9C RID: 3996
	private bool isCheckConnect;

	// Token: 0x04000F9D RID: 3997
	private bool isSwitchToLogin;

	// Token: 0x04000F9E RID: 3998
	public static int nData = -1;

	// Token: 0x04000F9F RID: 3999
	public static int maxData = -1;

	// Token: 0x04000FA0 RID: 4000
	public static SplashScr instance;

	// Token: 0x04000FA1 RID: 4001
	public static Image imgLogo;
}
