﻿using System;

// Token: 0x02000087 RID: 135
public class TaskTemplate
{
	// Token: 0x040006ED RID: 1773
	public short taskId;

	// Token: 0x040006EE RID: 1774
	public string name;

	// Token: 0x040006EF RID: 1775
	public string[] subNames;
}
