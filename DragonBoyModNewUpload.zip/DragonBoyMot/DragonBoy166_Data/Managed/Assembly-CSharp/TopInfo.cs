﻿using System;

// Token: 0x0200008A RID: 138
public class TopInfo
{
	// Token: 0x0400070C RID: 1804
	public int headID;

	// Token: 0x0400070D RID: 1805
	public short body;

	// Token: 0x0400070E RID: 1806
	public short leg;

	// Token: 0x0400070F RID: 1807
	public string name;

	// Token: 0x04000710 RID: 1808
	public string info;

	// Token: 0x04000711 RID: 1809
	public int pId;

	// Token: 0x04000712 RID: 1810
	public int rank;

	// Token: 0x04000713 RID: 1811
	public string info2;
}
