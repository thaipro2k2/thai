﻿using System;

namespace Assets.src.g
{
	// Token: 0x020000A5 RID: 165
	internal class Mabu : global::Char
	{
		// Token: 0x06000713 RID: 1811 RVA: 0x00006600 File Offset: 0x00004800
		public Mabu()
		{
			this.getData1();
			this.getData2();
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0006238C File Offset: 0x0006058C
		public void eat(int id)
		{
			this.effEat = new Effect(105, this.cx, this.cy + 20, 2, 1, -1);
			EffecMn.addEff(this.effEat);
			if (id == global::Char.myCharz().charID)
			{
				this.focus = global::Char.myCharz();
			}
			else
			{
				this.focus = GameScr.findCharInMap(id);
			}
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x000623F0 File Offset: 0x000605F0
		public new void checkFrameTick(int[] array)
		{
			if ((int)this.skillID == 0)
			{
				if (this.tick == 11)
				{
					this.addFoot = true;
					Effect me = new Effect(19, this.cx, this.cy + 20, 2, 1, -1);
					EffecMn.addEff(me);
				}
				if (this.tick >= array.Length - 1)
				{
					this.skillID = 2;
					return;
				}
			}
			if ((int)this.skillID == 1 && this.tick == array.Length - 1)
			{
				this.skillID = 3;
				this.cy -= 15;
				return;
			}
			this.tick++;
			if (this.tick > array.Length - 1)
			{
				this.tick = 0;
			}
			this.frame = array[this.tick];
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x000624BC File Offset: 0x000606BC
		public void getData1()
		{
			Mabu.data1 = null;
			Mabu.data1 = new EffectData();
			string patch = string.Concat(new object[]
			{
				"/x",
				mGraphics.zoomLevel,
				"/effectdata/",
				102,
				"/data"
			});
			try
			{
				Mabu.data1.readData2(patch);
				Mabu.data1.img = GameCanvas.loadImage("/effectdata/" + 102 + "/img.png");
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x00062560 File Offset: 0x00060760
		public void setSkill(sbyte id, short x, short y, global::Char[] charHit, int[] damageHit)
		{
			this.skillID = id;
			this.xTo = (int)x;
			this.yTo = (int)y;
			this.lastDir = this.cdir;
			this.cdir = ((this.xTo <= this.cx) ? -1 : 1);
			this.charAttack = charHit;
			this.damageAttack = damageHit;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x000625BC File Offset: 0x000607BC
		public void getData2()
		{
			Mabu.data2 = null;
			Mabu.data2 = new EffectData();
			string patch = string.Concat(new object[]
			{
				"/x",
				mGraphics.zoomLevel,
				"/effectdata/",
				103,
				"/data"
			});
			try
			{
				Mabu.data2.readData2(patch);
				Mabu.data2.img = GameCanvas.loadImage("/effectdata/" + 103 + "/img.png");
				Res.outz("read xong data");
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x0006266C File Offset: 0x0006086C
		public override void update()
		{
			if (this.focus != null)
			{
				if (this.effEat.t >= 30)
				{
					this.effEat.x += (this.cx - this.effEat.x) / 4;
					this.effEat.y += (this.cy - this.effEat.y) / 4;
					this.focus.cx = this.effEat.x;
					this.focus.cy = this.effEat.y;
					this.focus.isMabuHold = true;
				}
				else
				{
					this.effEat.trans = ((this.effEat.x <= this.focus.cx) ? 0 : 1);
					this.effEat.x += (this.focus.cx - this.effEat.x) / 3;
					this.effEat.y += (this.focus.cy - this.effEat.y) / 3;
				}
			}
			if ((int)this.skillID != -1)
			{
				if ((int)this.skillID == 0 && this.addFoot && GameCanvas.gameTick % 2 == 0)
				{
					this.dx += ((this.xTo <= this.cx) ? -30 : 30);
					EffecMn.addEff(new Effect(103, this.cx + this.dx, this.cy + 20, 2, 1, -1)
					{
						trans = ((this.xTo <= this.cx) ? 1 : 0)
					});
					if ((this.cdir == 1 && this.cx + this.dx >= this.xTo) || (this.cdir == -1 && this.cx + this.dx <= this.xTo))
					{
						this.addFoot = false;
						this.skillID = -1;
						this.dx = 0;
						this.tick = 0;
						this.cdir = this.lastDir;
						for (int i = 0; i < this.charAttack.Length; i++)
						{
							this.charAttack[i].doInjure(this.damageAttack[i], 0, false, false);
						}
					}
				}
				if ((int)this.skillID == 3)
				{
					this.xTo = this.charAttack[this.pIndex].cx;
					this.yTo = this.charAttack[this.pIndex].cy;
					this.cx += (this.xTo - this.cx) / 3;
					this.cy += (this.yTo - this.cy) / 3;
					if (GameCanvas.gameTick % 5 == 0)
					{
						Effect me = new Effect(19, this.cx, this.cy, 2, 1, -1);
						EffecMn.addEff(me);
					}
					if (Res.abs(this.cx - this.xTo) <= 20 && Res.abs(this.cy - this.yTo) <= 20)
					{
						this.cx = this.xTo;
						this.cy = this.yTo;
						this.charAttack[this.pIndex].doInjure(this.damageAttack[this.pIndex], 0, false, false);
						this.pIndex++;
						if (this.pIndex == this.charAttack.Length)
						{
							this.skillID = -1;
							this.pIndex = 0;
						}
					}
				}
				return;
			}
			base.update();
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x00062A20 File Offset: 0x00060C20
		public override void paint(mGraphics g)
		{
			if ((int)this.skillID != -1)
			{
				base.paintShadow(g);
				g.translate(0, GameCanvas.transY);
				this.checkFrameTick(Mabu.skills[(int)this.skillID]);
				if ((int)this.skillID == 0 || (int)this.skillID == 1)
				{
					Mabu.data1.paintFrame(g, this.frame, this.cx, this.cy + this.fy, (this.cdir != 1) ? 1 : 0, 2);
				}
				else
				{
					Mabu.data2.paintFrame(g, this.frame, this.cx, this.cy + this.fy, (this.cdir != 1) ? 1 : 0, 2);
				}
				g.translate(0, -GameCanvas.transY);
			}
			else
			{
				base.paint(g);
			}
		}

		// Token: 0x04000D51 RID: 3409
		public static EffectData data1;

		// Token: 0x04000D52 RID: 3410
		public static EffectData data2;

		// Token: 0x04000D53 RID: 3411
		private new int tick;

		// Token: 0x04000D54 RID: 3412
		private int lastDir;

		// Token: 0x04000D55 RID: 3413
		private bool addFoot;

		// Token: 0x04000D56 RID: 3414
		private Effect effEat;

		// Token: 0x04000D57 RID: 3415
		private new global::Char focus;

		// Token: 0x04000D58 RID: 3416
		public int xTo;

		// Token: 0x04000D59 RID: 3417
		public int yTo;

		// Token: 0x04000D5A RID: 3418
		public bool haftBody;

		// Token: 0x04000D5B RID: 3419
		public bool change;

		// Token: 0x04000D5C RID: 3420
		private global::Char[] charAttack;

		// Token: 0x04000D5D RID: 3421
		private int[] damageAttack;

		// Token: 0x04000D5E RID: 3422
		private int dx;

		// Token: 0x04000D5F RID: 3423
		public static int[] skill1 = new int[]
		{
			0,
			0,
			1,
			1,
			2,
			2,
			3,
			3,
			4,
			4,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5
		};

		// Token: 0x04000D60 RID: 3424
		public static int[] skill2 = new int[]
		{
			0,
			0,
			6,
			6,
			7,
			7,
			8,
			8,
			9,
			9,
			9,
			9,
			9,
			10,
			10
		};

		// Token: 0x04000D61 RID: 3425
		public static int[] skill3 = new int[]
		{
			0,
			0,
			1,
			1,
			2,
			2,
			3,
			3,
			4,
			4,
			5,
			5,
			6,
			6,
			7,
			7,
			8,
			8,
			9,
			9,
			10,
			10,
			11,
			11,
			12,
			12
		};

		// Token: 0x04000D62 RID: 3426
		public static int[] skill4 = new int[]
		{
			13,
			13,
			14,
			14,
			15,
			15,
			16,
			16
		};

		// Token: 0x04000D63 RID: 3427
		public static int[][] skills = new int[][]
		{
			Mabu.skill1,
			Mabu.skill2,
			Mabu.skill3,
			Mabu.skill4
		};

		// Token: 0x04000D64 RID: 3428
		public sbyte skillID = -1;

		// Token: 0x04000D65 RID: 3429
		private int frame;

		// Token: 0x04000D66 RID: 3430
		private int pIndex;
	}
}
