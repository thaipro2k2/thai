﻿using System;

// Token: 0x020000BA RID: 186
// (Invoke) Token: 0x06000940 RID: 2368
public delegate void ActionChat(string str);
