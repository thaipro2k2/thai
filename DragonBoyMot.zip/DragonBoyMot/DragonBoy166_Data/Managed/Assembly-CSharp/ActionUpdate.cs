﻿using System;

// Token: 0x020000BC RID: 188
// (Invoke) Token: 0x06000948 RID: 2376
public delegate void ActionUpdate();
