﻿using System;

// Token: 0x02000002 RID: 2
public class ArrayCast
{
	// Token: 0x06000002 RID: 2 RVA: 0x000074E4 File Offset: 0x000056E4
	public static sbyte[] cast(byte[] data)
	{
		sbyte[] array = new sbyte[data.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (sbyte)data[i];
		}
		return array;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00007518 File Offset: 0x00005718
	public static byte[] cast(sbyte[] data)
	{
		byte[] array = new byte[data.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)data[i];
		}
		return array;
	}

	// Token: 0x06000004 RID: 4 RVA: 0x0000754C File Offset: 0x0000574C
	public static char[] ToCharArray(sbyte[] data)
	{
		char[] array = new char[data.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (char)data[i];
		}
		return array;
	}
}
