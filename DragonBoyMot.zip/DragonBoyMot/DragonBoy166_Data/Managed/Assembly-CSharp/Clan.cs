﻿using System;

// Token: 0x0200002C RID: 44
public class Clan
{
	// Token: 0x040001D6 RID: 470
	public int ID;

	// Token: 0x040001D7 RID: 471
	public int imgID;

	// Token: 0x040001D8 RID: 472
	public string name = string.Empty;

	// Token: 0x040001D9 RID: 473
	public string slogan = string.Empty;

	// Token: 0x040001DA RID: 474
	public int date;

	// Token: 0x040001DB RID: 475
	public string powerPoint;

	// Token: 0x040001DC RID: 476
	public int currMember;

	// Token: 0x040001DD RID: 477
	public int maxMember = 50;

	// Token: 0x040001DE RID: 478
	public int leaderID;

	// Token: 0x040001DF RID: 479
	public string leaderName;

	// Token: 0x040001E0 RID: 480
	public int level;
}
