﻿using System;

// Token: 0x02000003 RID: 3
public class Cout
{
	// Token: 0x06000006 RID: 6 RVA: 0x000031FC File Offset: 0x000013FC
	public static void println(string s)
	{
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000031FC File Offset: 0x000013FC
	public static void Log(string str)
	{
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000031FC File Offset: 0x000013FC
	public static void LogError(string str)
	{
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000031FC File Offset: 0x000013FC
	public static void LogError2(string str)
	{
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000031FC File Offset: 0x000013FC
	public static void LogError3(string str)
	{
	}

	// Token: 0x0600000B RID: 11 RVA: 0x000031FC File Offset: 0x000013FC
	public static void LogWarning(string str)
	{
	}

	// Token: 0x04000001 RID: 1
	public static int count;
}
