﻿using System;

// Token: 0x02000005 RID: 5
public class DataOutputStream
{
	// Token: 0x06000022 RID: 34 RVA: 0x000032FB File Offset: 0x000014FB
	public void writeShort(short i)
	{
		this.w.writeShort(i);
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00003309 File Offset: 0x00001509
	public void writeInt(int i)
	{
		this.w.writeInt(i);
	}

	// Token: 0x06000024 RID: 36 RVA: 0x00003317 File Offset: 0x00001517
	public void write(sbyte[] data)
	{
		this.w.writeSByte(data);
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00003325 File Offset: 0x00001525
	public sbyte[] toByteArray()
	{
		return this.w.getData();
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00003332 File Offset: 0x00001532
	public void close()
	{
		this.w.Close();
	}

	// Token: 0x06000027 RID: 39 RVA: 0x0000333F File Offset: 0x0000153F
	public void writeByte(sbyte b)
	{
		this.w.writeByte(b);
	}

	// Token: 0x06000028 RID: 40 RVA: 0x0000334D File Offset: 0x0000154D
	public void writeUTF(string name)
	{
		this.w.writeUTF(name);
	}

	// Token: 0x06000029 RID: 41 RVA: 0x0000335B File Offset: 0x0000155B
	public void writeBoolean(bool b)
	{
		this.w.writeBoolean(b);
	}

	// Token: 0x04000008 RID: 8
	private myWriter w = new myWriter();
}
