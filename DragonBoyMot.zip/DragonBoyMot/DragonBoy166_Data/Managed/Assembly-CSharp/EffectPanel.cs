﻿using System;

// Token: 0x0200003A RID: 58
public class EffectPanel : Effect2
{
	// Token: 0x06000269 RID: 617 RVA: 0x00015C10 File Offset: 0x00013E10
	public static void addServerEffect(int id, int cx, int cy, int loopCount)
	{
		EffectPanel effectPanel = new EffectPanel();
		effectPanel.eff = GameScr.efs[id - 1];
		effectPanel.x = cx;
		effectPanel.y = cy;
		effectPanel.loopCount = (short)loopCount;
		Effect2.vEffect3.addElement(effectPanel);
	}

	// Token: 0x0600026A RID: 618 RVA: 0x00015C54 File Offset: 0x00013E54
	public override void paint(mGraphics g)
	{
		if (mGraphics.zoomLevel == 1)
		{
			GameScr.countEff++;
		}
		if (GameScr.countEff < 8)
		{
			if (this.c != null)
			{
				this.x = this.c.cx;
				this.y = this.c.cy + GameCanvas.transY;
			}
			if (this.m != null)
			{
				this.x = this.m.x;
				this.y = this.m.y + GameCanvas.transY;
			}
			int num = this.x + this.dx0 + this.eff.arrEfInfo[this.i0].dx;
			int num2 = this.y + this.dy0 + this.eff.arrEfInfo[this.i0].dy;
			SmallImage.drawSmallImage(g, this.eff.arrEfInfo[this.i0].idImg, num, num2, this.trans, mGraphics.VCENTER | mGraphics.HCENTER);
		}
	}

	// Token: 0x0600026B RID: 619 RVA: 0x00015D68 File Offset: 0x00013F68
	public override void update()
	{
		if (this.endTime != 0L)
		{
			this.i0++;
			if (this.i0 >= this.eff.arrEfInfo.Length)
			{
				this.i0 = 0;
			}
			if (mSystem.currentTimeMillis() - this.endTime > 0L)
			{
				Effect2.vEffect3.removeElement(this);
			}
		}
		else
		{
			this.i0++;
			if (this.i0 >= this.eff.arrEfInfo.Length)
			{
				this.loopCount -= 1;
				if (this.loopCount <= 0)
				{
					Effect2.vEffect3.removeElement(this);
				}
				else
				{
					this.i0 = 0;
				}
			}
		}
		if (GameCanvas.gameTick % 11 == 0 && this.c != null && this.c != global::Char.myCharz() && !GameScr.vCharInMap.contains(this.c))
		{
			Effect2.vEffect3.removeElement(this);
		}
	}

	// Token: 0x040002BE RID: 702
	public EffectCharPaint eff;

	// Token: 0x040002BF RID: 703
	private int i0;

	// Token: 0x040002C0 RID: 704
	private int dx0;

	// Token: 0x040002C1 RID: 705
	private int dy0;

	// Token: 0x040002C2 RID: 706
	private int x;

	// Token: 0x040002C3 RID: 707
	private int y;

	// Token: 0x040002C4 RID: 708
	private global::Char c;

	// Token: 0x040002C5 RID: 709
	private Mob m;

	// Token: 0x040002C6 RID: 710
	private short loopCount;

	// Token: 0x040002C7 RID: 711
	private long endTime;

	// Token: 0x040002C8 RID: 712
	private int trans;
}
