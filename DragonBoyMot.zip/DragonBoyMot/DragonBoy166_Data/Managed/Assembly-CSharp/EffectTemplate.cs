﻿using System;

// Token: 0x02000052 RID: 82
public class EffectTemplate
{
	// Token: 0x040004AB RID: 1195
	public sbyte id;

	// Token: 0x040004AC RID: 1196
	public sbyte type;

	// Token: 0x040004AD RID: 1197
	public int iconId;

	// Token: 0x040004AE RID: 1198
	public string name;
}
