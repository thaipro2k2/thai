﻿using System;

// Token: 0x0200003E RID: 62
public class Frame
{
	// Token: 0x040002F3 RID: 755
	public short[] dx;

	// Token: 0x040002F4 RID: 756
	public short[] dy;

	// Token: 0x040002F5 RID: 757
	public sbyte[] idImg;
}
