﻿using System;
using UnityEngine;

// Token: 0x020000B7 RID: 183
public class GameMidlet
{
	// Token: 0x06000923 RID: 2339 RVA: 0x00007339 File Offset: 0x00005539
	public GameMidlet()
	{
		this.initGame();
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x00088A34 File Offset: 0x00086C34
	public void initGame()
	{
		GameMidlet.instance = this;
		MotherCanvas.instance = new MotherCanvas();
		Session_ME.gI().setHandler(Controller.gI());
		Session_ME2.gI().setHandler(Controller.gI());
		Session_ME2.isMainSession = false;
		GameMidlet.instance = this;
		GameMidlet.gameCanvas = new GameCanvas();
		GameMidlet.gameCanvas.start();
		SplashScr.loadImg();
		SplashScr.loadSplashScr();
		GameCanvas.currentScreen = new SplashScr();
	}

	// Token: 0x06000926 RID: 2342 RVA: 0x00007367 File Offset: 0x00005567
	public void exit()
	{
		if (Main.typeClient == 6)
		{
			mSystem.exitWP();
		}
		else
		{
			GameCanvas.bRun = false;
			mSystem.gcc();
			this.notifyDestroyed();
		}
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x0000738F File Offset: 0x0000558F
	public static void sendSMS(string data, string to, Command successAction, Command failAction)
	{
		Cout.println("SEND SMS");
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x0000739B File Offset: 0x0000559B
	public static void flatForm(string url)
	{
		Cout.LogWarning("PLATFORM REQUEST: " + url);
		Application.OpenURL(url);
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x000073B3 File Offset: 0x000055B3
	public void notifyDestroyed()
	{
		Main.exit();
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x000073BA File Offset: 0x000055BA
	public void platformRequest(string url)
	{
		Cout.LogWarning("PLATFORM REQUEST: " + url);
		Application.OpenURL(url);
	}

	// Token: 0x04001107 RID: 4359
	public static string IP = "112.213.94.23";

	// Token: 0x04001108 RID: 4360
	public static int PORT = 14445;

	// Token: 0x04001109 RID: 4361
	public static string IP2;

	// Token: 0x0400110A RID: 4362
	public static int PORT2;

	// Token: 0x0400110B RID: 4363
	public static sbyte PROVIDER;

	// Token: 0x0400110C RID: 4364
	public static string VERSION = "1.6.6";

	// Token: 0x0400110D RID: 4365
	public static GameCanvas gameCanvas;

	// Token: 0x0400110E RID: 4366
	public static GameMidlet instance;

	// Token: 0x0400110F RID: 4367
	public static bool isConnect2;

	// Token: 0x04001110 RID: 4368
	public static bool isBackWindowsPhone;
}
