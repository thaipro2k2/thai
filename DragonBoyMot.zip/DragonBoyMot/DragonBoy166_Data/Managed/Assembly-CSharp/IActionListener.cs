﻿using System;

// Token: 0x02000055 RID: 85
public interface IActionListener
{
	// Token: 0x060002D9 RID: 729
	void perform(int idAction, object p);
}
