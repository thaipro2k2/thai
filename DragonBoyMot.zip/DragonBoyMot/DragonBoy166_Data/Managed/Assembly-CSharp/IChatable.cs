﻿using System;

// Token: 0x0200009B RID: 155
public interface IChatable
{
	// Token: 0x060006C9 RID: 1737
	void onChatFromMe(string text, string to);

	// Token: 0x060006CA RID: 1738
	void onCancelChat();
}
