﻿using System;

// Token: 0x0200009F RID: 159
public class InfoItem
{
	// Token: 0x060006DF RID: 1759 RVA: 0x00006448 File Offset: 0x00004648
	public InfoItem(string s)
	{
		this.f = mFont.tahoma_7_green2;
		this.s = s;
		this.speed = 20;
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00006472 File Offset: 0x00004672
	public InfoItem(string s, mFont f, int speed)
	{
		this.f = f;
		this.s = s;
		this.speed = speed;
	}

	// Token: 0x04000CD8 RID: 3288
	public string s;

	// Token: 0x04000CD9 RID: 3289
	private mFont f;

	// Token: 0x04000CDA RID: 3290
	public int speed = 70;

	// Token: 0x04000CDB RID: 3291
	public global::Char charInfo;

	// Token: 0x04000CDC RID: 3292
	public bool isChatServer;

	// Token: 0x04000CDD RID: 3293
	public bool isOnline;

	// Token: 0x04000CDE RID: 3294
	public int timeCount;

	// Token: 0x04000CDF RID: 3295
	public int maxTime;

	// Token: 0x04000CE0 RID: 3296
	public long last;

	// Token: 0x04000CE1 RID: 3297
	public long curr;
}
