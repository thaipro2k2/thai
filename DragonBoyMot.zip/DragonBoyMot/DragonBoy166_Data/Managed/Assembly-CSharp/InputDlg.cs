﻿using System;

// Token: 0x020000A1 RID: 161
public class InputDlg : Dialog
{
	// Token: 0x060006EB RID: 1771 RVA: 0x00060274 File Offset: 0x0005E474
	public InputDlg()
	{
		this.padLeft = 40;
		if (GameCanvas.w <= 176)
		{
			this.padLeft = 10;
		}
		this.tfInput = new TField();
		this.tfInput.x = this.padLeft + 10;
		this.tfInput.y = GameCanvas.h - mScreen.ITEM_HEIGHT - 43;
		this.tfInput.width = GameCanvas.w - 2 * (this.padLeft + 10);
		this.tfInput.height = mScreen.ITEM_HEIGHT + 2;
		this.tfInput.isFocus = true;
		this.right = this.tfInput.cmdClear;
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x0006032C File Offset: 0x0005E52C
	public void show(string info, Command ok, int type)
	{
		this.tfInput.setText(string.Empty);
		this.tfInput.setIputType(type);
		this.info = mFont.tahoma_8b.splitFontArray(info, GameCanvas.w - this.padLeft * 2);
		this.left = new Command(mResources.CLOSE, GameCanvas.gI(), 8882, null);
		this.center = ok;
		this.show();
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x0006039C File Offset: 0x0005E59C
	public override void paint(mGraphics g)
	{
		GameCanvas.paintz.paintInputDlg(g, this.padLeft, GameCanvas.h - 77 - mScreen.cmdH, GameCanvas.w - this.padLeft * 2, 69, this.info);
		this.tfInput.paint(g);
		base.paint(g);
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x000064EC File Offset: 0x000046EC
	public override void keyPress(int keyCode)
	{
		this.tfInput.keyPressed(keyCode);
		base.keyPress(keyCode);
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x00006502 File Offset: 0x00004702
	public override void update()
	{
		this.tfInput.update();
		base.update();
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x00006515 File Offset: 0x00004715
	public override void show()
	{
		GameCanvas.currentDialog = this;
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x00005761 File Offset: 0x00003961
	public void hide()
	{
		GameCanvas.endDlg();
	}

	// Token: 0x04000CF9 RID: 3321
	protected string[] info;

	// Token: 0x04000CFA RID: 3322
	public TField tfInput;

	// Token: 0x04000CFB RID: 3323
	private int padLeft;
}
