﻿using System;

// Token: 0x02000009 RID: 9
public class InputStream : myReader
{
	// Token: 0x0600004E RID: 78 RVA: 0x0000344D File Offset: 0x0000164D
	public InputStream()
	{
	}

	// Token: 0x0600004F RID: 79 RVA: 0x00003455 File Offset: 0x00001655
	public InputStream(sbyte[] data)
	{
		this.buffer = data;
	}

	// Token: 0x06000050 RID: 80 RVA: 0x00003464 File Offset: 0x00001664
	public InputStream(string filename) : base(filename)
	{
	}
}
