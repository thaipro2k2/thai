﻿using System;

// Token: 0x0200005A RID: 90
public class ItemObject
{
	// Token: 0x0400054A RID: 1354
	public int id;

	// Token: 0x0400054B RID: 1355
	public int where;

	// Token: 0x0400054C RID: 1356
	public int type;

	// Token: 0x0400054D RID: 1357
	public int indexX;

	// Token: 0x0400054E RID: 1358
	public int indexY;

	// Token: 0x0400054F RID: 1359
	public Image image;
}
