﻿using System;

// Token: 0x0200005D RID: 93
public class ItemTemplate
{
	// Token: 0x06000336 RID: 822 RVA: 0x0001BEFC File Offset: 0x0001A0FC
	public ItemTemplate(short templateID, sbyte type, sbyte gender, string name, string description, sbyte level, int strRequire, short iconID, short part, bool isUpToUp)
	{
		this.id = templateID;
		this.type = type;
		this.gender = gender;
		this.name = name;
		this.name = Res.changeString(this.name);
		this.description = description;
		this.description = Res.changeString(this.description);
		this.level = level;
		this.strRequire = strRequire;
		this.iconID = iconID;
		this.part = part;
		this.isUpToUp = isUpToUp;
	}

	// Token: 0x04000556 RID: 1366
	public short id;

	// Token: 0x04000557 RID: 1367
	public sbyte type;

	// Token: 0x04000558 RID: 1368
	public sbyte gender;

	// Token: 0x04000559 RID: 1369
	public string name;

	// Token: 0x0400055A RID: 1370
	public string[] subName;

	// Token: 0x0400055B RID: 1371
	public string description;

	// Token: 0x0400055C RID: 1372
	public sbyte level;

	// Token: 0x0400055D RID: 1373
	public short iconID;

	// Token: 0x0400055E RID: 1374
	public short part;

	// Token: 0x0400055F RID: 1375
	public bool isUpToUp;

	// Token: 0x04000560 RID: 1376
	public int w;

	// Token: 0x04000561 RID: 1377
	public int h;

	// Token: 0x04000562 RID: 1378
	public int strRequire;
}
