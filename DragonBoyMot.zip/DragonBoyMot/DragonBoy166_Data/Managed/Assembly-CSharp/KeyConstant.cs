﻿using System;

// Token: 0x020000A2 RID: 162
public class KeyConstant
{
	// Token: 0x04000CFC RID: 3324
	public const int KEY_NUM0 = 0;

	// Token: 0x04000CFD RID: 3325
	public const int KEY_NUM1 = 1;

	// Token: 0x04000CFE RID: 3326
	public const int KEY_NUM2 = 2;

	// Token: 0x04000CFF RID: 3327
	public const int KEY_NUM3 = 3;

	// Token: 0x04000D00 RID: 3328
	public const int KEY_NUM4 = 4;

	// Token: 0x04000D01 RID: 3329
	public const int KEY_NUM5 = 5;

	// Token: 0x04000D02 RID: 3330
	public const int KEY_NUM6 = 6;

	// Token: 0x04000D03 RID: 3331
	public const int KEY_NUM7 = 7;

	// Token: 0x04000D04 RID: 3332
	public const int KEY_NUM8 = 8;

	// Token: 0x04000D05 RID: 3333
	public const int KEY_NUM9 = 9;

	// Token: 0x04000D06 RID: 3334
	public const int KEY_STAR = 10;

	// Token: 0x04000D07 RID: 3335
	public const int KEY_BOUND = 11;

	// Token: 0x04000D08 RID: 3336
	public const int KEY_UP = 12;

	// Token: 0x04000D09 RID: 3337
	public const int KEY_DOWN = 13;

	// Token: 0x04000D0A RID: 3338
	public const int KEY_LEFT = 14;

	// Token: 0x04000D0B RID: 3339
	public const int KEY_RIGHT = 15;

	// Token: 0x04000D0C RID: 3340
	public const int KEY_FIRE = 16;

	// Token: 0x04000D0D RID: 3341
	public const int KEY_LEFT_SOFTKEY = 17;

	// Token: 0x04000D0E RID: 3342
	public const int KEY_RIGHT_SOFTKEY = 18;

	// Token: 0x04000D0F RID: 3343
	public const int KEY_CLEAR = 19;

	// Token: 0x04000D10 RID: 3344
	public const int KEY_BACK = 20;
}
