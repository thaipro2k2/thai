﻿using System;

// Token: 0x020000A3 RID: 163
public class Layer
{
	// Token: 0x060006F4 RID: 1780 RVA: 0x000031FC File Offset: 0x000013FC
	public void update()
	{
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x000031FC File Offset: 0x000013FC
	public void paint(mGraphics g, int x, int y)
	{
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x000031FC File Offset: 0x000013FC
	public void keyPress(int keyCode)
	{
	}
}
