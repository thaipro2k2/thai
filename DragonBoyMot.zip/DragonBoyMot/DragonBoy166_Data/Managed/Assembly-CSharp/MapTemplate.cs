﻿using System;

// Token: 0x02000062 RID: 98
public class MapTemplate
{
	// Token: 0x0400059B RID: 1435
	public static int[] tmw = new int[3];

	// Token: 0x0400059C RID: 1436
	public static int[] tmh = new int[3];

	// Token: 0x0400059D RID: 1437
	public static int[] pxw = new int[3];

	// Token: 0x0400059E RID: 1438
	public static int[] pxh = new int[3];

	// Token: 0x0400059F RID: 1439
	public static int[] tileID = new int[3];

	// Token: 0x040005A0 RID: 1440
	public static int[][] maps = new int[3][];

	// Token: 0x040005A1 RID: 1441
	public static int[][] types = new int[3][];

	// Token: 0x040005A2 RID: 1442
	public static MyVector[] vCurrItem = new MyVector[3];
}
