﻿using System;

// Token: 0x02000020 RID: 32
public class Message
{
	// Token: 0x06000134 RID: 308 RVA: 0x00003DC9 File Offset: 0x00001FC9
	public Message(int command)
	{
		this.command = (sbyte)command;
		this.dos = new myWriter();
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00003DE4 File Offset: 0x00001FE4
	public Message()
	{
		this.dos = new myWriter();
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00003DF7 File Offset: 0x00001FF7
	public Message(sbyte command)
	{
		this.command = command;
		this.dos = new myWriter();
	}

	// Token: 0x06000137 RID: 311 RVA: 0x00003E11 File Offset: 0x00002011
	public Message(sbyte command, sbyte[] data)
	{
		this.command = command;
		this.dis = new myReader(data);
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00003E2C File Offset: 0x0000202C
	public sbyte[] getData()
	{
		return this.dos.getData();
	}

	// Token: 0x06000139 RID: 313 RVA: 0x00003E39 File Offset: 0x00002039
	public myReader reader()
	{
		return this.dis;
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00003E41 File Offset: 0x00002041
	public myWriter writer()
	{
		return this.dos;
	}

	// Token: 0x0600013B RID: 315 RVA: 0x00003E49 File Offset: 0x00002049
	public int readInt3Byte()
	{
		return this.dis.readInt();
	}

	// Token: 0x0600013C RID: 316 RVA: 0x000031FC File Offset: 0x000013FC
	public void cleanup()
	{
	}

	// Token: 0x04000114 RID: 276
	public sbyte command;

	// Token: 0x04000115 RID: 277
	private myReader dis;

	// Token: 0x04000116 RID: 278
	private myWriter dos;
}
