﻿using System;

// Token: 0x02000064 RID: 100
public class MobTemplate
{
	// Token: 0x040005B5 RID: 1461
	public sbyte mobTemplateId;

	// Token: 0x040005B6 RID: 1462
	public sbyte rangeMove;

	// Token: 0x040005B7 RID: 1463
	public sbyte speed;

	// Token: 0x040005B8 RID: 1464
	public sbyte type;

	// Token: 0x040005B9 RID: 1465
	public int hp;

	// Token: 0x040005BA RID: 1466
	public string name;

	// Token: 0x040005BB RID: 1467
	public EffectData data;

	// Token: 0x040005BC RID: 1468
	public sbyte dartType;
}
