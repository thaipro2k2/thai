﻿using System;

// Token: 0x020000A9 RID: 169
public class MsgDlg : Dialog
{
	// Token: 0x0600075C RID: 1884 RVA: 0x00006792 File Offset: 0x00004992
	public MsgDlg()
	{
		this.padLeft = 35;
		if (GameCanvas.w <= 176)
		{
			this.padLeft = 10;
		}
		if (GameCanvas.w > 320)
		{
			this.padLeft = 80;
		}
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x000067D0 File Offset: 0x000049D0
	public void pleasewait()
	{
		this.setInfo(mResources.PLEASEWAIT, null, null, null);
		GameCanvas.currentDialog = this;
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x00006515 File Offset: 0x00004715
	public override void show()
	{
		GameCanvas.currentDialog = this;
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x00066740 File Offset: 0x00064940
	public void setInfo(string info)
	{
		this.info = mFont.tahoma_8b.splitFontArray(info, GameCanvas.w - (this.padLeft * 2 + 20));
		this.h = 80;
		if (this.info.Length >= 5)
		{
			this.h = this.info.Length * mFont.tahoma_8b.getHeight() + 20;
		}
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x000667A4 File Offset: 0x000649A4
	public void setInfo(string info, Command left, Command center, Command right)
	{
		this.info = mFont.tahoma_8b.splitFontArray(info, GameCanvas.w - (this.padLeft * 2 + 20));
		this.left = left;
		this.center = center;
		this.right = right;
		this.h = 80;
		if (this.info.Length >= 5)
		{
			this.h = this.info.Length * mFont.tahoma_8b.getHeight() + 20;
		}
		if (GameCanvas.isTouch)
		{
			if (left != null)
			{
				this.left.x = GameCanvas.w / 2 - 68 - 5;
				this.left.y = GameCanvas.h - 50;
			}
			if (right != null)
			{
				this.right.x = GameCanvas.w / 2 + 5;
				this.right.y = GameCanvas.h - 50;
			}
			if (center != null)
			{
				this.center.x = GameCanvas.w / 2 - 35;
				this.center.y = GameCanvas.h - 50;
			}
		}
		this.isWait = false;
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x000668B8 File Offset: 0x00064AB8
	public override void paint(mGraphics g)
	{
		g.setClip(0, 0, GameCanvas.w, GameCanvas.h);
		if (LoginScr.isContinueToLogin)
		{
			return;
		}
		int num = GameCanvas.h - this.h - 38;
		int w = GameCanvas.w - this.padLeft * 2;
		GameCanvas.paintz.paintPopUp(this.padLeft, num, w, this.h, g);
		int num2 = num + (this.h - this.info.Length * mFont.tahoma_8b.getHeight()) / 2 - 2;
		if (this.isWait)
		{
			num2 += 8;
			GameCanvas.paintShukiren(GameCanvas.hw, num2 - 12, g);
		}
		int i = 0;
		int num3 = num2;
		while (i < this.info.Length)
		{
			mFont.tahoma_7b_dark.drawString(g, this.info[i], GameCanvas.hw, num3, 2);
			i++;
			num3 += mFont.tahoma_8b.getHeight();
		}
		base.paint(g);
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x000067E6 File Offset: 0x000049E6
	public override void update()
	{
		base.update();
	}

	// Token: 0x04000DFB RID: 3579
	public string[] info;

	// Token: 0x04000DFC RID: 3580
	public bool isWait;

	// Token: 0x04000DFD RID: 3581
	private int h;

	// Token: 0x04000DFE RID: 3582
	private int padLeft;
}
