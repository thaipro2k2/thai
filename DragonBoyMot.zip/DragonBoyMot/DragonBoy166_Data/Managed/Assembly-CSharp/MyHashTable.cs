﻿using System;
using System.Collections;

// Token: 0x0200000C RID: 12
public class MyHashTable
{
	// Token: 0x0600005A RID: 90 RVA: 0x000034F6 File Offset: 0x000016F6
	public object get(object k)
	{
		return this.h[k];
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00003504 File Offset: 0x00001704
	public void clear()
	{
		this.h.Clear();
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003511 File Offset: 0x00001711
	public IDictionaryEnumerator GetEnumerator()
	{
		return this.h.GetEnumerator();
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000351E File Offset: 0x0000171E
	public int size()
	{
		return this.h.Count;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x0000352B File Offset: 0x0000172B
	public void put(object k, object v)
	{
		if (this.h.ContainsKey(k))
		{
			this.h.Remove(k);
		}
		this.h.Add(k, v);
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00003557 File Offset: 0x00001757
	public void remove(object k)
	{
		this.h.Remove(k);
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003557 File Offset: 0x00001757
	public void Remove(string key)
	{
		this.h.Remove(key);
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003565 File Offset: 0x00001765
	public bool containsKey(object key)
	{
		return this.h.ContainsKey(key);
	}

	// Token: 0x0400001D RID: 29
	public Hashtable h = new Hashtable();
}
