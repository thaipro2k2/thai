﻿using System;

// Token: 0x0200000E RID: 14
public class MyRandom
{
	// Token: 0x06000065 RID: 101 RVA: 0x00003573 File Offset: 0x00001773
	public MyRandom()
	{
		this.r = new Random();
	}

	// Token: 0x06000066 RID: 102 RVA: 0x00003586 File Offset: 0x00001786
	public int nextInt()
	{
		return this.r.Next();
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00003593 File Offset: 0x00001793
	public int nextInt(int a)
	{
		return this.r.Next(a);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x000035A1 File Offset: 0x000017A1
	public int nextInt(int a, int b)
	{
		return this.r.Next(a, b);
	}

	// Token: 0x0400001F RID: 31
	public Random r;
}
