﻿using System;

// Token: 0x02000066 RID: 102
public class NClass
{
	// Token: 0x040005C3 RID: 1475
	public int classId;

	// Token: 0x040005C4 RID: 1476
	public string name;

	// Token: 0x040005C5 RID: 1477
	public SkillTemplate[] skillTemplates;
}
