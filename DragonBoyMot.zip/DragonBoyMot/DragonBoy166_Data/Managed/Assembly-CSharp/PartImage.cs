﻿using System;

// Token: 0x0200006C RID: 108
public class PartImage
{
	// Token: 0x04000600 RID: 1536
	public short id;

	// Token: 0x04000601 RID: 1537
	public sbyte dx;

	// Token: 0x04000602 RID: 1538
	public sbyte dy;
}
