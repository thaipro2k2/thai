﻿using System;

// Token: 0x02000075 RID: 117
public class SkillInfoPaint
{
	// Token: 0x04000681 RID: 1665
	public int status;

	// Token: 0x04000682 RID: 1666
	public int effS0Id;

	// Token: 0x04000683 RID: 1667
	public int e0dx;

	// Token: 0x04000684 RID: 1668
	public int e0dy;

	// Token: 0x04000685 RID: 1669
	public int effS1Id;

	// Token: 0x04000686 RID: 1670
	public int e1dx;

	// Token: 0x04000687 RID: 1671
	public int e1dy;

	// Token: 0x04000688 RID: 1672
	public int effS2Id;

	// Token: 0x04000689 RID: 1673
	public int e2dx;

	// Token: 0x0400068A RID: 1674
	public int e2dy;

	// Token: 0x0400068B RID: 1675
	public int arrowId;

	// Token: 0x0400068C RID: 1676
	public int adx;

	// Token: 0x0400068D RID: 1677
	public int ady;
}
