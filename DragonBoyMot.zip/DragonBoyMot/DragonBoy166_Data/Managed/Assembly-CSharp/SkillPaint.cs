﻿using System;

// Token: 0x02000078 RID: 120
public class SkillPaint
{
	// Token: 0x04000693 RID: 1683
	public int id;

	// Token: 0x04000694 RID: 1684
	public int effectHappenOnMob;

	// Token: 0x04000695 RID: 1685
	public int numEff;

	// Token: 0x04000696 RID: 1686
	public SkillInfoPaint[] skillStand;

	// Token: 0x04000697 RID: 1687
	public SkillInfoPaint[] skillfly;
}
