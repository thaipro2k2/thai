﻿using System;

// Token: 0x02000079 RID: 121
public class SkillTemplate
{
	// Token: 0x060003CC RID: 972 RVA: 0x000051E1 File Offset: 0x000033E1
	public bool isBuffToPlayer()
	{
		return this.type == 2;
	}

	// Token: 0x060003CD RID: 973 RVA: 0x000051F2 File Offset: 0x000033F2
	public bool isUseAlone()
	{
		return this.type == 3;
	}

	// Token: 0x060003CE RID: 974 RVA: 0x00005203 File Offset: 0x00003403
	public bool isAttackSkill()
	{
		return this.type == 1;
	}

	// Token: 0x04000698 RID: 1688
	public sbyte id;

	// Token: 0x04000699 RID: 1689
	public int classId;

	// Token: 0x0400069A RID: 1690
	public string name;

	// Token: 0x0400069B RID: 1691
	public int maxPoint;

	// Token: 0x0400069C RID: 1692
	public int manaUseType;

	// Token: 0x0400069D RID: 1693
	public int type;

	// Token: 0x0400069E RID: 1694
	public int iconId;

	// Token: 0x0400069F RID: 1695
	public string[] description;

	// Token: 0x040006A0 RID: 1696
	public Skill[] skills;

	// Token: 0x040006A1 RID: 1697
	public string damInfo;
}
