﻿using System;

// Token: 0x02000042 RID: 66
public class SmallDart
{
	// Token: 0x06000291 RID: 657 RVA: 0x000046E5 File Offset: 0x000028E5
	public SmallDart(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	// Token: 0x0400031F RID: 799
	public int index;

	// Token: 0x04000320 RID: 800
	public int x;

	// Token: 0x04000321 RID: 801
	public int y;
}
