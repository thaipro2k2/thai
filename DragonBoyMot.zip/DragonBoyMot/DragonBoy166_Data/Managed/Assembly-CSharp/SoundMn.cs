﻿using System;

// Token: 0x0200007E RID: 126
public class SoundMn
{
	// Token: 0x060003E8 RID: 1000 RVA: 0x000052C7 File Offset: 0x000034C7
	public static void init(SoundMn.AssetManager ac)
	{
		Sound.setActivity(ac);
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x000052CF File Offset: 0x000034CF
	public static SoundMn gI()
	{
		if (SoundMn.gIz == null)
		{
			SoundMn.gIz = new SoundMn();
		}
		return SoundMn.gIz;
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x000217A4 File Offset: 0x0001F9A4
	public void loadSound(int mapID)
	{
		Sound.init(new int[]
		{
			SoundMn.AIR_SHIP,
			SoundMn.RAIN,
			SoundMn.TAITAONANGLUONG
		}, new int[]
		{
			SoundMn.GET_ITEM,
			SoundMn.MOVE,
			SoundMn.LOW_PUNCH,
			SoundMn.LOW_KICK,
			SoundMn.FLY,
			SoundMn.JUMP,
			SoundMn.PANEL_OPEN,
			SoundMn.BUTTON_CLOSE,
			SoundMn.BUTTON_CLICK,
			SoundMn.MEDIUM_PUNCH,
			SoundMn.MEDIUM_KICK,
			SoundMn.PANEL_OPEN,
			SoundMn.EAT_PEAN,
			SoundMn.OPEN_DIALOG,
			SoundMn.NORMAL_KAME,
			SoundMn.NAMEK_KAME,
			SoundMn.XAYDA_KAME,
			SoundMn.EXPLODE_1,
			SoundMn.EXPLODE_2,
			SoundMn.TRAIDAT_KAME,
			SoundMn.HP_UP,
			SoundMn.THAIDUONGHASAN,
			SoundMn.HOISINH,
			SoundMn.GONG,
			SoundMn.KHICHAY,
			SoundMn.BIG_EXPLODE,
			SoundMn.NAMEK_LAZER,
			SoundMn.NAMEK_CHARGE
		});
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x000218D0 File Offset: 0x0001FAD0
	public void getSoundOption()
	{
		if (GameCanvas.loginScr.isLogin2 && global::Char.myCharz().taskMaint != null && global::Char.myCharz().taskMaint.taskId >= 2)
		{
			Panel.strTool = new string[]
			{
				mResources.quayso,
				mResources.gameInfo,
				mResources.change_flag,
				mResources.change_zone,
				mResources.chat_world,
				mResources.account,
				mResources.option,
				mResources.change_account,
				mResources.REGISTOPROTECT
			};
			if (global::Char.myCharz().havePet)
			{
				Panel.strTool = new string[]
				{
					mResources.quayso,
					mResources.gameInfo,
					mResources.pet,
					mResources.change_flag,
					mResources.change_zone,
					mResources.chat_world,
					mResources.account,
					mResources.option,
					mResources.change_account,
					mResources.REGISTOPROTECT
				};
			}
		}
		else
		{
			Panel.strTool = new string[]
			{
				mResources.quayso,
				mResources.gameInfo,
				mResources.change_flag,
				mResources.change_zone,
				mResources.chat_world,
				mResources.account,
				mResources.option,
				mResources.change_account
			};
			if (global::Char.myCharz().havePet)
			{
				Panel.strTool = new string[]
				{
					mResources.quayso,
					mResources.gameInfo,
					mResources.pet,
					mResources.change_flag,
					mResources.change_zone,
					mResources.chat_world,
					mResources.account,
					mResources.option,
					mResources.change_account
				};
			}
		}
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00021A84 File Offset: 0x0001FC84
	public void getStrOption()
	{
		if (Main.isPC)
		{
			Panel.strCauhinh = new string[]
			{
				(!GameCanvas.isPlaySound) ? mResources.turnOnSound : mResources.turnOffSound,
				(mGraphics.zoomLevel <= 1) ? mResources.x2Screen : mResources.x1Screen
			};
		}
		else
		{
			Panel.strCauhinh = new string[]
			{
				(!GameCanvas.isPlaySound) ? mResources.turnOnSound : mResources.turnOffSound,
				(GameScr.isAnalog != 0) ? mResources.turnOffAnalog : mResources.turnOnAnalog
			};
		}
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x000052EA File Offset: 0x000034EA
	public void HP_MPup()
	{
		Sound.playSound(SoundMn.HP_UP, 0.5f);
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x00021B28 File Offset: 0x0001FD28
	public void charPunch(bool isKick, float volumn)
	{
		if (!global::Char.myCharz().me)
		{
			SoundMn.volume /= 2;
		}
		if (volumn <= 0f)
		{
			volumn = 0.01f;
		}
		int num = Res.random(0, 3);
		if (isKick)
		{
			Sound.playSound((num != 0) ? SoundMn.MEDIUM_KICK : SoundMn.LOW_KICK, 0.1f);
		}
		else
		{
			Sound.playSound((num != 0) ? SoundMn.MEDIUM_PUNCH : SoundMn.LOW_PUNCH, 0.1f);
		}
		this.poolCount++;
	}

	// Token: 0x060003EF RID: 1007 RVA: 0x000052FB File Offset: 0x000034FB
	public void thaiduonghasan()
	{
		Sound.playSound(SoundMn.THAIDUONGHASAN, 0.5f);
		this.poolCount++;
	}

	// Token: 0x060003F0 RID: 1008 RVA: 0x0000531A File Offset: 0x0000351A
	public void rain()
	{
		Sound.playMus(SoundMn.RAIN, 0.3f, true);
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x0000532C File Offset: 0x0000352C
	public void gongName()
	{
		Sound.playSound(SoundMn.NAMEK_CHARGE, 0.3f);
		this.poolCount++;
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x0000534B File Offset: 0x0000354B
	public void gong()
	{
		Sound.playSound(SoundMn.GONG, 0.2f);
		this.poolCount++;
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x0000536A File Offset: 0x0000356A
	public void getItem()
	{
		Sound.playSound(SoundMn.GET_ITEM, 0.3f);
		this.poolCount++;
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x00021BC4 File Offset: 0x0001FDC4
	public void soundToolOption()
	{
		GameCanvas.isPlaySound = !GameCanvas.isPlaySound;
		if (GameCanvas.isPlaySound)
		{
			Panel.strCauhinh[0] = mResources.turnOffSound;
			SoundMn.gI().loadSound(TileMap.mapID);
			Rms.saveRMSInt("isPlaySound", 1);
		}
		else
		{
			Panel.strCauhinh[0] = mResources.turnOnSound;
			SoundMn.gI().closeSound();
			Rms.saveRMSInt("isPlaySound", 0);
		}
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x000031FC File Offset: 0x000013FC
	public void update()
	{
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x00005389 File Offset: 0x00003589
	public void closeSound()
	{
		Sound.stopAll = true;
		this.stopAll();
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x00005397 File Offset: 0x00003597
	public void openSound()
	{
		if (Sound.music == null)
		{
			this.loadSound(0);
		}
		Sound.stopAll = false;
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x000053B0 File Offset: 0x000035B0
	public void bigeExlode()
	{
		Sound.playSound(SoundMn.BIG_EXPLODE, 0.5f);
		this.poolCount++;
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x000053CF File Offset: 0x000035CF
	public void explode_1()
	{
		Sound.playSound(SoundMn.EXPLODE_1, 0.5f);
		this.poolCount++;
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x000053CF File Offset: 0x000035CF
	public void explode_2()
	{
		Sound.playSound(SoundMn.EXPLODE_1, 0.5f);
		this.poolCount++;
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x000053EE File Offset: 0x000035EE
	public void traidatKame()
	{
		Sound.playSound(SoundMn.TRAIDAT_KAME, 1f);
		this.poolCount++;
	}

	// Token: 0x060003FC RID: 1020 RVA: 0x0000540D File Offset: 0x0000360D
	public void namekKame()
	{
		Sound.playSound(SoundMn.NAMEK_KAME, 0.3f);
		this.poolCount++;
	}

	// Token: 0x060003FD RID: 1021 RVA: 0x0000542C File Offset: 0x0000362C
	public void nameLazer()
	{
		Sound.playSound(SoundMn.NAMEK_LAZER, 0.3f);
		this.poolCount++;
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x0000544B File Offset: 0x0000364B
	public void xaydaKame()
	{
		Sound.playSound(SoundMn.XAYDA_KAME, 0.3f);
		this.poolCount++;
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x00021C34 File Offset: 0x0001FE34
	public void mobKame(int type)
	{
		int id = SoundMn.XAYDA_KAME;
		if (type == 13)
		{
			id = SoundMn.NORMAL_KAME;
		}
		Sound.playSound(id, 0.1f);
		this.poolCount++;
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x00021C70 File Offset: 0x0001FE70
	public void charRun(float volumn)
	{
		if (!global::Char.myCharz().me)
		{
			SoundMn.volume /= 2;
			if (volumn <= 0f)
			{
				volumn = 0.01f;
			}
		}
		if (GameCanvas.gameTick % 8 == 0)
		{
			Sound.playSound(SoundMn.MOVE, volumn);
			this.poolCount++;
		}
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x0000546A File Offset: 0x0000366A
	public void monkeyRun(float volumn)
	{
		if (GameCanvas.gameTick % 8 == 0)
		{
			Sound.playSound(SoundMn.KHICHAY, 0.2f);
			this.poolCount++;
		}
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x00005495 File Offset: 0x00003695
	public void charFall()
	{
		Sound.playSound(SoundMn.MOVE, 0.1f);
		this.poolCount++;
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x000054B4 File Offset: 0x000036B4
	public void charJump()
	{
		Sound.playSound(SoundMn.MOVE, 0.2f);
		this.poolCount++;
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x000054D3 File Offset: 0x000036D3
	public void panelOpen()
	{
		Sound.playSound(SoundMn.PANEL_OPEN, 0.5f);
		this.poolCount++;
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x000054F2 File Offset: 0x000036F2
	public void buttonClose()
	{
		Sound.playSound(SoundMn.BUTTON_CLOSE, 0.5f);
		this.poolCount++;
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x00005511 File Offset: 0x00003711
	public void buttonClick()
	{
		Sound.playSound(SoundMn.BUTTON_CLICK, 0.5f);
		this.poolCount++;
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x000031FC File Offset: 0x000013FC
	public void stopMove()
	{
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x00005530 File Offset: 0x00003730
	public void charFly()
	{
		Sound.playSound(SoundMn.FLY, 0.2f);
		this.poolCount++;
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x000031FC File Offset: 0x000013FC
	public void stopFly()
	{
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x000054F2 File Offset: 0x000036F2
	public void openMenu()
	{
		Sound.playSound(SoundMn.BUTTON_CLOSE, 0.5f);
		this.poolCount++;
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0000554F File Offset: 0x0000374F
	public void panelClick()
	{
		Sound.playSound(SoundMn.PANEL_CLICK, 0.5f);
		this.poolCount++;
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x0000556E File Offset: 0x0000376E
	public void eatPeans()
	{
		Sound.playSound(SoundMn.EAT_PEAN, 0.5f);
		this.poolCount++;
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x0000558D File Offset: 0x0000378D
	public void openDialog()
	{
		Sound.playSound(SoundMn.OPEN_DIALOG, 0.5f);
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x0000559E File Offset: 0x0000379E
	public void hoisinh()
	{
		Sound.playSound(SoundMn.HOISINH, 0.5f);
		this.poolCount++;
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x000055BD File Offset: 0x000037BD
	public void taitao()
	{
		Sound.playMus(SoundMn.TAITAONANGLUONG, 0.5f, true);
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x000031FC File Offset: 0x000013FC
	public void taitaoPause()
	{
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00021CD0 File Offset: 0x0001FED0
	public bool isPlayRain()
	{
		bool result;
		try
		{
			result = Sound.isPlayingSound();
		}
		catch (Exception ex)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x000034E0 File Offset: 0x000016E0
	public bool isPlayAirShip()
	{
		return false;
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x000055CF File Offset: 0x000037CF
	public void airShip()
	{
		SoundMn.cout++;
		if (SoundMn.cout % 2 == 0)
		{
			Sound.playMus(SoundMn.AIR_SHIP, 0.3f, false);
		}
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x000031FC File Offset: 0x000013FC
	public void pauseAirShip()
	{
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x000031FC File Offset: 0x000013FC
	public void resumeAirShip()
	{
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x000055F9 File Offset: 0x000037F9
	public void stopAll()
	{
		Sound.stopAllz();
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00005600 File Offset: 0x00003800
	public void backToRegister()
	{
		Session_ME.gI().close();
		GameCanvas.panel.hide();
		GameCanvas.loginScr.actRegister();
		GameCanvas.loginScr.switchToMe();
	}

	// Token: 0x040006B2 RID: 1714
	public static SoundMn gIz;

	// Token: 0x040006B3 RID: 1715
	public static bool isSound = true;

	// Token: 0x040006B4 RID: 1716
	public static int volume;

	// Token: 0x040006B5 RID: 1717
	private static int MAX_VOLUME = 10;

	// Token: 0x040006B6 RID: 1718
	public static SoundMn.MediaPlayer[] music;

	// Token: 0x040006B7 RID: 1719
	public static SoundMn.SoundPool[] sound;

	// Token: 0x040006B8 RID: 1720
	public static int[] soundID;

	// Token: 0x040006B9 RID: 1721
	public static int AIR_SHIP;

	// Token: 0x040006BA RID: 1722
	public static int RAIN = 1;

	// Token: 0x040006BB RID: 1723
	public static int TAITAONANGLUONG = 2;

	// Token: 0x040006BC RID: 1724
	public static int GET_ITEM;

	// Token: 0x040006BD RID: 1725
	public static int MOVE = 1;

	// Token: 0x040006BE RID: 1726
	public static int LOW_PUNCH = 2;

	// Token: 0x040006BF RID: 1727
	public static int LOW_KICK = 3;

	// Token: 0x040006C0 RID: 1728
	public static int FLY = 4;

	// Token: 0x040006C1 RID: 1729
	public static int JUMP = 5;

	// Token: 0x040006C2 RID: 1730
	public static int PANEL_OPEN = 6;

	// Token: 0x040006C3 RID: 1731
	public static int BUTTON_CLOSE = 7;

	// Token: 0x040006C4 RID: 1732
	public static int BUTTON_CLICK = 8;

	// Token: 0x040006C5 RID: 1733
	public static int MEDIUM_PUNCH = 9;

	// Token: 0x040006C6 RID: 1734
	public static int MEDIUM_KICK = 10;

	// Token: 0x040006C7 RID: 1735
	public static int PANEL_CLICK = 11;

	// Token: 0x040006C8 RID: 1736
	public static int EAT_PEAN = 12;

	// Token: 0x040006C9 RID: 1737
	public static int OPEN_DIALOG = 13;

	// Token: 0x040006CA RID: 1738
	public static int NORMAL_KAME = 14;

	// Token: 0x040006CB RID: 1739
	public static int NAMEK_KAME = 15;

	// Token: 0x040006CC RID: 1740
	public static int XAYDA_KAME = 16;

	// Token: 0x040006CD RID: 1741
	public static int EXPLODE_1 = 17;

	// Token: 0x040006CE RID: 1742
	public static int EXPLODE_2 = 18;

	// Token: 0x040006CF RID: 1743
	public static int TRAIDAT_KAME = 19;

	// Token: 0x040006D0 RID: 1744
	public static int HP_UP = 20;

	// Token: 0x040006D1 RID: 1745
	public static int THAIDUONGHASAN = 21;

	// Token: 0x040006D2 RID: 1746
	public static int HOISINH = 22;

	// Token: 0x040006D3 RID: 1747
	public static int GONG = 23;

	// Token: 0x040006D4 RID: 1748
	public static int KHICHAY = 24;

	// Token: 0x040006D5 RID: 1749
	public static int BIG_EXPLODE = 25;

	// Token: 0x040006D6 RID: 1750
	public static int NAMEK_LAZER = 26;

	// Token: 0x040006D7 RID: 1751
	public static int NAMEK_CHARGE = 27;

	// Token: 0x040006D8 RID: 1752
	public bool freePool;

	// Token: 0x040006D9 RID: 1753
	public int poolCount;

	// Token: 0x040006DA RID: 1754
	public static int cout = 1;

	// Token: 0x0200007F RID: 127
	public class MediaPlayer
	{
	}

	// Token: 0x02000080 RID: 128
	public class SoundPool
	{
	}

	// Token: 0x02000081 RID: 129
	public class AssetManager
	{
	}
}
