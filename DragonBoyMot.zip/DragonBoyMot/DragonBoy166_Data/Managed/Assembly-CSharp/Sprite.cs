﻿using System;

// Token: 0x0200001A RID: 26
public class Sprite
{
	// Token: 0x0400008C RID: 140
	public const int TRANS_MIRROR = 2;

	// Token: 0x0400008D RID: 141
	public const int TRANS_MIRROR_ROT180 = 1;

	// Token: 0x0400008E RID: 142
	public const int TRANS_MIRROR_ROT270 = 4;

	// Token: 0x0400008F RID: 143
	public const int TRANS_MIRROR_ROT90 = 7;

	// Token: 0x04000090 RID: 144
	public const int TRANS_NONE = 0;

	// Token: 0x04000091 RID: 145
	public const int TRANS_ROT180 = 3;

	// Token: 0x04000092 RID: 146
	public const int TRANS_ROT270 = 6;

	// Token: 0x04000093 RID: 147
	public const int TRANS_ROT90 = 5;
}
