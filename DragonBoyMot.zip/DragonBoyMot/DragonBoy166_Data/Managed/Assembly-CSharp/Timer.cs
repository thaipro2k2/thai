﻿using System;

// Token: 0x020000B4 RID: 180
public class Timer
{
	// Token: 0x060008C8 RID: 2248 RVA: 0x00007018 File Offset: 0x00005218
	public static void setTimer(IActionListener actionListener, int action, long timeEllapse)
	{
		Timer.timeListener = actionListener;
		Timer.idAction = action;
		Timer.timeExecute = mSystem.currentTimeMillis() + timeEllapse;
		Timer.isON = true;
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x000834C4 File Offset: 0x000816C4
	public static void update()
	{
		long num = mSystem.currentTimeMillis();
		if (Timer.isON && num > Timer.timeExecute)
		{
			Timer.isON = false;
			try
			{
				if (Timer.idAction > 0)
				{
					GameScr.gI().actionPerform(Timer.idAction, null);
				}
			}
			catch (Exception ex)
			{
			}
		}
	}

	// Token: 0x0400104D RID: 4173
	public static IActionListener timeListener;

	// Token: 0x0400104E RID: 4174
	public static int idAction;

	// Token: 0x0400104F RID: 4175
	public static long timeExecute;

	// Token: 0x04001050 RID: 4176
	public static bool isON;
}
