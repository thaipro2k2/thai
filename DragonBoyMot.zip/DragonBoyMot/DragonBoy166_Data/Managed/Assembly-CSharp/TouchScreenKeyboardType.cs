﻿using System;

// Token: 0x02000013 RID: 19
public enum TouchScreenKeyboardType
{
	// Token: 0x04000029 RID: 41
	Default,
	// Token: 0x0400002A RID: 42
	ASCIICapable,
	// Token: 0x0400002B RID: 43
	NumberPad
}
