﻿using System;

namespace Assets.src.e
{
	// Token: 0x0200004A RID: 74
	internal class ChatVip
	{
		// Token: 0x04000358 RID: 856
		public string chat;

		// Token: 0x04000359 RID: 857
		public int width;

		// Token: 0x0400035A RID: 858
		public int x;
	}
}
