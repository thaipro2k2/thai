﻿using System;

namespace Assets.src.e
{
	// Token: 0x0200007D RID: 125
	internal class SmallSave
	{
		// Token: 0x040006B0 RID: 1712
		public sbyte[] data;

		// Token: 0x040006B1 RID: 1713
		public int id;
	}
}
