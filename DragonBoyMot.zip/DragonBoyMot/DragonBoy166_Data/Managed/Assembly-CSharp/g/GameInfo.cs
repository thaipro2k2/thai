﻿using System;

namespace Assets.src.g
{
	// Token: 0x02000099 RID: 153
	internal class GameInfo
	{
		// Token: 0x04000B04 RID: 2820
		public string main;

		// Token: 0x04000B05 RID: 2821
		public string content;

		// Token: 0x04000B06 RID: 2822
		public short id;

		// Token: 0x04000B07 RID: 2823
		public bool hasRead;
	}
}
