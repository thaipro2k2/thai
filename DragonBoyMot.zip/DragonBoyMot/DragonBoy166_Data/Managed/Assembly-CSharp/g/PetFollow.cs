﻿using System;

namespace Assets.src.g
{
	// Token: 0x020000AB RID: 171
	public class PetFollow
	{
		// Token: 0x06000835 RID: 2101 RVA: 0x00006AFA File Offset: 0x00004CFA
		public PetFollow()
		{
			this.f = Res.random(0, 3);
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x0007CCB8 File Offset: 0x0007AEB8
		public void paint(mGraphics g)
		{
			SmallImage.drawSmallImage(g, (int)this.smallID, this.f, this.cmx, this.cmy + 3 + ((GameCanvas.gameTick % 10 <= 5) ? 0 : 1), 32, 32, (this.dir != 1) ? 2 : 0, StaticObj.VCENTER_HCENTER);
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x0007CD18 File Offset: 0x0007AF18
		public void update()
		{
			this.moveCamera();
			if (GameCanvas.gameTick % 3 == 0)
			{
				this.f = this.frame[this.count];
				this.count++;
			}
			if (this.count >= this.frame.Length)
			{
				this.count = 0;
			}
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00006B32 File Offset: 0x00004D32
		public void remove()
		{
			ServerEffect.addServerEffect(60, this.cmx, this.cmy + 3 + ((GameCanvas.gameTick % 10 <= 5) ? 0 : 1), 1);
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x0007CD74 File Offset: 0x0007AF74
		public void moveCamera()
		{
			if (this.cmy != this.cmtoY)
			{
				this.cmvy = this.cmtoY - this.cmy << 2;
				this.cmdy += this.cmvy;
				this.cmy += this.cmdy >> 4;
				this.cmdy &= 15;
			}
			if (this.cmx != this.cmtoX)
			{
				this.cmvx = this.cmtoX - this.cmx << 2;
				this.cmdx += this.cmvx;
				this.cmx += this.cmdx >> 4;
				this.cmdx &= 15;
			}
		}

		// Token: 0x04000F0B RID: 3851
		public short smallID;

		// Token: 0x04000F0C RID: 3852
		public Info info = new Info();

		// Token: 0x04000F0D RID: 3853
		public int dir;

		// Token: 0x04000F0E RID: 3854
		public int f;

		// Token: 0x04000F0F RID: 3855
		public int tF;

		// Token: 0x04000F10 RID: 3856
		public int cmtoY;

		// Token: 0x04000F11 RID: 3857
		public int cmy;

		// Token: 0x04000F12 RID: 3858
		public int cmdy;

		// Token: 0x04000F13 RID: 3859
		public int cmvy;

		// Token: 0x04000F14 RID: 3860
		public int cmyLim;

		// Token: 0x04000F15 RID: 3861
		public int cmtoX;

		// Token: 0x04000F16 RID: 3862
		public int cmx;

		// Token: 0x04000F17 RID: 3863
		public int cmdx;

		// Token: 0x04000F18 RID: 3864
		public int cmvx;

		// Token: 0x04000F19 RID: 3865
		public int cmxLim;

		// Token: 0x04000F1A RID: 3866
		private int[] frame = new int[]
		{
			0,
			1,
			2,
			1
		};

		// Token: 0x04000F1B RID: 3867
		private int count;
	}
}
