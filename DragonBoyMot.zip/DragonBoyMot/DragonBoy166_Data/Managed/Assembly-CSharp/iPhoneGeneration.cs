﻿using System;

// Token: 0x02000014 RID: 20
public enum iPhoneGeneration
{
	// Token: 0x0400002D RID: 45
	Unknown,
	// Token: 0x0400002E RID: 46
	iPhone,
	// Token: 0x0400002F RID: 47
	iPhone3G,
	// Token: 0x04000030 RID: 48
	iPhone3GS,
	// Token: 0x04000031 RID: 49
	iPodTouch1Gen,
	// Token: 0x04000032 RID: 50
	iPodTouch2Gen,
	// Token: 0x04000033 RID: 51
	iPodTouch3Gen,
	// Token: 0x04000034 RID: 52
	iPad1Gen,
	// Token: 0x04000035 RID: 53
	iPhone4,
	// Token: 0x04000036 RID: 54
	iPodTouch4Gen,
	// Token: 0x04000037 RID: 55
	iPad2Gen,
	// Token: 0x04000038 RID: 56
	iPhone4S,
	// Token: 0x04000039 RID: 57
	iPad3Gen,
	// Token: 0x0400003A RID: 58
	iPhone5,
	// Token: 0x0400003B RID: 59
	iPodTouch5Gen,
	// Token: 0x0400003C RID: 60
	iPadMini1Gen,
	// Token: 0x0400003D RID: 61
	iPad4Gen,
	// Token: 0x0400003E RID: 62
	iPhoneUnknown = 10001,
	// Token: 0x0400003F RID: 63
	iPadUnknown,
	// Token: 0x04000040 RID: 64
	iPodTouchUnknown
}
