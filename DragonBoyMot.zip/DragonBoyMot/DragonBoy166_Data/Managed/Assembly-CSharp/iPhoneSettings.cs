﻿using System;

// Token: 0x02000015 RID: 21
public class iPhoneSettings
{
	// Token: 0x04000041 RID: 65
	public static iPhoneGeneration generation;

	// Token: 0x04000042 RID: 66
	public static iPhoneGeneration iPhone;

	// Token: 0x04000043 RID: 67
	public static iPhoneGeneration iPhone3G;

	// Token: 0x04000044 RID: 68
	public static iPhoneGeneration iPodTouch1Gen;

	// Token: 0x04000045 RID: 69
	public static iPhoneGeneration iPodTouch2Gen;
}
